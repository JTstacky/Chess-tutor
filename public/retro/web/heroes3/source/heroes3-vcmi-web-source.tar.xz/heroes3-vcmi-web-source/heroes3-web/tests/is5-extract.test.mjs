import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { deflateRawSync } from "node:zlib";
import { mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const script = fileURLToPath(
  new URL("../tools/is5-extract.mjs", import.meta.url),
);

function cabinet(entries, directory = "Data") {
  const header = Buffer.alloc(2048);
  const cabParts = [];
  let cabOffset = 0;
  const descriptor = 0x20;
  const base = descriptor + 0x50;
  let cursor = 4 * (entries.length + 1);
  const putString = (text) => {
    const offset = cursor;
    cursor += header.write(`${text}\0`, base + cursor, "latin1");
    return offset;
  };
  const dirOffset = putString(directory);
  header.writeUInt32LE(dirOffset, base);
  entries.forEach((entry, index) => {
    const content = Buffer.from(entry.content);
    const compressed = entry.compressed ? deflateRawSync(content) : content;
    const payload = entry.compressed
      ? Buffer.concat([
          Buffer.from([compressed.length & 255, compressed.length >> 8]),
          compressed,
        ])
      : compressed;
    const nameOffset = putString(entry.name);
    const offset = cursor;
    header.writeUInt32LE(offset, base + (index + 1) * 4);
    let p = base + offset;
    header.writeUInt32LE(nameOffset, p);
    p += 4;
    header.writeUInt32LE(0, p);
    p += 4;
    header.writeUInt16LE(entry.compressed ? 4 : 0, p);
    p += 2;
    header.writeUInt32LE(content.length, p);
    p += 4;
    header.writeUInt32LE(payload.length, p);
    p += 4;
    p += 0x14;
    header.writeUInt32LE(cabOffset, p);
    p += 4;
    const md5 = createHash("md5").update(content).digest();
    if (entry.badMd5) md5[0] ^= 0xff;
    md5.copy(header, p);
    cursor += 58;
    cabParts.push(payload);
    cabOffset += payload.length;
  });
  header.write("ISc(", 0, "latin1");
  header.writeUInt32LE((1 << 24) | (5 << 12), 4);
  header.writeUInt32LE(descriptor, 12);
  header.writeUInt32LE(0x50, descriptor + 0x0c);
  header.writeUInt32LE(1, descriptor + 0x1c);
  header.writeUInt32LE(entries.length, descriptor + 0x28);
  return { header, cab: Buffer.concat(cabParts) };
}

async function runFixture(t, entries, directory) {
  const root = await mkdtemp(join(tmpdir(), "h3-is5-test-"));
  t.after(() => rm(root, { recursive: true, force: true }));
  const hdr = join(root, "data1.hdr");
  const cab = join(root, "data1.cab");
  const out = join(root, "out");
  const fixture = cabinet(entries, directory);
  await writeFile(hdr, fixture.header);
  await writeFile(cab, fixture.cab);
  const result = spawnSync(process.execPath, [script, hdr, cab, out], {
    encoding: "utf8",
  });
  return { root, out, result };
}

test("stored and raw-deflate cabinet entries pass MD5", async (t) => {
  const { out, result } = await runFixture(t, [
    { name: "stored.bin", content: "fake stored payload" },
    {
      name: "compressed.bin",
      content: "fake compressed payload",
      compressed: true,
    },
  ]);
  assert.equal(result.status, 0, result.stderr);
  assert.equal(
    await readFile(join(out, "Data", "stored.bin"), "utf8"),
    "fake stored payload",
  );
  assert.equal(
    await readFile(join(out, "Data", "compressed.bin"), "utf8"),
    "fake compressed payload",
  );
});

test("bad MD5 is rejected without a partial destination", async (t) => {
  const { out, result } = await runFixture(t, [
    { name: "bad.bin", content: "fake bytes", badMd5: true },
  ]);
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /MD5 mismatch/);
  assert.deepEqual(await readdir(join(out, "Data")), []);
});

test("cabinet parent traversal cannot escape output directory", async (t) => {
  const { root, result } = await runFixture(
    t,
    [{ name: "escape.bin", content: "fake bytes" }],
    "..",
  );
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /unsafe cabinet path/);
  assert.ok(!(await readdir(root)).includes("escape.bin"));
});
