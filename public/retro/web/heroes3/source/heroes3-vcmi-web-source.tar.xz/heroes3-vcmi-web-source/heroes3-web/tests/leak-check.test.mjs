import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtemp, mkdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { checkDirectory } from "../tools/leak-check.mjs";

async function fixture(t) {
  const root = await mkdtemp(join(tmpdir(), "h3-leak-test-"));
  t.after(() => rm(root, { recursive: true, force: true }));
  const publicDir = join(root, "public");
  await mkdir(publicDir);
  const manifest = join(root, "fake-sha256.json");
  return { root, publicDir, manifest };
}

test("clean public directory passes, including the CLI", async (t) => {
  const { publicDir, manifest } = await fixture(t);
  await writeFile(join(publicDir, "app.js"), "export const game = true;");
  assert.deepEqual(
    (await checkDirectory(publicDir, { manifest })).failures,
    [],
  );
  const result = spawnSync(
    process.execPath,
    ["tools/leak-check.mjs", publicDir],
    {
      cwd: new URL("..", import.meta.url),
      encoding: "utf8",
    },
  );
  assert.equal(result.status, 0, result.stderr);
});

test("case-insensitive data extension and LOD magic are rejected", async (t) => {
  const { publicDir, manifest } = await fixture(t);
  await writeFile(join(publicDir, "map.H3M"), "fake map");
  await writeFile(join(publicDir, "disc.ISO"), "fake disc");
  await writeFile(
    join(publicDir, "renamed.bin"),
    Buffer.from("LOD\0fake archive"),
  );
  const result = await checkDirectory(publicDir, { manifest });
  assert.equal(result.failures.length, 3);
  assert.match(result.failures.join("\n"), /data extension/);
  assert.match(result.failures.join("\n"), /LOD magic/);
  const cli = spawnSync(process.execPath, ["tools/leak-check.mjs", publicDir], {
    cwd: new URL("..", import.meta.url),
    encoding: "utf8",
  });
  assert.equal(cli.status, 1);
});

test("size and SHA-256 match finds renamed fake data", async (t) => {
  const { publicDir, manifest } = await fixture(t);
  const bytes = Buffer.from("synthetic payload, not game data");
  await writeFile(join(publicDir, "renamed.dat"), bytes);
  await writeFile(
    manifest,
    JSON.stringify({
      "Data/fake.snd": {
        size: bytes.length,
        sha256: createHash("sha256").update(bytes).digest("hex"),
      },
    }),
  );
  assert.match(
    (await checkDirectory(publicDir, { manifest })).failures[0],
    /matches private/,
  );
  await writeFile(
    join(publicDir, "renamed.dat"),
    Buffer.from("different payload"),
  );
  assert.deepEqual(
    (await checkDirectory(publicDir, { manifest })).failures,
    [],
  );
});

test("invalid manifest fails closed", async (t) => {
  const { publicDir, manifest } = await fixture(t);
  await writeFile(manifest, "{broken");
  await assert.rejects(checkDirectory(publicDir, { manifest }));
});
