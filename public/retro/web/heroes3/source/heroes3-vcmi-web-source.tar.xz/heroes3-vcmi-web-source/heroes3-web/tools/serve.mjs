import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, relative, extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const defaults = { port: Number(process.env.PORT ?? 8831), root: resolve(fileURLToPath(new URL('../web/', import.meta.url))) };
const mime = { '.html':'text/html', '.js':'text/javascript', '.mjs':'text/javascript', '.css':'text/css', '.json':'application/json', '.wasm':'application/wasm', '.png':'image/png', '.svg':'image/svg+xml', '.ico':'image/x-icon', '.data':'application/octet-stream', '.txt':'text/plain', '.md':'text/markdown' };
const headers = { 'Cross-Origin-Opener-Policy':'same-origin', 'Cross-Origin-Embedder-Policy':'require-corp', 'Cross-Origin-Resource-Policy':'same-origin', 'Cache-Control':'no-store' };

export async function startServer({ port = defaults.port, root = defaults.root, siteRoot = process.env.H3_SITE_PUBLIC,
  testBattle = false, testLocalFiles = false } = {}) {
  root = resolve(root);
  if (siteRoot) siteRoot = resolve(siteRoot);
  const server = createServer(async (req, res) => {
    const send = (code, body, type='text/plain') => { res.writeHead(code, { ...headers, 'Content-Type':type }); res.end(req.method === 'HEAD' ? undefined : body); };
    if (!['GET','HEAD'].includes(req.method)) return send(405, 'Method not allowed');
    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); }
    catch { return send(400, 'Bad path'); }
    if (pathname.includes('\0') || pathname.split('/').includes('..') || pathname.includes('\\')) return send(403, 'Forbidden');
    const file = resolve(root, '.' + (pathname.endsWith('/') ? pathname + 'index.html' : pathname));
    const rel = relative(root, file);
    if (rel.startsWith('..') || resolve(root, rel) !== file) return send(403, 'Forbidden');
    try {
      const info = await stat(file);
      if (!info.isFile()) return send(404, 'Not found');
      let body = await readFile(file);
      if (testLocalFiles && pathname === '/config.js') {
        if (!body.toString().includes('export const PRIVATE_STORE'))
          return send(500, 'Local file test config is outdated.');
        body = "export const PRIVATE_STORE = { enabled:false, apiBase:'http://127.0.0.1:8842', ownerProfileIds:[] };\n";
      }
      if (testBattle && pathname === '/launcher.js') {
        const source = body.toString();
        const marker = 'if (phase !== undefined) options.ENV.H3_TURN_PHASE = String(phase);';
        const callback = 'onTurnBattle: onBattle,';
        if (!source.includes(marker) || !source.includes(callback)) return send(500, 'Local battle test hook is outdated.');
        body = source.replace(marker, `${marker}\n      if (localSeat !== undefined) options.ENV.H3_TEST_BATTLE = '1';`)
          .replace(callback, `onTurnBattle: event => { (window.__h3Battles ??= []).push(event); onBattle(event); },`);
      }
      send(200, body, mime[extname(file).toLowerCase()] ?? 'application/octet-stream');
    } catch {
      if (pathname === '/tg-profile.js') return send(200, '', 'text/javascript');
      if (siteRoot && ['/tg-invite.js', '/tg-invite.css', '/relay.json'].includes(pathname)) {
        try {
          const siteFile = resolve(siteRoot, '.' + pathname);
          if (relative(siteRoot, siteFile).startsWith('..')) return send(403, 'Forbidden');
          return send(200, await readFile(siteFile), mime[extname(siteFile)]);
        } catch { /* The local test fixture did not supply this site asset. */ }
      }
      send(404, 'Not found');
    }
  });
  await new Promise((ok, fail) => { server.once('error', fail); server.listen(port, '127.0.0.1', ok); });
  return { server, url:`http://127.0.0.1:${server.address().port}/`, close:() => new Promise((ok, fail) => server.close(e => e ? fail(e) : ok())) };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const value = flag => { const i = args.indexOf(flag); return i < 0 ? undefined : args[i+1]; };
  startServer({ port:Number(value('--port') ?? process.env.PORT ?? 8831), root:value('--root') ?? defaults.root,
    testBattle: args.includes('--test-battle'), testLocalFiles: args.includes('--test-local-files') })
    .then(({url}) => console.log(`Serving ${url}`)).catch(e => { console.error(e); process.exitCode = 1; });
}
