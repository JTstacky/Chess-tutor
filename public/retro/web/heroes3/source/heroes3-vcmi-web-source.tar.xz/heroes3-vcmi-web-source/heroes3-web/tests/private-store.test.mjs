import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { PRIVATE_STORE } from "../web/config.js";
import { readManifest } from "../web/data-import.js";
import { privateStoreSource } from "../web/sources/private-store.js";

const missing = () => new DOMException("Missing", "NotFoundError");
class FileHandle {
  data = new Uint8Array();
  async getFile() { return new Blob([this.data]); }
  async createWritable() {
    const chunks = [];
    return new WritableStream({
      write(chunk) { chunks.push(Buffer.from(chunk)); },
      close: () => { this.data = Buffer.concat(chunks); },
    });
  }
}
class Directory {
  kind = "directory";
  children = new Map();
  async getDirectoryHandle(name, { create = false } = {}) {
    let child = this.children.get(name);
    if (!child && create) this.children.set(name, child = new Directory());
    if (!child || child.kind !== "directory") throw missing();
    return child;
  }
  async getFileHandle(name, { create = false } = {}) {
    let child = this.children.get(name);
    if (!child && create) this.children.set(name, child = new FileHandle());
    if (!child || child.kind === "directory") throw missing();
    return child;
  }
  async removeEntry(name) { if (!this.children.delete(name)) throw missing(); }
  async *entries() { yield* this.children.entries(); }
}
function fakeBrowser(t) {
  const originals = new Map();
  const replace = (name, value) => {
    originals.set(name, Object.getOwnPropertyDescriptor(globalThis, name));
    Object.defineProperty(globalThis, name, { configurable: true, value });
  };
  const values = new Map([
    ["evonline.session", "fake-profile-token"],
    ["tenggames.kind", "parent"],
  ]);
  const root = new Directory();
  replace("localStorage", { getItem: key => values.get(key) ?? null });
  replace("navigator", { storage: {
    getDirectory: async () => root,
    estimate: async () => ({ quota: 1e9, usage: 0 }),
    persist: async () => true,
  } });
  const previousEnabled = PRIVATE_STORE.enabled;
  PRIVATE_STORE.enabled = true;
  t.after(() => {
    PRIVATE_STORE.enabled = previousEnabled;
    for (const [name, descriptor] of originals)
      if (descriptor) Object.defineProperty(globalThis, name, descriptor);
      else delete globalThis[name];
  });
  return { values, root, replace };
}
const hash = bytes => createHash("sha256").update(bytes).digest("hex");
const privateHeaders = { "Cache-Control": "private, no-store" };
function fakeWorker(files, { badBody, badHeader, denied } = {}) {
  const records = Object.entries(files).map(([path, body]) => ({ path, size: body.length, sha256: hash(body) }));
  const calls = [];
  const fetch = async (url, options) => {
    calls.push({ url, options });
    assert.equal(options.headers.Authorization, "Bearer fake-profile-token");
    assert.equal(options.method, "GET");
    assert.equal(options.cache, "no-store");
    assert.equal(options.credentials, "omit");
    const path = decodeURI(url.split("/api/private/heroes3/")[1] ?? "");
    if (denied) return Response.json({ message: denied }, { status: 403, headers: privateHeaders });
    if (path === "manifest") return Response.json({ files: records }, { headers: privateHeaders });
    const body = files[path];
    if (!body) return new Response("missing", { status: 404, headers: privateHeaders });
    const bytes = path === badBody ? Buffer.from(body).fill(42) : body;
    let offset = 0;
    const stream = new ReadableStream({
      pull(controller) {
        if (offset === bytes.length) { controller.close(); return; }
        controller.enqueue(bytes.subarray(offset, offset + 3));
        offset = Math.min(offset + 3, bytes.length);
      },
    });
    return new Response(stream, {
      headers: { ...privateHeaders, "X-Sha256": path === badHeader ? "0".repeat(64) : hash(body) },
    });
  };
  return { fetch, calls };
}
const files = Object.fromEntries([
  "H3bitmap.lod", "H3sprite.lod", "H3ab_bmp.lod", "H3ab_spr.lod", "Heroes3.snd", "VIDEO.VID",
].map((name, index) => [`Data/${name}`, Buffer.from(`fake local file ${index}`)]));

test("button is visible for signed-in non-guests; Worker decides full access", t => {
  const { values } = fakeBrowser(t);
  assert.deepEqual(PRIVATE_STORE.ownerProfileIds, []);
  assert.equal(privateStoreSource.isAvailable(), true);
  values.set("tenggames.kind", "kid");
  values.set("evonline.tier", "full");
  assert.equal(privateStoreSource.isAvailable(), true);
  values.set("evonline.tier", "basic");
  assert.equal(privateStoreSource.isAvailable(), true);
  values.set("evonline.tier", "guest");
  assert.equal(privateStoreSource.isAvailable(), false);
  values.set("tenggames.kind", "parent");
  values.set("evonline.tier", "full");
  assert.equal(privateStoreSource.isAvailable(), true);
  values.set("tenggames.kind", "guest");
  assert.equal(privateStoreSource.isAvailable(), false);
  values.set("tenggames.kind", "parent");
  values.delete("evonline.session");
  assert.equal(privateStoreSource.isAvailable(), false);
});

test("fake Worker 403 full-account message reaches a basic kid", async t => {
  const { replace, values } = fakeBrowser(t);
  values.set("tenggames.kind", "kid");
  values.set("evonline.tier", "basic");
  const worker = fakeWorker(files, { denied: "Heroes III needs a full account." });
  replace("fetch", worker.fetch);
  assert.equal(privateStoreSource.isAvailable(), true);
  await assert.rejects(privateStoreSource.load(), /Heroes III needs a full account\./);
  assert.equal(worker.calls.length, 1);
});

test("fake Worker file hashes are checked before the staged OPFS swap", async t => {
  const { replace, root } = fakeBrowser(t);
  let worker = fakeWorker(files);
  replace("fetch", (...args) => worker.fetch(...args));
  const result = await privateStoreSource.load();
  assert.equal(result.manifest.source, "private-store");
  assert.equal(result.manifest.files.length, 6);
  assert.equal(worker.calls.length, 7);
  const before = await readManifest();

  worker = fakeWorker(files, { badBody: "Data/H3sprite.lod" });
  await assert.rejects(privateStoreSource.load(), /SHA-256 mismatch/);
  assert.deepEqual(await readManifest(), before);
  assert.deepEqual([...root.children.keys()], ["h3"]);

  worker = fakeWorker(files, { badHeader: "Data/H3bitmap.lod" });
  await assert.rejects(privateStoreSource.load(), /checksum header mismatch/);
  assert.deepEqual(await readManifest(), before);
});

test("fake Worker responses without private no-store are rejected", async t => {
  const { replace } = fakeBrowser(t);
  replace("fetch", async () => new Response("{}", { headers: { "Cache-Control": "public" } }));
  await assert.rejects(privateStoreSource.load(), /no-store protection/);
});
