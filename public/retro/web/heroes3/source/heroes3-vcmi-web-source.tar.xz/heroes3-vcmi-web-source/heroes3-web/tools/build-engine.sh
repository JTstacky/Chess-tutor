#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/env.sh"
source "$PROJECT_ROOT/tools/ramgate.sh"

build="$PROJECT_ROOT/build-wasm"
out="$PROJECT_ROOT/web/engine"
mkdir -p "$build" "$out"

# VCMI's Linux data path is derived from install prefix and DATA_DIR.
# Mount the GPL engine content there; user supplied Heroes III data is separate.
link_flags=(
  -pthread -fwasm-exceptions -sPTHREAD_POOL_SIZE=24 -sPROXY_TO_PTHREAD=1
  -sALLOW_MEMORY_GROWTH=1 -sMAXIMUM_MEMORY=4GB -sINITIAL_MEMORY=256MB
  -sSTACK_SIZE=2MB -sDEFAULT_PTHREAD_STACK_SIZE=2MB
  -sWASMFS=1 -lopfs.js -sFORCE_FILESYSTEM=1
  -sEXIT_RUNTIME=0 -sINVOKE_RUN=0 -sMODULARIZE=1 -sEXPORT_ES6=1
  -sEXPORT_NAME=createVcmi -sASSERTIONS=1 -sUSE_SDL=2
  -sEXPORTED_FUNCTIONS=_main,_h3_request_checkpoint,_h3_set_battle_bot,_wasmfs_create_opfs_backend,_wasmfs_create_directory
  -sEXPORTED_RUNTIME_METHODS=callMain,ccall,FS,ENV
)
linker="${link_flags[*]}"

# SDL 2.32.8's Emscripten audio driver reads the sample rate with a plain EM_ASM_INT, which runs on
# the proxied main thread (a worker, no Web Audio) and crashes there. Every other call in the
# driver already uses MAIN_THREAD_EM_ASM; make this one match, then let emcc rebuild libSDL2-mt.
sdl_audio="$EM_CACHE/ports/sdl2/SDL-release-2.32.8/src/audio/emscripten/SDL_emscriptenaudio.c"
if grep -q 'this->spec.freq = EM_ASM_INT' "$sdl_audio"; then
  sed -i 's/this->spec.freq = EM_ASM_INT/this->spec.freq = MAIN_THREAD_EM_ASM_INT/' "$sdl_audio"
  rm -f "$EM_CACHE"/sysroot/lib/wasm32-emscripten/libSDL2-mt.a
  echo 'patched SDL2 Emscripten audio sample-rate read to run on the browser main thread'
fi

ramgate
emcmake cmake -S "$PROJECT_ROOT/engines/vcmi" -B "$build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$build/install" -DDATA_DIR=vcmi \
  -DCMAKE_PREFIX_PATH="$PREFIX" -DCMAKE_FIND_PACKAGE_PREFER_CONFIG=TRUE \
  -DCMAKE_FIND_ROOT_PATH_MODE_PACKAGE=BOTH \
  -DCMAKE_HAVE_LIBC_PTHREAD=1 -DTHREADS_PREFER_PTHREAD_FLAG=ON \
  -DIconv_IS_BUILT_IN=TRUE \
  -Dminizip_INCLUDE_DIR="$PREFIX/include" -Dminizip_LIBRARY="$PREFIX/lib/libminizip.a" \
  -DLIBSQUISH_INCLUDE_DIR="$PREFIX/include" -DLIBSQUISH_LIBRARY="$PREFIX/lib/libsquish.a" \
  -DBoost_DIR="$PREFIX/lib/cmake/Boost-1.86.0" \
  -DCMAKE_C_FLAGS="$CFLAGS" -DCMAKE_CXX_FLAGS="$CXXFLAGS" \
  -DCMAKE_EXE_LINKER_FLAGS="$linker" \
  -DENABLE_CLIENT=ON -DENABLE_SERVER=OFF -DENABLE_SINGLE_APP_BUILD=OFF \
  -DENABLE_STATIC_LIBS=ON -DENABLE_LAUNCHER=OFF -DENABLE_EDITOR=OFF \
  -DENABLE_LOBBY=OFF -DENABLE_VIDEO=OFF -DENABLE_DISCORD=OFF \
  -DENABLE_MMAI=OFF -DENABLE_LUA=OFF -DENABLE_ERM=OFF \
  -DENABLE_TRANSLATIONS=OFF -DENABLE_TEST=OFF -DENABLE_INNOEXTRACT=OFF \
  -DENABLE_PCH=OFF -DENABLE_GITVERSION=OFF -DCOPY_CONFIG_ON_BUILD=OFF \
  -DENABLE_NULLKILLER_AI=OFF -DENABLE_NULLKILLER2_AI=ON \
  -DENABLE_STUPID_AI=ON -DENABLE_BATTLE_AI=ON

ramgate
cmake --build "$build" --target vcmiclient --parallel "$JOBS"

for file in vcmiclient.js vcmiclient.wasm vcmiclient.data; do
  [[ -s "$build/bin/$file" ]] || { echo "Missing engine output: $file" >&2; exit 1; }
  cp "$build/bin/$file" "$out/$file"
done
if [[ -f "$build/bin/vcmiclient.worker.js" ]]; then
  cp "$build/bin/vcmiclient.worker.js" "$out/"
else
  rm -f "$out/vcmiclient.worker.js"
fi
echo "Engine outputs copied to $out"
