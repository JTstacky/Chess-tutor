#pragma once
#include <algorithm>
#include <cstddef>
#include <functional>
#include <iterator>
#include <memory>
#include <mutex>
#include <queue>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace tbb {
template<class T> class blocked_range {
  T first_, last_; std::size_t grain_;
public:
  blocked_range(T first, T last, std::size_t grain = 1) : first_(first), last_(last), grain_(grain) {}
  T begin() const { return first_; } T end() const { return last_; }
  std::size_t grainsize() const { return grain_; }
};
template<class T> class blocked_range2d {
  blocked_range<T> rows_, cols_;
public:
  blocked_range2d(T rb,T re,std::size_t rg,T cb,T ce,std::size_t cg) : rows_(rb,re,rg), cols_(cb,ce,cg) {}
  const blocked_range<T>& rows() const { return rows_; }
  const blocked_range<T>& cols() const { return cols_; }
};
template<class Range,class Body> void parallel_for(const Range& r,Body&& body) { body(r); }
template<class Index,class Body> void parallel_for(Index first,Index last,Body&& body) { for(;first<last;++first) body(first); }
template<class Range,class Value,class Body,class Reduce>
Value parallel_reduce(const Range& r,Value identity,Body&& body,Reduce&&) { return body(r,identity); }
template<class F,class G> void parallel_invoke(F&& f,G&& g) { f(); g(); }
template<class F,class G,class H> void parallel_invoke(F&& f,G&& g,H&& h) { f(); g(); h(); }

// An enqueued task must run while its caller continues: AI and map generation
// wait for dependent work. Running it inline would deadlock those call sites.
class task_group {
  std::mutex mutex_; std::vector<std::thread> threads_;
public:
  task_group() = default; task_group(const task_group&) = delete;
  ~task_group() { wait(); }
  template<class F> auto defer(F&& f) { return [this, work=std::forward<F>(f)]() mutable { run(std::move(work)); }; }
  template<class F> void run(F&& f) {
    std::thread worker(std::forward<F>(f));
    std::lock_guard<std::mutex> lock(mutex_);
    threads_.emplace_back(std::move(worker));
  }
  void wait() {
    for (;;) {
      std::vector<std::thread> pending;
      { std::lock_guard<std::mutex> lock(mutex_); if(threads_.empty()) break; pending.swap(threads_); }
      for(auto& t: pending) t.join();
    }
  }
};
namespace this_task_arena {
  inline int max_concurrency() { return std::max(1u,std::thread::hardware_concurrency()); }
  inline int current_thread_index() { return 0; }
}
class task_arena {
public:
  explicit task_arena(int = 0) {}
  template<class F> void enqueue(F&& f) { f(); }
  template<class F> auto execute(F&& f) -> decltype(f()) { return f(); }
};
class global_control {
public:
  enum parameter { max_allowed_parallelism };
  global_control(parameter,int) {}
};
template<class T> class concurrent_queue {
  mutable std::mutex mutex_; std::queue<T> values_;
public:
  void push(T v) { std::lock_guard<std::mutex> lock(mutex_); values_.push(std::move(v)); }
  bool try_pop(T& out) { std::lock_guard<std::mutex> lock(mutex_); if(values_.empty()) return false; out=std::move(values_.front()); values_.pop(); return true; }
};

template<class Key> struct default_hash_compare {
  std::size_t hash(const Key& k) const { return std::hash<Key>{}(k); }
  bool equal(const Key& a,const Key& b) const { return a==b; }
};
template<class Key,class Value,class HashCompare=default_hash_compare<Key>> class concurrent_hash_map {
  struct Hash { std::size_t operator()(const Key& k) const { return HashCompare{}.hash(k); } };
  struct Equal { bool operator()(const Key& a,const Key& b) const { return HashCompare{}.equal(a,b); } };
  using map_type=std::unordered_map<Key,Value,Hash,Equal>;
  mutable std::mutex mutex_; map_type values_;
public:
  using value_type=typename map_type::value_type;
  template<bool Const> class basic_accessor {
    friend class concurrent_hash_map;
    using pointer=typename std::conditional<Const,const value_type*,value_type*>::type;
    std::unique_lock<std::mutex> lock_; pointer ptr_=nullptr;
  public:
    basic_accessor()=default;
    void release() { ptr_=nullptr; if(lock_.owns_lock()) lock_.unlock(); }
    auto operator->() const { return ptr_; }
    auto& operator*() const { return *ptr_; }
  };
  using accessor=basic_accessor<false>; using const_accessor=basic_accessor<true>;
  bool find(accessor& a,const Key& key) { a.release(); a.lock_=std::unique_lock<std::mutex>(mutex_); auto it=values_.find(key); if(it==values_.end()){a.release();return false;} a.ptr_=&*it; return true; }
  bool find(const_accessor& a,const Key& key) const { a.release(); a.lock_=std::unique_lock<std::mutex>(mutex_); auto it=values_.find(key); if(it==values_.end()){a.release();return false;} a.ptr_=&*it; return true; }
  bool insert(accessor& a,const value_type& value) { a.release(); a.lock_=std::unique_lock<std::mutex>(mutex_); auto result=values_.insert(value); a.ptr_=&*result.first; return result.second; }
  template<class... Args> bool emplace(Args&&... args) { std::lock_guard<std::mutex> lock(mutex_); return values_.emplace(std::forward<Args>(args)...).second; }
  bool erase(accessor& a) { if(!a.ptr_) return false; values_.erase(a.ptr_->first); a.release(); return true; }
  bool erase(const Key& key) { std::lock_guard<std::mutex> lock(mutex_); return values_.erase(key)>0; }
  void clear() { std::lock_guard<std::mutex> lock(mutex_); values_.clear(); }
  bool empty() const { std::lock_guard<std::mutex> lock(mutex_); return values_.empty(); }
  std::size_t size() const { std::lock_guard<std::mutex> lock(mutex_); return values_.size(); }
  auto begin() { return values_.begin(); } auto end() { return values_.end(); }
  auto begin() const { return values_.begin(); } auto end() const { return values_.end(); }
};
template<class T,class Hash=std::hash<T>> class concurrent_unordered_set : public std::unordered_set<T,Hash> {
  using base=std::unordered_set<T,Hash>; mutable std::mutex mutex_;
public:
  using base::base;
  auto insert(const T& v) { std::lock_guard<std::mutex> lock(mutex_); return base::insert(v); }
};
template<class K,class V,class Hash=std::hash<K>> class concurrent_unordered_map : public std::unordered_map<K,V,Hash> {
  using base=std::unordered_map<K,V,Hash>; mutable std::mutex mutex_;
public:
  using base::base;
  auto insert(const typename base::value_type& v) { std::lock_guard<std::mutex> lock(mutex_); return base::insert(v); }
};
template<class T> class concurrent_vector : public std::vector<T> {
  using base=std::vector<T>; mutable std::mutex mutex_;
public:
  using base::base;
  void push_back(const T& v) { std::lock_guard<std::mutex> lock(mutex_); base::push_back(v); }
  void push_back(T&& v) { std::lock_guard<std::mutex> lock(mutex_); base::push_back(std::move(v)); }
};
}
