// Local-only gameplay smoke check. H3_DATA_DIR points to the owner's installed
// game data; CDP attaches those files to the browser input without an upload.
import { spawn, execFileSync } from 'node:child_process';
import { access, mkdir, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve, sep } from 'node:path';
import { startServer } from './serve.mjs';

const pause = ms => new Promise(done => setTimeout(done, ms));
async function waitFor(fn, timeout, label, retryErrors = true) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    try { const value = await fn(); if (value) return value; }
    catch (error) { if (!retryErrors) throw error; }
    await pause(250);
  }
  throw Error(`Timed out waiting for ${label}.`);
}
function freeKiB() {
  const value = execFileSync('powershell', ['-NoProfile', '-Command',
    '(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'],
    { encoding: 'utf8' }).trim();
  return Number(value);
}
async function chromePath() {
  for (const path of [process.env.CHROME,
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe']) {
    if (!path) continue;
    try { await access(path); return path; } catch {}
  }
  throw Error('Chrome is not available locally.');
}
class CDP {
  constructor(url) {
    this.ws = new WebSocket(url);
    this.next = 0;
    this.pending = new Map();
    this.handlers = new Map();
    this.ready = new Promise((resolve, reject) => {
      this.ws.onopen = resolve;
      this.ws.onerror = reject;
    });
    this.ws.onmessage = event => {
      const message = JSON.parse(event.data);
      if (message.id) {
        const pending = this.pending.get(message.id);
        if (!pending) return;
        this.pending.delete(message.id);
        message.error ? pending.reject(Error(message.error.message)) : pending.resolve(message.result);
      } else for (const callback of this.handlers.get(message.method) ?? []) callback(message.params);
    };
  }
  async send(method, params = {}) {
    await this.ready;
    const id = ++this.next;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }
  on(method, callback) {
    this.handlers.set(method, [...(this.handlers.get(method) ?? []), callback]);
  }
  close() { this.ws.close(); }
}
async function evaluate(tab, expression) {
  const result = await tab.send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true });
  if (result.exceptionDetails) throw Error(result.exceptionDetails.exception?.description ?? result.exceptionDetails.text);
  return result.result.value;
}
async function localFiles(dataDir) {
  if (!dataDir) throw Error('Set H3_DATA_DIR to the local Heroes III data folder.');
  const root = resolve(dataDir);
  const data = await readdir(join(root, 'Data'), { withFileTypes: true });
  const files = data.filter(entry => entry.isFile() && /\.(lod|snd|vid)$/i.test(entry.name) &&
    (process.env.H3_INCLUDE_VIDEO === '1' || entry.name.toLowerCase() !== 'heroes3.vid'))
    .map(entry => join(root, 'Data', entry.name));
  const maps = await readdir(join(root, 'Maps'), { withFileTypes: true });
  const map = maps.find(entry => entry.isFile() && /\.h3m$/i.test(entry.name));
  if (map) files.push(join(root, 'Maps', map.name));
  const music = await readdir(join(root, 'Mp3'), { withFileTypes: true });
  files.push(...music.filter(entry => entry.isFile() && /\.mp3$/i.test(entry.name))
    .map(entry => join(root, 'Mp3', entry.name)));
  if (files.length < 6) throw Error('Local game data is incomplete.');
  return files;
}

async function main() {
  const onlineCreate = process.env.H3_FLOW === 'hotseat-online-begin';
  if (onlineCreate) process.env.H3_FLOW = 'hotseat-begin';
  const free = freeKiB();
  if (!Number.isFinite(free) || free < 2.5 * 1024 * 1024)
    throw Error(`RAM gate: ${(free / 1048576).toFixed(2)} GB free; need 2.5 GB for a real-data browser test.`);
  const files = await localFiles(process.env.H3_DATA_DIR);
  let server, chrome, profile, browser, tab;
  try {
    server = await startServer({ port: 8831 });
    profile = await mkdtemp(join(tmpdir(), 'h3-local-play-'));
    chrome = spawn(await chromePath(), [
      '--headless=new', '--remote-debugging-port=0', `--user-data-dir=${profile}`,
      '--no-first-run', '--no-default-browser-check', '--disable-gpu',
      '--no-sandbox', '--disable-extensions', '--mute-audio', 'about:blank',
    ], { stdio: 'ignore' });
    const port = await waitFor(async () => Number((await readFile(join(profile, 'DevToolsActivePort'), 'utf8')).split('\n')[0]), 15000, 'Chrome debugger');
    const version = await (await fetch(`http://127.0.0.1:${port}/json/version`)).json();
    browser = new CDP(version.webSocketDebuggerUrl);
    await browser.ready;
    const page = await waitFor(async () => (await (await fetch(`http://127.0.0.1:${port}/json`)).json()).find(item => item.type === 'page'), 10000, 'browser page');
    tab = new CDP(page.webSocketDebuggerUrl);
    await tab.ready;
    await Promise.all([tab.send('Page.enable'), tab.send('Runtime.enable'), tab.send('Network.enable'), tab.send('DOM.enable')]);
    const viewport = {
      landscape: { width: 844, height: 390 },
      portrait: { width: 390, height: 844 },
    }[process.env.H3_VIEWPORT];
    if (process.env.H3_VIEWPORT && !viewport) throw Error('H3_VIEWPORT must be landscape or portrait.');
    if (viewport) {
      await tab.send('Emulation.setDeviceMetricsOverride', { ...viewport, deviceScaleFactor: 1, mobile: true });
      await tab.send('Emulation.setTouchEmulationEnabled', { enabled: true, maxTouchPoints: 5 });
    }
    const logs = [], requests = [];
    tab.on('Runtime.consoleAPICalled', event => logs.push(event.args.map(arg => arg.value ?? arg.description ?? '').join(' ')));
    tab.on('Runtime.exceptionThrown', event => logs.push(event.exceptionDetails.exception?.description ?? event.exceptionDetails.text));
    tab.on('Network.requestWillBeSent', event => requests.push(event.request.method));
    await tab.send('Page.navigate', { url: server.url });
    await waitFor(() => evaluate(tab, `document.readyState==='complete' && crossOriginIsolated`), 20000, 'cross-origin isolation');
    const { root: node } = await tab.send('DOM.getDocument');
    const { nodeId } = await tab.send('DOM.querySelector', { nodeId: node.nodeId, selector: '#files-input' });
    if (!nodeId) throw Error('Game file input is missing.');
    await tab.send('DOM.setFileInputFiles', { nodeId, files });
    await waitFor(async () => {
      const state = await evaluate(tab, `({status:document.getElementById('status').textContent,
        ready:!document.getElementById('launch').disabled})`);
      if (/missing required|could not|failed/i.test(state.status)) throw Error(state.status);
      return state.ready;
    }, 300000, 'local file import', false);
    console.log(`Imported ${files.length} local files into the temporary browser profile.`);
    if (['seat-load-direct', 'seat-battle-direct'].includes(process.env.H3_FLOW)) {
      const seat = Number(process.env.H3_LOCAL_SEAT);
      if (![0, 1].includes(seat)) throw Error('Direct turn test needs red or blue H3_LOCAL_SEAT.');
      const source = seat === 0 ? (process.env.H3_SEAT_SOURCE === 'back'
        ? 'shots/turn-pass-back.vsgm1' : 'shots/turn-pass-source.vsgm1') : 'shots/turn-pass-handoff.vsgm1';
      const encodedSave = (await readFile(source)).toString('base64');
      await evaluate(tab, `import('/saves.js').then(m=>m.importSave(
        new File([Uint8Array.from(atob(${JSON.stringify(encodedSave)}), ch=>ch.charCodeAt(0))], 'TurnPass.vsgm1')))`);
      await evaluate(tab, `(()=>{
        window.__h3TurnEvents=[];window.__h3TurnSeats=[];window.__h3Checkpoints=[];window.__h3Battles=[];
        document.getElementById('setup').hidden=true;
        document.getElementById('game').hidden=false;
        return import('/launcher.js').then(m=>m.launch({
          canvas:document.getElementById('canvas'),localSeat:${seat},saveName:'TurnPass.vsgm1',
          onTurnPass:event=>window.__h3TurnEvents.push(event),
          onSeats:colors=>window.__h3TurnSeats.push(colors),
          onCheckpoint:event=>window.__h3Checkpoints.push(event),
          onBattle:event=>window.__h3Battles.push(event),
          ${process.env.H3_FLOW === 'seat-battle-direct' ? `factory: async options=>{
            options.preRun.push(()=>{options.ENV.H3_TEST_BATTLE='1'});
            return (await import('/engine/vcmiclient.js')).default(options);
          },` : ''}
          onMessage:line=>console.log(line),onStatus:line=>console.log(line)
        }).then(module=>{window.__h3Module=module;return true}));
      })()`);
    }
    if (['seat-load-direct', 'seat-battle-direct'].includes(process.env.H3_FLOW)) {
      const seat = Number(process.env.H3_LOCAL_SEAT);
      const colors = await waitFor(() => {
        const failure = logs.find(line => /H3 direct load: .*timed out|H3 turn load: (lobby start has no map|There are no maps to play\.)|FATAL ERROR|RuntimeError:/i.test(line));
        if (failure) throw Error(failure);
        return evaluate(tab, `window.__h3TurnSeats?.[0]`);
      }, 180000, 'native seat mapping', false)
        .catch(async error => {
          const debug = await tab.send('Page.captureScreenshot', { format: 'png' });
          await writeFile('shots/direct-load-debug.png', Buffer.from(debug.data, 'base64'));
          const ui = await evaluate(tab, `({loading:document.getElementById('loading-status').textContent,
            game:document.getElementById('game').hidden, seats:window.__h3TurnSeats})`);
          throw Error(`${error.message} UI: ${JSON.stringify(ui)} Recent engine logs: ${logs.slice(-80).join(' | ')}`);
        });
      console.log(`Direct turn load seat map: ${JSON.stringify(colors)}`);
      if (JSON.stringify(colors) !== '[0,1]') throw Error('Native seat map did not match the two human colours.');
      await waitFor(() => logs.some(line => line.includes('will be lead by human')), 90000, 'local human interface');
      const humans = logs.filter(line => line.includes('will be lead by human'));
      if (humans.length !== 1 || !humans[0].includes(seat === 0 ? 'Player red' : 'Player blue'))
        throw Error(`Direct load has wrong local human interface: ${humans.join(' | ')}`);
      if (process.env.H3_FLOW === 'seat-battle-direct') {
        const rect = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
        const point = { x: Math.round(rect.left + rect.width * 400 / 800),
          y: Math.round(rect.top + rect.height * 415 / 600) };
        await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...point, button: 'left', buttons: 1, clickCount: 1 });
        await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...point, button: 'left', buttons: 0, clickCount: 1 });
        const battle = await waitFor(() => evaluate(tab, 'window.__h3Battles?.[0]'), 45000, 'native two-human battle')
          .catch(async error => {
            const capture = await tab.send('Page.captureScreenshot', { format: 'png' });
            await writeFile('shots/online-human-battle-debug.png', Buffer.from(capture.data, 'base64'));
            throw Error(`${error.message} Recent engine logs: ${logs.slice(-100).join(' | ')}`);
          });
        if (!battle.active || battle.attacker !== 0 || battle.defender !== 1)
          throw Error(`Wrong native battle event: ${JSON.stringify(battle)}`);
        if (process.env.H3_BATTLE_REMOTE_INPUT === '1') {
          await waitFor(() => evaluate(tab, `window.__h3Battles.some(event=>event.control===1)`),
            60000, 'Blue human battle control');
          const before = await evaluate(tab, `window.__h3Battles.filter(event=>event.control===1).length`);
          await evaluate(tab, `(()=>{
            const canvas=document.getElementById('canvas');canvas.focus();
            for(const type of ['keydown','keyup']){
              const event=new KeyboardEvent(type,{code:'Space',key:' ',bubbles:true,cancelable:true});
              Object.defineProperty(event,'keyCode',{value:32});
              Object.defineProperty(event,'which',{value:32});
              canvas.dispatchEvent(event);
            }
          })()`);
          await waitFor(async () => (await evaluate(tab,
            `window.__h3Battles.filter(event=>event.control===1).length`)) > before,
          30000, 'remote synthetic battle action').catch(async error => {
            const capture = await tab.send('Page.captureScreenshot', { format: 'png' });
            await writeFile('shots/online-remote-input-debug.png', Buffer.from(capture.data, 'base64'));
            throw Error(`${error.message} Events: ${JSON.stringify(await evaluate(tab,'window.__h3Battles'))} Logs: ${logs.slice(-25).join(' | ')}`);
          });
          if (logs.some(line => line.includes('Player is not allowed to perform this action!')))
            throw Error('Server rejected the streamed remote human battle action.');
          console.log('A synthetic remote keyboard action advanced the Blue human battle side.');
        }
        if (process.env.H3_BATTLE_BOT === '1') {
          await evaluate(tab, `window.__h3Module.ccall('h3_set_battle_bot',null,['number'],[1])`);
          await waitFor(() => logs.some(line => line.includes('H3 away battle bot enabled for blue')),
            60000, 'native remote battle AI').catch(async error => {
              const capture = await tab.send('Page.captureScreenshot', { format: 'png' });
              await writeFile('shots/online-bot-debug.png', Buffer.from(capture.data, 'base64'));
              throw Error(`${error.message} Events: ${JSON.stringify(await evaluate(tab, 'window.__h3Battles'))} Logs: ${logs.slice(-70).join(' | ')}`);
            });
          console.log('Remote human battle side switched to BattleAI.');
          await waitFor(async () => (await evaluate(tab,
            `window.__h3Battles.filter(event=>event.control===1).length`)) >= 2,
          60000, 'remote battle AI actions');
          console.log('The remote BattleAI received multiple Blue combat turns.');
          let resultScreen;
          await waitFor(async () => {
            await pause(1500);
            resultScreen = await tab.send('Page.captureScreenshot', { format: 'png' });
            const pixel = await evaluate(tab, `(async()=>{
              const bytes=Uint8Array.from(atob(${JSON.stringify(resultScreen.data)}), ch=>ch.charCodeAt(0));
              const image=await createImageBitmap(new Blob([bytes],{type:'image/png'}));
              const sample=document.createElement('canvas');sample.width=sample.height=1;
              const ctx=sample.getContext('2d');ctx.drawImage(image,200,100,1,1,0,0,1,1);
              image.close();return [...ctx.getImageData(0,0,1,1).data];
            })()`);
            return pixel[0] === 0 && pixel[1] === 0 && pixel[2] === 0;
          }, 90000, 'two-human battle result window').catch(async error => {
            await writeFile('shots/online-bot-result-debug.png', Buffer.from(resultScreen.data, 'base64'));
            throw Error(`${error.message} Events: ${JSON.stringify(await evaluate(tab,'window.__h3Battles'))} Logs: ${logs.slice(-25).join(' | ')}`);
          });
          await writeFile('shots/online-bot-result.png', Buffer.from(resultScreen.data, 'base64'));
          const resultRect = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
          const okay = { x: Math.round(resultRect.left + resultRect.width * 580 / 800),
            y: Math.round(resultRect.top + resultRect.height * 550 / 600) };
          await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...okay, button: 'left', buttons: 1, clickCount: 1 });
          await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...okay, button: 'left', buttons: 0, clickCount: 1 });
          await tab.send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13 });
          await tab.send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13 });
          await waitFor(() => evaluate(tab, `window.__h3Battles.some(event=>event.active===false)`),
            30000, 'battle result acknowledgement').catch(async error => {
              const capture = await tab.send('Page.captureScreenshot', { format: 'png' });
              await writeFile('shots/online-bot-ack-debug.png', Buffer.from(capture.data, 'base64'));
              throw Error(`${error.message} Logs: ${logs.slice(-25).join(' | ')}`);
            });
          if (logs.some(line => line.includes('Player is not allowed to perform this action!')))
            throw Error('Battle result confirmation was rejected by the native server.');
          console.log('The native human battle completed and its result was accepted.');
        }
        await pause(4000);
        const capture = await tab.send('Page.captureScreenshot', { format: 'png' });
        await writeFile('shots/online-human-battle.png', Buffer.from(capture.data, 'base64'));
        console.log(`Native human battle started: ${JSON.stringify(battle)}. Screenshot saved locally.`);
      }
      if (process.env.H3_FLOW !== 'seat-battle-direct' && (process.env.H3_DIRECT_END === '1' || (seat === 0 && process.env.H3_SEAT_SOURCE !== 'back'))) {
        const bounds = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
        const click = async (x, y) => {
          const point = { x: Math.round(bounds.left + bounds.width * x / 800), y: Math.round(bounds.top + bounds.height * y / 600) };
          await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...point, button: 'none', buttons: 0 });
          await pause(150);
          await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...point, button: 'left', buttons: 1, clickCount: 1 });
          await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...point, button: 'left', buttons: 0, clickCount: 1 });
        };
        await click(400, 400); // Red's hot-seat privacy confirmation, if shown.
        await pause(4000);
        if (seat === 1) {
          await click(400, 415); // Blue's start-of-turn rumour confirmation on the fixture map.
          await pause(1000);
        }
        await evaluate(tab, `[...document.querySelectorAll('#touch-bar button')].find(button=>button.textContent==='End turn').click()`);
        await pause(1500);
        await click(355, 350);
        const afterEnd = await tab.send('Page.captureScreenshot', { format: 'png' });
        await writeFile('shots/direct-after-end.png', Buffer.from(afterEnd.data, 'base64'));
        const event = await waitFor(() => evaluate(tab, `window.__h3TurnEvents?.[0]`), seat === 1 ? 240000 : 90000, 'structured native handoff')
          .catch(async error => {
            const debug = await tab.send('Page.captureScreenshot', { format: 'png' });
            await writeFile('shots/direct-end-debug.png', Buffer.from(debug.data, 'base64'));
            const checkpoints = await evaluate(tab, `window.__h3Checkpoints`);
            throw Error(`${error.message} Checkpoints: ${JSON.stringify(checkpoints)} Recent engine logs: ${logs.slice(-90).join(' | ')}`);
          });
        if (event.seat !== 1 - seat || event.save !== 'TurnPass.vsgm1' || event.phase !== 0)
          throw Error(`Wrong native handoff: ${JSON.stringify(event)}`);
        const encoded = await evaluate(tab, `import('/saves.js').then(async m=>{
          const file=await m.exportSave('TurnPass.vsgm1'), bytes=new Uint8Array(await file.arrayBuffer());
          let binary='';for(let i=0;i<bytes.length;i+=8192)
            binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
          return btoa(binary);
        })`);
        await writeFile(seat === 0 ? 'shots/turn-pass-handoff.vsgm1' : 'shots/turn-pass-back.vsgm1', Buffer.from(encoded, 'base64'));
        console.log(`Structured native handoff saved ${Buffer.from(encoded, 'base64').length} bytes.`);
      }
    }
    if (process.env.H3_FLOW === 'seat-load') {
      const seat = Number(process.env.H3_LOCAL_SEAT);
      if (!Number.isInteger(seat) || seat < 0 || seat > 7) throw Error('H3_LOCAL_SEAT must be 0-7.');
      const source = seat === 0 ? 'shots/turn-pass-source.vsgm1' : 'shots/turn-pass-handoff.vsgm1';
      const encodedSave = (await readFile(source)).toString('base64');
      await evaluate(tab, `import('/saves.js').then(m=>m.importSave(
        new File([Uint8Array.from(atob(${JSON.stringify(encodedSave)}), ch=>ch.charCodeAt(0))], 'TurnPass.vsgm1')))`);
      await evaluate(tab, `(()=>{
        document.getElementById('setup').hidden=true;
        document.getElementById('game').hidden=false;
        return import('/launcher.js').then(m=>m.launch({
          canvas:document.getElementById('canvas'),localSeat:${seat},
          onMessage:line=>console.log(line),onStatus:line=>console.log(line)
        }));
      })()`);
    } else if (onlineCreate) {
      await evaluate(tab, `(()=>{
        window.__h3TurnSeats=[];
        document.getElementById('setup').hidden=true;
        document.getElementById('game').hidden=false;
        return import('/launcher.js').then(m=>m.launch({
          canvas:document.getElementById('canvas'),localSeat:0,
          onSeats:colors=>window.__h3TurnSeats.push(colors),
          onMessage:line=>console.log(line),onStatus:line=>console.log(line)
        }));
      })()`);
    } else if (!['seat-load-direct', 'seat-battle-direct'].includes(process.env.H3_FLOW)) {
      await evaluate(tab, `document.getElementById('launch').click()`);
    }
    await waitFor(() => evaluate(tab, `!document.getElementById('game').hidden`), 15000, 'game canvas');
    await waitFor(() => logs.some(line => /All game content loaded|uncaught exception|FATAL ERROR|Pthread .* sent an error/i.test(line)), 240000, 'game content initialization');
    await pause(10000);
    console.log(`Runtime status: ${await evaluate(tab, `({engine:document.getElementById('engine-status').textContent,loading:document.getElementById('loading-status').textContent,width:document.getElementById('canvas').width,height:document.getElementById('canvas').height})`).then(JSON.stringify)}`);
    console.log(`Runtime milestones: ${logs.filter(line => /Created renderer|All game content loaded|Failed to load music|uncaught exception|FATAL ERROR/i.test(line)).join(' | ')}`);
    if (logs.some(line => /FATAL ERROR|Could not mount browser game storage|RuntimeError:|unreachable|worker: onmessage\(\) captured an uncaught exception|Pthread .* sent an error|Uncaught TypeError/i.test(line)))
      throw Error(`Engine failed: ${logs.filter(line => /FATAL ERROR|Could not mount|RuntimeError|unreachable|uncaught exception|sent an error|Uncaught TypeError/i.test(line)).at(-1)}`);
    await mkdir('shots', { recursive: true });
    const shot = await tab.send('Page.captureScreenshot', { format: 'png' });
    await writeFile('shots/local-main-menu.png', Buffer.from(shot.data, 'base64'));
    const colors = await evaluate(tab, `new Promise((resolve,reject)=>{
      const img=new Image(); img.onload=()=>{
        const canvas=document.createElement('canvas'); canvas.width=img.width; canvas.height=img.height;
        const ctx=canvas.getContext('2d'); ctx.drawImage(img,0,0);
        const rect=document.getElementById('canvas').getBoundingClientRect();
        const samples=new Set();
        for(let y=30;y<Math.min(rect.height-30,390);y+=20)
          for(let x=30;x<Math.min(rect.width-30,510);x+=20)
            samples.add([...ctx.getImageData(Math.floor(rect.left+x),Math.floor(rect.top+y),1,1).data].join(','));
        resolve(samples.size);
      }; img.onerror=reject; img.src='data:image/png;base64,${shot.data}';
    })`);
    console.log(`Game canvas sample colors: ${colors}`);
    if (colors < 12) throw Error('Game canvas is still blank after engine startup.');
    console.log(`Game canvas captured locally; ${logs.length} console lines. Screenshot: shots/local-main-menu.png`);
    if (viewport) {
      const layout = await evaluate(tab, `(()=>{
        const canvas=document.getElementById('canvas').getBoundingClientRect();
        const bar=document.getElementById('touch-bar');
        const buttons=[...bar.querySelectorAll('button')].map(button=>button.getBoundingClientRect());
        const hint=document.getElementById('rotate-hint');
        return {width:innerWidth,height:innerHeight,canvas:{left:canvas.left,top:canvas.top,right:canvas.right,bottom:canvas.bottom,width:canvas.width,height:canvas.height},
          controlsVisible:getComputedStyle(bar).display!=='none',smallButtons:buttons.filter(r=>r.width<48||r.height<48).length,
          outsideButtons:buttons.filter(r=>r.left<0||r.top<0||r.right>innerWidth+1||r.bottom>innerHeight+1).length,
          rotateHint:getComputedStyle(hint).display!=='none',scrollWidth:document.documentElement.scrollWidth};
      })()`);
      if (layout.canvas.width < 200 || layout.canvas.height < 150 || layout.canvas.left < 0 ||
          layout.canvas.top < 0 || layout.canvas.right > layout.width + 1 || layout.canvas.bottom > layout.height + 1 ||
          !layout.controlsVisible || layout.smallButtons || layout.outsideButtons || layout.scrollWidth > layout.width + 1 ||
          layout.rotateHint !== (process.env.H3_VIEWPORT === 'portrait'))
        throw Error(`Real-engine mobile layout failed: ${JSON.stringify(layout)}`);
      await writeFile(`shots/local-phone-${process.env.H3_VIEWPORT}.png`, Buffer.from(shot.data, 'base64'));
      console.log(`Real-engine ${process.env.H3_VIEWPORT} layout passed: ${JSON.stringify(layout)}`);
    }
    if (process.env.H3_FLOW === 'seat-load') {
      const seat = Number(process.env.H3_LOCAL_SEAT);
      const bounds = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
      const load = { x: Math.round(bounds.left + bounds.width * 644 / 800), y: Math.round(bounds.top + bounds.height * 200 / 600) };
      await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...load, button: 'none', buttons: 0 });
      await pause(150);
      await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...load, button: 'left', buttons: 1, clickCount: 1 });
      await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...load, button: 'left', buttons: 0, clickCount: 1 });
      await pause(5000);
      const menu = await tab.send('Page.captureScreenshot', { format: 'png' });
      await writeFile('shots/local-seat-load-menu.png', Buffer.from(menu.data, 'base64'));
      console.log('Seat-load selection captured locally.');
      const choose = { x: Math.round(bounds.left + bounds.width * 649 / 800), y: Math.round(bounds.top + bounds.height * 65 / 600) };
      await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...choose, button: 'none', buttons: 0 });
      await pause(150);
      await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...choose, button: 'left', buttons: 1, clickCount: 1 });
      await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...choose, button: 'left', buttons: 0, clickCount: 1 });
      await pause(4000);
      const saves = await tab.send('Page.captureScreenshot', { format: 'png' });
      await writeFile('shots/local-seat-save-list.png', Buffer.from(saves.data, 'base64'));
      console.log('Seat-load native save list captured locally.');
      const loadSave = { x: Math.round(bounds.left + bounds.width * 490 / 800), y: Math.round(bounds.top + bounds.height * 558 / 600) };
      await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...loadSave, button: 'none', buttons: 0 });
      await pause(150);
      await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...loadSave, button: 'left', buttons: 1, clickCount: 1 });
      await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...loadSave, button: 'left', buttons: 0, clickCount: 1 });
      await pause(45000);
      const loaded = await tab.send('Page.captureScreenshot', { format: 'png' });
      await writeFile(`shots/local-seat-${process.env.H3_LOCAL_SEAT}-loaded.png`, Buffer.from(loaded.data, 'base64'));
      const humans = logs.filter(line => line.includes('will be lead by human'));
      const computers = logs.filter(line => line.includes('will be lead by') && !line.includes('will be lead by human'));
      console.log(`Seat ${process.env.H3_LOCAL_SEAT}: human interfaces: ${humans.join(' | ')}; AI interfaces: ${computers.length}.`);
      if (humans.length !== 1 || !humans[0].includes(seat === 0 ? 'Player red' : 'Player blue'))
        throw Error('Turn-pass load did not create exactly the selected local human interface.');
      if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:/i.test(line)))
        throw Error('Engine worker failed while loading the remote-seat save.');
      if (seat === 0) {
        const accept = { x: Math.round(bounds.left + bounds.width * 400 / 800), y: Math.round(bounds.top + bounds.height * 400 / 600) };
        await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...accept, button: 'none', buttons: 0 });
        await pause(150);
        await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...accept, button: 'left', buttons: 1, clickCount: 1 });
        await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...accept, button: 'left', buttons: 0, clickCount: 1 });
        await pause(4000);
        await evaluate(tab, `[...document.querySelectorAll('#touch-bar button')].find(button=>button.textContent==='End turn').click()`);
        await pause(1500);
        const confirm = { x: Math.round(bounds.left + bounds.width * 355 / 800), y: Math.round(bounds.top + bounds.height * 350 / 600) };
        await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...confirm, button: 'none', buttons: 0 });
        await pause(150);
        await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...confirm, button: 'left', buttons: 1, clickCount: 1 });
        await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...confirm, button: 'left', buttons: 0, clickCount: 1 });
        await waitFor(() => logs.some(line => line.includes('H3_TURN_PASS_READY seat=1')), 90000, 'turn-pass save marker');
        const handoff = await waitFor(async () => {
          const list = await evaluate(tab, `import('/saves.js').then(m=>m.listSaves())`);
          return list.find(entry => entry.name === 'TurnPass.vsgm1' && entry.size > 0);
        }, 15000, 'turn-pass native save');
        const encoded = await evaluate(tab, `import('/saves.js').then(async m=>{
          const file=await m.exportSave('TurnPass.vsgm1'), bytes=new Uint8Array(await file.arrayBuffer());
          let binary='';for(let i=0;i<bytes.length;i+=8192)
            binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
          return btoa(binary);
        })`);
        await writeFile('shots/turn-pass-handoff.vsgm1', Buffer.from(encoded, 'base64'));
        console.log(`Remote blue turn saved locally: ${handoff.size} bytes.`);
      }
    }
    if (['new-game', 'scenario', 'begin', 'save-dialog', 'save', 'load-dialog', 'load-menu', 'load-list', 'load', 'turn-dialog', 'turn', 'hotseat-menu', 'hotseat-names', 'hotseat-typed', 'hotseat-lobby', 'hotseat-begin', 'hotseat-first', 'hotseat-pass', 'hotseat-save'].includes(process.env.H3_FLOW)) {
      // VCMI's own mainmenu.json centres this button at game coordinates 644,70.
      const bounds = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height,dpr:devicePixelRatio}})()`);
      const target = { x: Math.round(bounds.left + bounds.width * 644 / 800), y: Math.round(bounds.top + bounds.height * 70 / 600) };
      if (viewport) {
        await tab.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ ...target, id: 0 }] });
        await pause(150);
        await tab.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
      } else {
        await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...target, button: 'none', buttons: 0 });
        await pause(150);
        await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...target, button: 'left', buttons: 1, clickCount: 1 });
        await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...target, button: 'left', buttons: 0, clickCount: 1 });
      }
      await pause(5000);
      const next = await tab.send('Page.captureScreenshot', { format: 'png' });
      await writeFile('shots/local-new-game.png', Buffer.from(next.data, 'base64'));
      const layout = await evaluate(tab, `(()=>{const c=document.getElementById('canvas').getBoundingClientRect(),w=document.getElementById('canvas-wrap').getBoundingClientRect(),bar=document.getElementById('touch-bar'),b=bar.getBoundingClientRect();return {fullscreen:!!document.fullscreenElement,canvasRight:c.right,canvasBottom:c.bottom,wrapRight:w.right,barLeft:b.left,barTop:b.top,barVisible:getComputedStyle(bar).display!=='none'}})()`);
      if (layout.fullscreen || layout.canvasRight > layout.wrapRight + 1 ||
          (layout.barVisible && (process.env.H3_VIEWPORT === 'portrait'
            ? layout.canvasBottom > layout.barTop + 1
            : layout.canvasRight > layout.barLeft + 1)))
        throw Error(`New Game changed the canvas layout: ${JSON.stringify(layout)}`);
      const changed = await evaluate(tab, `new Promise(async (resolve,reject)=>{
        try {
          const sources=[${JSON.stringify('data:image/png;base64,' + shot.data)},${JSON.stringify('data:image/png;base64,' + next.data)}];
          const [before,after]=await Promise.all(sources.map(async src=>{const img=new Image();img.src=src;await img.decode();return img}));
          if(before.width!==after.width||before.height!==after.height){resolve(-1);return}
          const canvas=document.createElement('canvas');canvas.width=before.width;canvas.height=before.height;
          const ctx=canvas.getContext('2d');ctx.drawImage(before,0,0);const a=ctx.getImageData(0,0,canvas.width,canvas.height).data;
          ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(after,0,0);const b=ctx.getImageData(0,0,canvas.width,canvas.height).data;
          let count=0;for(let y=${Math.round(bounds.top+bounds.height*.02)};y<${Math.round(bounds.top+bounds.height*.62)};y+=2)
            for(let x=${Math.round(bounds.left+bounds.width*.65)};x<${Math.round(bounds.left+bounds.width*.95)};x+=2){
              const i=(y*canvas.width+x)*4;
              if(Math.abs(a[i]-b[i])+Math.abs(a[i+1]-b[i+1])+Math.abs(a[i+2]-b[i+2])>90)count++;
            }
          resolve(count);
        }catch(error){reject(error)}
      })`);
      if (changed < 1000) throw Error(`New Game menu did not visibly open (${changed} changed samples).`);
      console.log(`New Game menu opened; ${changed} changed button samples. Screenshot: shots/local-new-game.png`);
      if (logs.some(line => /uncaught exception|Pthread .* sent an error/i.test(line)))
        throw Error('Engine worker failed after opening New Game.');
      if (['hotseat-menu', 'hotseat-names', 'hotseat-typed', 'hotseat-lobby', 'hotseat-begin', 'hotseat-first', 'hotseat-pass', 'hotseat-save'].includes(process.env.H3_FLOW)) {
        const multi = { x: Math.round(bounds.left + bounds.width * 649 / 800), y: Math.round(bounds.top + bounds.height * 180 / 600) };
        await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...multi, button: 'none', buttons: 0 });
        await pause(150);
        await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...multi, button: 'left', buttons: 1, clickCount: 1 });
        await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...multi, button: 'left', buttons: 0, clickCount: 1 });
        await pause(5000);
        const hotseatMenu = await tab.send('Page.captureScreenshot', { format: 'png' });
        await writeFile('shots/local-hotseat-menu.png', Buffer.from(hotseatMenu.data, 'base64'));
        console.log('Multiplayer menu captured locally. Screenshot: shots/local-hotseat-menu.png');
        console.log(`Recent engine logs: ${logs.slice(-12).join(' | ')}`);
        if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:/i.test(line)))
          throw Error('Engine worker failed while opening Multiplayer.');
        if (['hotseat-names', 'hotseat-typed', 'hotseat-lobby', 'hotseat-begin', 'hotseat-first', 'hotseat-pass', 'hotseat-save'].includes(process.env.H3_FLOW)) {
          const hotseat = { x: Math.round(bounds.left + bounds.width * 578 / 800), y: Math.round(bounds.top + bounds.height * 178 / 600) };
          await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...hotseat, button: 'none', buttons: 0 });
          await pause(150);
          await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...hotseat, button: 'left', buttons: 1, clickCount: 1 });
          await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...hotseat, button: 'left', buttons: 0, clickCount: 1 });
          await pause(5000);
          const names = await tab.send('Page.captureScreenshot', { format: 'png' });
          await writeFile('shots/local-hotseat-names.png', Buffer.from(names.data, 'base64'));
          console.log('Hot Seat names captured locally. Screenshot: shots/local-hotseat-names.png');
          if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:/i.test(line)))
            throw Error('Engine worker failed while opening Hot Seat names.');
          if (['hotseat-typed', 'hotseat-lobby', 'hotseat-begin', 'hotseat-first', 'hotseat-pass', 'hotseat-save'].includes(process.env.H3_FLOW)) {
            const second = { x: Math.round(bounds.left + bounds.width * 410 / 800), y: Math.round(bounds.top + bounds.height * 219 / 600) };
            await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...second, button: 'none', buttons: 0 });
            await pause(150);
            await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...second, button: 'left', buttons: 1, clickCount: 1 });
            await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...second, button: 'left', buttons: 0, clickCount: 1 });
            await pause(300);
            for (const letter of 'Second')
              await tab.send('Input.dispatchKeyEvent', { type: 'char', text: letter, unmodifiedText: letter });
            await pause(3000);
            const typed = await tab.send('Page.captureScreenshot', { format: 'png' });
            await writeFile('shots/local-hotseat-typed.png', Buffer.from(typed.data, 'base64'));
            console.log('Second player name captured locally. Screenshot: shots/local-hotseat-typed.png');
            if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:/i.test(line)))
              throw Error('Engine worker failed during hot-seat name entry.');
            if (['hotseat-lobby', 'hotseat-begin', 'hotseat-first', 'hotseat-pass', 'hotseat-save'].includes(process.env.H3_FLOW)) {
              const accept = { x: Math.round(bounds.left + bounds.width * 343 / 800), y: Math.round(bounds.top + bounds.height * 450 / 600) };
              await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...accept, button: 'none', buttons: 0 });
              await pause(150);
              await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...accept, button: 'left', buttons: 1, clickCount: 1 });
              await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...accept, button: 'left', buttons: 0, clickCount: 1 });
              await pause(12000);
              const lobby = await tab.send('Page.captureScreenshot', { format: 'png' });
              await writeFile('shots/local-hotseat-lobby.png', Buffer.from(lobby.data, 'base64'));
              console.log('Hot Seat scenario lobby captured locally. Screenshot: shots/local-hotseat-lobby.png');
              console.log(`Hot-seat connection logs: ${logs.filter(line=>/Player joined lobby|Connection established|Function not implemented|uncaught exception|RuntimeError:/i.test(line)).slice(-8).join(' | ')}`);
              if (!logs.some(line => line.includes('Player joined lobby')))
                throw Error('Hot Seat did not connect its local scenario lobby.');
              if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:/i.test(line)))
                throw Error('Engine worker failed while opening hot-seat lobby.');
              if (['hotseat-begin', 'hotseat-first', 'hotseat-pass', 'hotseat-save'].includes(process.env.H3_FLOW)) {
                const begin = { x: Math.round(bounds.left + bounds.width * 490 / 800), y: Math.round(bounds.top + bounds.height * 558 / 600) };
                await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...begin, button: 'none', buttons: 0 });
                await pause(150);
                await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...begin, button: 'left', buttons: 1, clickCount: 1 });
                await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...begin, button: 'left', buttons: 0, clickCount: 1 });
                await pause(45000);
                const game = await tab.send('Page.captureScreenshot', { format: 'png' });
                await writeFile('shots/local-hotseat-begin.png', Buffer.from(game.data, 'base64'));
                const humans = logs.filter(line => line.includes('will be lead by human'));
                console.log(`Hot Seat began with ${humans.length} local human interface(s). Screenshot: shots/local-hotseat-begin.png`);
                if (onlineCreate) {
                  const colors = await evaluate(tab, `window.__h3TurnSeats?.[0]`);
                  if (humans.length !== 1 || !humans[0].includes('Player red') || JSON.stringify(colors) !== '[0,1]')
                    throw Error(`Online creator did not keep only Red local: ${JSON.stringify({humans,colors})}`);
                } else if (humans.length < 2)
                  throw Error(`Hot Seat did not assign two human players: ${logs.slice(-10).join(' | ')}`);
                if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:/i.test(line)))
                  throw Error('Engine worker failed after starting Hot Seat.');
                if (['hotseat-first', 'hotseat-pass', 'hotseat-save'].includes(process.env.H3_FLOW)) {
                  const acceptTurn = { x: Math.round(bounds.left + bounds.width * 400 / 800), y: Math.round(bounds.top + bounds.height * 400 / 600) };
                  await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...acceptTurn, button: 'none', buttons: 0 });
                  await pause(150);
                  await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...acceptTurn, button: 'left', buttons: 1, clickCount: 1 });
                  await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...acceptTurn, button: 'left', buttons: 0, clickCount: 1 });
                  await pause(5000);
                  const first = await tab.send('Page.captureScreenshot', { format: 'png' });
                  await writeFile('shots/local-hotseat-first.png', Buffer.from(first.data, 'base64'));
                  console.log('First hot-seat turn accepted locally. Screenshot: shots/local-hotseat-first.png');
                  if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:/i.test(line)))
                    throw Error('Engine worker failed after accepting first hot-seat turn.');
                  if (process.env.H3_FLOW === 'hotseat-save') {
                    const story = { x: Math.round(bounds.left + bounds.width * 400 / 800), y: Math.round(bounds.top + bounds.height * 415 / 600) };
                    await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...story, button: 'none', buttons: 0 });
                    await pause(150);
                    await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...story, button: 'left', buttons: 1, clickCount: 1 });
                    await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...story, button: 'left', buttons: 0, clickCount: 1 });
                    await pause(2000);
                    await evaluate(tab, `[...document.querySelectorAll('#touch-bar button')].find(button=>button.textContent==='Save').click()`);
                    await pause(3000);
                    const save = { x: Math.round(bounds.left + bounds.width * 490 / 800), y: Math.round(bounds.top + bounds.height * 558 / 600) };
                    await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...save, button: 'none', buttons: 0 });
                    await pause(150);
                    await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...save, button: 'left', buttons: 1, clickCount: 1 });
                    await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...save, button: 'left', buttons: 0, clickCount: 1 });
                    const saves = await waitFor(async () => {
                      const list = await evaluate(tab, `import('/saves.js').then(m=>m.listSaves())`);
                      return list.find(entry => entry.name === 'NEWGAME.vsgm1' && entry.size > 0);
                    }, 90000, 'two-human native save');
                    const encoded = await evaluate(tab, `import('/saves.js').then(async m=>{
                      const file=await m.exportSave('NEWGAME.vsgm1'), bytes=new Uint8Array(await file.arrayBuffer());
                      let binary='';for(let i=0;i<bytes.length;i+=8192)
                        binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
                      return btoa(binary);
                    })`);
                    await writeFile('shots/turn-pass-source.vsgm1', Buffer.from(encoded, 'base64'));
                    console.log(`Two-human source save stored locally: ${saves.size} bytes.`);
                  }
                  if (process.env.H3_FLOW === 'hotseat-pass') {
                    const story = { x: Math.round(bounds.left + bounds.width * 400 / 800), y: Math.round(bounds.top + bounds.height * 415 / 600) };
                    await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...story, button: 'none', buttons: 0 });
                    await pause(150);
                    await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...story, button: 'left', buttons: 1, clickCount: 1 });
                    await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...story, button: 'left', buttons: 0, clickCount: 1 });
                    await pause(2000);
                    await evaluate(tab, `[...document.querySelectorAll('#touch-bar button')].find(button=>button.textContent==='End turn').click()`);
                    await pause(2000);
                    const confirm = { x: Math.round(bounds.left + bounds.width * 355 / 800), y: Math.round(bounds.top + bounds.height * 350 / 600) };
                    await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...confirm, button: 'none', buttons: 0 });
                    await pause(150);
                    await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...confirm, button: 'left', buttons: 1, clickCount: 1 });
                    await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...confirm, button: 'left', buttons: 0, clickCount: 1 });
                    await pause(20000);
                    const passed = await tab.send('Page.captureScreenshot', { format: 'png' });
                    await writeFile('shots/local-hotseat-pass.png', Buffer.from(passed.data, 'base64'));
                    console.log('Second hot-seat privacy screen captured locally. Screenshot: shots/local-hotseat-pass.png');
                    const bluePixels = await evaluate(tab, `new Promise(async (resolve,reject)=>{
                      try {
                        const img=new Image();img.src=${JSON.stringify('data:image/png;base64,' + passed.data)};await img.decode();
                        const canvas=document.createElement('canvas');canvas.width=img.width;canvas.height=img.height;
                        const ctx=canvas.getContext('2d');ctx.drawImage(img,0,0);
                        const r=document.getElementById('canvas').getBoundingClientRect();let count=0;
                        for(let y=r.top+r.height*280/600;y<r.top+r.height*340/600;y+=2)
                          for(let x=r.left+r.width*370/800;x<r.left+r.width*430/800;x+=2){
                            const [red,green,blue]=ctx.getImageData(Math.floor(x),Math.floor(y),1,1).data;
                            if(blue>red+35 && blue>green+25 && blue>95)count++;
                          }
                        resolve(count);
                      }catch(error){reject(error)}
                    })`);
                    if (bluePixels < 20) throw Error(`Second player's blue privacy flag was not visible (${bluePixels} samples).`);
                    console.log(`Second player's blue privacy flag visible (${bluePixels} samples).`);
                    if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:/i.test(line)))
                      throw Error('Engine worker failed while passing the hot-seat turn.');
                  }
                }
              }
            }
          }
        }
      }
      if (['scenario', 'begin', 'save-dialog', 'save', 'load-dialog', 'load-menu', 'load-list', 'load', 'turn-dialog', 'turn'].includes(process.env.H3_FLOW)) {
        const rect = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
        const single = { x: Math.round(rect.left + rect.width * 649 / 800), y: Math.round(rect.top + rect.height * 65 / 600) };
        await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...single, button: 'none', buttons: 0 });
        await pause(150);
        await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...single, button: 'left', buttons: 1, clickCount: 1 });
        await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...single, button: 'left', buttons: 0, clickCount: 1 });
        await pause(10000);
        const scenario = await tab.send('Page.captureScreenshot', { format: 'png' });
        await writeFile('shots/local-scenario.png', Buffer.from(scenario.data, 'base64'));
        console.log(`Single Scenario screen captured locally. Screenshot: shots/local-scenario.png`);
        if (!logs.some(line => line.includes('Player joined lobby')))
          throw Error(`Internal scenario lobby did not connect: ${logs.slice(-5).join(' | ')}`);
        console.log('Internal scenario lobby connected.');
        if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:|memory access out of bounds/i.test(line)))
          throw Error('Engine worker failed while opening Single Scenario.');
        if (['begin', 'save-dialog', 'save', 'load-dialog', 'load-menu', 'load-list', 'load', 'turn-dialog', 'turn'].includes(process.env.H3_FLOW)) {
          const rect = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
          const begin = { x: Math.round(rect.left + rect.width * 490 / 800), y: Math.round(rect.top + rect.height * 558 / 600) };
          await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...begin, button: 'none', buttons: 0 });
          await pause(150);
          await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...begin, button: 'left', buttons: 1, clickCount: 1 });
          await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...begin, button: 'left', buttons: 0, clickCount: 1 });
          await pause(45000);
          const adventure = await tab.send('Page.captureScreenshot', { format: 'png' });
          await writeFile('shots/local-adventure.png', Buffer.from(adventure.data, 'base64'));
          console.log(`Begin screen captured locally. Screenshot: shots/local-adventure.png`);
          if (!logs.some(line => line.includes('Player red will be lead by human')))
            throw Error(`Adventure did not assign the human player: ${logs.slice(-10).join(' | ')}`);
          console.log('Adventure assigned the red player to a human.');
          if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:|memory access out of bounds/i.test(line)))
            throw Error('Engine worker failed after pressing Begin.');
          if (['save-dialog', 'save', 'load-dialog', 'load-menu', 'load-list', 'load', 'turn-dialog', 'turn'].includes(process.env.H3_FLOW)) {
            const rect = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
            const okay = { x: Math.round(rect.left + rect.width * 400 / 800), y: Math.round(rect.top + rect.height * 415 / 600) };
            await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...okay, button: 'none', buttons: 0 });
            await pause(150);
            await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...okay, button: 'left', buttons: 1, clickCount: 1 });
            await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...okay, button: 'left', buttons: 0, clickCount: 1 });
            await pause(3000);
            const ready = await tab.send('Page.captureScreenshot', { format: 'png' });
            await writeFile('shots/local-adventure-ready.png', Buffer.from(ready.data, 'base64'));
            console.log('Story dialog dismissed; captured local adventure view.');
            if (['turn-dialog', 'turn'].includes(process.env.H3_FLOW)) {
              await evaluate(tab, `[...document.querySelectorAll('#touch-bar button')].find(button=>button.textContent==='End turn').click()`);
              await pause(3000);
              const reminder = await tab.send('Page.captureScreenshot', { format: 'png' });
              await writeFile('shots/local-turn-reminder.png', Buffer.from(reminder.data, 'base64'));
              console.log('End turn response captured locally. Screenshot: shots/local-turn-reminder.png');
              if (process.env.H3_FLOW === 'turn') {
                const rect = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
                const yes = { x: Math.round(rect.left + rect.width * 355 / 800), y: Math.round(rect.top + rect.height * 350 / 600) };
                await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...yes, button: 'none', buttons: 0 });
                await pause(150);
                await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...yes, button: 'left', buttons: 1, clickCount: 1 });
                await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...yes, button: 'left', buttons: 0, clickCount: 1 });
                await pause(60000);
                const afterTurn = await tab.send('Page.captureScreenshot', { format: 'png' });
                await writeFile('shots/local-turn-ended.png', Buffer.from(afterTurn.data, 'base64'));
                console.log(`Turn result captured locally. Screenshot: shots/local-turn-ended.png`);
                const changed = await evaluate(tab, `new Promise(async (resolve,reject)=>{
                  try {
                    const images=await Promise.all([${JSON.stringify('data:image/png;base64,' + reminder.data)},${JSON.stringify('data:image/png;base64,' + afterTurn.data)}].map(async src=>{const img=new Image();img.src=src;await img.decode();return img}));
                    const canvas=document.createElement('canvas');canvas.width=images[0].width;canvas.height=images[0].height;
                    const ctx=canvas.getContext('2d');ctx.drawImage(images[0],0,0);const a=ctx.getImageData(0,0,canvas.width,canvas.height).data;
                    ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(images[1],0,0);const b=ctx.getImageData(0,0,canvas.width,canvas.height).data;
                    const r=document.getElementById('canvas').getBoundingClientRect();let count=0;
                    for(let y=Math.floor(r.top+r.height*180/600);y<r.top+r.height*400/600;y+=3)
                      for(let x=Math.floor(r.left+r.width*200/800);x<r.left+r.width*550/800;x+=3){
                        const i=(y*canvas.width+x)*4;if(Math.abs(a[i]-b[i])+Math.abs(a[i+1]-b[i+1])+Math.abs(a[i+2]-b[i+2])>90)count++;
                      }
                    resolve(count);
                  }catch(error){reject(error)}
                })`);
                if (changed < 500) throw Error(`End turn confirmation did not dismiss (${changed} changed samples).`);
                console.log(`End turn confirmation dismissed (${changed} changed dialog samples).`);
                if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:|memory access out of bounds/i.test(line)))
                  throw Error('Engine worker failed during the adventure turn.');
              }
            }
            if (!['turn-dialog', 'turn'].includes(process.env.H3_FLOW)) {
            await evaluate(tab, `[...document.querySelectorAll('#touch-bar button')].find(button=>button.textContent==='Save').click()`);
            await pause(3000);
            const saving = await tab.send('Page.captureScreenshot', { format: 'png' });
            await writeFile('shots/local-save-dialog.png', Buffer.from(saving.data, 'base64'));
            console.log(`Save screen captured locally. Screenshot: shots/local-save-dialog.png`);
            if (['save', 'load-dialog', 'load-menu', 'load-list', 'load'].includes(process.env.H3_FLOW)) {
              const rect = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
              const save = { x: Math.round(rect.left + rect.width * 490 / 800), y: Math.round(rect.top + rect.height * 558 / 600) };
              await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...save, button: 'none', buttons: 0 });
              await pause(150);
              await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...save, button: 'left', buttons: 1, clickCount: 1 });
              await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...save, button: 'left', buttons: 0, clickCount: 1 });
              const saves = await waitFor(async () => {
                const found = await evaluate(tab, `import('/saves.js').then(m=>m.listSaves())`);
                return found.some(save => save.size > 0) ? found : null;
              }, 90000, 'native VCMI save');
              console.log(`Native saves in browser storage: ${JSON.stringify(saves.map(save=>({name:save.name,size:save.size})))}`);
              const saved = await tab.send('Page.captureScreenshot', { format: 'png' });
              await writeFile('shots/local-saved.png', Buffer.from(saved.data, 'base64'));
              if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:/i.test(line)))
                throw Error('Engine worker failed while saving.');
              if (['load-dialog', 'load-menu', 'load-list', 'load'].includes(process.env.H3_FLOW)) {
                const rect = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
                const okay = { x: Math.round(rect.left + rect.width * 400 / 800), y: Math.round(rect.top + rect.height * 350 / 600) };
                await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...okay, button: 'none', buttons: 0 });
                await pause(150);
                await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...okay, button: 'left', buttons: 1, clickCount: 1 });
                await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...okay, button: 'left', buttons: 0, clickCount: 1 });
                await pause(1500);
                await evaluate(tab, `[...document.querySelectorAll('#touch-bar button')].find(button=>button.textContent==='Load').click()`);
                await pause(3000);
                const loading = await tab.send('Page.captureScreenshot', { format: 'png' });
                await writeFile('shots/local-load-dialog.png', Buffer.from(loading.data, 'base64'));
                console.log(`Load confirmation captured locally. Screenshot: shots/local-load-dialog.png`);
                if (['load-menu', 'load-list', 'load'].includes(process.env.H3_FLOW)) {
                  const rect = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
                  const yes = { x: Math.round(rect.left + rect.width * 360 / 800), y: Math.round(rect.top + rect.height * 350 / 600) };
                  await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...yes, button: 'none', buttons: 0 });
                  await pause(150);
                  await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...yes, button: 'left', buttons: 1, clickCount: 1 });
                  await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...yes, button: 'left', buttons: 0, clickCount: 1 });
                  await pause(5000);
                  const menu = await tab.send('Page.captureScreenshot', { format: 'png' });
                  await writeFile('shots/local-load-menu.png', Buffer.from(menu.data, 'base64'));
                  console.log(`Load menu captured locally. Screenshot: shots/local-load-menu.png`);
                  console.log(`Recent engine logs: ${logs.slice(-12).join(' | ')}`);
                  if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:/i.test(line)))
                    throw Error('Engine worker failed while opening Load Game.');
                  if (['load-list', 'load'].includes(process.env.H3_FLOW)) {
                    const rect = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
                    const single = { x: Math.round(rect.left + rect.width * 649 / 800), y: Math.round(rect.top + rect.height * 65 / 600) };
                    await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...single, button: 'none', buttons: 0 });
                    await pause(150);
                    await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...single, button: 'left', buttons: 1, clickCount: 1 });
                    await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...single, button: 'left', buttons: 0, clickCount: 1 });
                    await pause(10000);
                    const list = await tab.send('Page.captureScreenshot', { format: 'png' });
                    await writeFile('shots/local-load-list.png', Buffer.from(list.data, 'base64'));
                    console.log(`Saved-game list captured locally. Screenshot: shots/local-load-list.png`);
                    console.log(`Recent engine logs: ${logs.slice(-15).join(' | ')}`);
                    if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:/i.test(line)))
                      throw Error('Engine worker failed while listing native saves.');
                    if (process.env.H3_FLOW === 'load') {
                      const rect = await evaluate(tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
                      const load = { x: Math.round(rect.left + rect.width * 490 / 800), y: Math.round(rect.top + rect.height * 558 / 600) };
                      await tab.send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...load, button: 'none', buttons: 0 });
                      await pause(150);
                      await tab.send('Input.dispatchMouseEvent', { type: 'mousePressed', ...load, button: 'left', buttons: 1, clickCount: 1 });
                      await tab.send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...load, button: 'left', buttons: 0, clickCount: 1 });
                      await pause(45000);
                      const reloaded = await tab.send('Page.captureScreenshot', { format: 'png' });
                      await writeFile('shots/local-reloaded.png', Buffer.from(reloaded.data, 'base64'));
                      console.log(`Reloaded screen captured locally. Screenshot: shots/local-reloaded.png`);
                      const humanStarts = logs.filter(line => line.includes('Player red will be lead by human')).length;
                      if (humanStarts < 2)
                        throw Error(`Native save did not start a second adventure (${humanStarts} human player starts).`);
                      console.log(`Native save reopened the adventure (${humanStarts} human player starts).`);
                      if (logs.some(line => /uncaught exception|Pthread .* sent an error|RuntimeError:/i.test(line)))
                        throw Error('Engine worker failed while reloading the native save.');
                    }
                  }
                }
              }
            }
            }
          }
        }
      }
    }
    console.log(`Network methods: ${[...new Set(requests)].join(', ')}`);
    if (requests.some(method => !['GET', 'HEAD'].includes(method))) throw Error('Unexpected network upload request.');
  } finally {
    if (tab) tab.close();
    if (browser) { await browser.send('Browser.close').catch(() => {}); browser.close(); }
    if (chrome) { chrome.kill(); await pause(500); }
    if (server) await server.close();
    if (profile) {
      const safeRoot = resolve(tmpdir()) + sep;
      if (!resolve(profile).startsWith(safeRoot) || !profile.startsWith(join(tmpdir(), 'h3-local-play-')))
        throw Error('Temporary browser profile path escaped its expected directory.');
      await rm(profile, { recursive: true, force: true, maxRetries: 3, retryDelay: 200 });
    }
  }
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
