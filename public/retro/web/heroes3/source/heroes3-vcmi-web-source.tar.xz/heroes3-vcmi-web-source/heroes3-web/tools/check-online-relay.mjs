// Local-only real Worker check. Synthetic profiles and synthetic saves; never live credentials.
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import WebSocket from '../private/local-relay-test/node_modules/ws/wrapper.mjs';
import { TurnRelayClient } from '../web/turn-transfer.js';

const fixtures = JSON.parse(await readFile(new URL('../private/local-invite-fixtures.json', import.meta.url)));
const origin = process.env.H3_TEST_ORIGIN || 'http://127.0.0.1:8814';
const relayURL = process.env.H3_TEST_RELAY || 'ws://127.0.0.1:8810';
const accountsURL = process.env.H3_TEST_ACCOUNTS || 'http://127.0.0.1:8812';
const id = randomBytes(16).toString('hex');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(check, label) {
  for (let attempt = 0; attempt < 400; attempt++) {
    if (check()) return check();
    await delay(25);
  }
  throw Error(`Timed out waiting for ${label}.`);
}
const sockets = [];
async function connect(index, query = '') {
  const ws = new WebSocket(`${relayURL}/invite/heroes3/${id}${query}`,
    ['tg-invite', `tg-auth.${fixtures[index].token}`], { headers: { Origin: origin } });
  sockets.push(ws);
  const state = { seat: null, room: null, client: null, frames: [], messages: [] };
  ws.on('message', (raw, binary) => {
    if (binary) { state.frames.push(raw); state.client?.onFrame(raw); return; }
    let message;
    try { message = JSON.parse(raw.toString()); } catch { return; }
    if (message.type === 'welcome') state.seat = message.seat;
    else if (message.type === 'room') { state.room = message; state.client?.onState(message); }
    else { state.messages.push(message); state.client?.onMessage(message); }
  });
  await new Promise((resolve, reject) => {
    ws.once('open', resolve); ws.once('error', reject);
    ws.once('unexpected-response', (_, response) => reject(Error(`HTTP ${response.statusCode}`)));
  });
  await waitFor(() => state.seat !== null && state.room, 'real relay welcome');
  state.client = new TurnRelayClient({ seat: state.seat, timeoutMs: 10000,
    send: message => {
      if (ws.readyState !== WebSocket.OPEN || ws.bufferedAmount > 256000) return false;
      ws.send(message instanceof ArrayBuffer ? Buffer.from(message) : JSON.stringify(message));
      return true;
    },
    onStale: () => { state.stale = true; },
  });
  state.client.onState(state.room);
  return { ws, state };
}

try {
  const accountURL = `${accountsURL}/api/private/heroes3/manifest`;
  const allowed = await fetch(accountURL, { headers: { Authorization: `Bearer ${fixtures[0].token}` } });
  assert.equal(allowed.status, 200, 'synthetic full profile can read local fake manifest');
  assert.equal(allowed.headers.get('cache-control'), 'private, no-store');
  assert.deepEqual((await allowed.json()).files, []);
  const denied = await fetch(accountURL, { headers: { Authorization: `Bearer ${fixtures[8].token}` } });
  assert.equal(denied.status, 403, 'synthetic basic profile is refused');
  const red = await connect(0, '?host=1&players=2&bot=0');
  assert.equal(red.state.seat, 0);
  assert.equal(red.state.room.botMinutes, 0);
  const blue = await connect(1);
  assert.equal(blue.state.seat, 1);
  await waitFor(() => red.state.room.players.length === 2, 'two seats');
  await assert.rejects(connect(8), /HTTP 403/);
  const nativeSaves = process.env.H3_NATIVE_SAVES === '1';
  const first = nativeSaves
    ? new Uint8Array(await readFile(new URL('../shots/turn-pass-handoff.vsgm1', import.meta.url)))
    : new Uint8Array(711626);
  if (!nativeSaves) for (let i = 0; i < first.length; i++) first[i] = i % 251;
  red.state.client.runningLease = red.state.room.lease;
  const sent = await red.state.client.upload({ save: new Blob([first]),
    lease: red.state.room.lease, phase: 0, saveSeat: 1, nextSeat: 1,
    colors: [0, 1], order: [0, 1] });
  assert.equal(sent.revision, 1);
  await waitFor(() => blue.state.room.holder === 1, 'blue lease');
  assert.equal(red.state.stale, true);
  const received = await blue.state.client.load({ lease: blue.state.room.lease, expectedColor: 1 });
  assert.deepEqual(new Uint8Array(await received.save.arrayBuffer()), first);
  const second = nativeSaves
    ? new Uint8Array(await readFile(new URL('../shots/turn-pass-back.vsgm1', import.meta.url)))
    : new Uint8Array([4, 5, 6]);
  await blue.state.client.upload({ save: new Blob([second]),
    lease: blue.state.room.lease, phase: 0, saveSeat: 0, nextSeat: 0,
    colors: [0, 1], order: [0, 1] });
  await waitFor(() => red.state.room.holder === 0, 'red lease');
  const returned = await red.state.client.load({ lease: red.state.room.lease, expectedColor: 0 });
  assert.deepEqual(new Uint8Array(await returned.save.arrayBuffer()), second);
  red.ws.send(JSON.stringify({ type: 'control', lease: red.state.room.lease, viewer: 1, controller: 1 }));
  await waitFor(() => blue.state.room.viewer === 1 && blue.state.room.controller === 1, 'battle control grant');
  const frame = Buffer.from([1, 0xff, 0xd8, 0xff, 0xd9]);
  red.ws.send(frame);
  await waitFor(() => blue.state.frames.some(value => value.equals(frame)), 'private battle frame');
  const frameCount = blue.state.frames.filter(value => value[0] === 1).length;
  red.ws.send(Buffer.alloc(200002, 1));
  await delay(150);
  assert.equal(blue.state.frames.filter(value => value[0] === 1).length, frameCount,
    'relay drops oversized battle frames');
  blue.ws.send(JSON.stringify({ type: 'input', event: 'down', x: .5, y: .5, button: 0 }));
  await waitFor(() => red.state.messages.some(value => value.type === 'input' && value.seat === 1), 'remote battle input');
  const acceptedInputs = red.state.messages.filter(value => value.type === 'input').length;
  blue.ws.send(JSON.stringify({ type: 'input', event: 'down', x: 1.5, y: .5, button: 0 }));
  await delay(150);
  assert.equal(red.state.messages.filter(value => value.type === 'input').length, acceptedInputs,
    'relay drops out-of-bounds battle input');
  red.ws.send(JSON.stringify({ type: 'control', lease: red.state.room.lease, viewer: 1, controller: -1 }));
  await waitFor(() => blue.state.room.controller === -1, 'battle control revoke');
  const count = red.state.messages.filter(value => value.type === 'input').length;
  blue.ws.send(JSON.stringify({ type: 'input', event: 'up', x: .5, y: .5, button: 0 }));
  await delay(150);
  assert.equal(red.state.messages.filter(value => value.type === 'input').length, count,
    'viewer cannot inject input after control is revoked');
  console.log(`PASS local Heroes III relay (${nativeSaves ? 'owner-local native saves' : 'synthetic saves'}): full seats, basic 403, multi-part handoff, SHA-256, stale lease, blue-to-red return.`);
  console.log('PASS local battle stream: one viewer, bounded frame forwarding, input grant and revoke.');
} finally {
  for (const socket of sockets) try { socket.close(); } catch {}
}
