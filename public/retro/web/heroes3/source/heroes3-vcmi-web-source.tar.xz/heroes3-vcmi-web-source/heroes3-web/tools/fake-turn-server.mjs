// In-memory TURN-GAMES.md relay fixture. Synthetic saves and fake seats only.
import { encodePart, decodePart, PART_BYTES } from '../web/turn-transfer.js';

const MAX_SAVE = 16 * 1024 * 1024;
const copy = bytes => bytes.slice().buffer;

export class FakeTurnRelay {
  constructor(capacity = 2) {
    this.capacity = capacity;
    this.holder = 0;
    this.lease = 1;
    this.active = 0;
    this.revision = 0;
    this.checkpoint = null;
    this.order = null;
    this.upload = null;
    this.links = new Map();
    this.corruptLoadPart = -1;
  }

  room() {
    return {
      type: 'room', game: 'heroes3', mode: 'local', capacity: this.capacity,
      players: Array.from({ length: this.capacity }, (_, seat) =>
        ({ seat, online: this.links.has(seat) })),
      holder: this.holder, lease: this.lease, active: this.active,
      order: this.order, checkpointPhase: this.checkpoint?.phase ?? null,
      savedAt: this.checkpoint ? Date.now() : null,
      botMinutes: null, viewer: -1, controller: -1, now: Date.now(),
    };
  }

  publish() { for (const link of this.links.values()) link.client?.onState(this.room()); }
  connect(seat) {
    if (!Number.isInteger(seat) || seat < 0 || seat >= this.capacity) throw Error('Invalid fake seat.');
    const link = {
      seat,
      client: null,
      send: message => {
        if (!this.links.has(seat)) return false;
        queueMicrotask(() => this.receive(link, message));
        return true;
      },
      bind: client => { link.client = client; client.onState(this.room()); this.publish(); },
      close: () => { this.links.delete(seat); this.publish(); },
    };
    this.links.set(seat, link);
    this.publish();
    return link;
  }

  reply(link, value) { queueMicrotask(() => link.client?.onMessage(value)); }
  refuse(link, id, error) { this.reply(link, { type: 'refused', id, error }); }

  receive(link, message) {
    if (!this.links.has(link.seat)) return;
    if (message instanceof ArrayBuffer) return this.receivePart(link, message);
    if (message?.type === 'load') {
      if (link.seat !== this.holder || !this.checkpoint) return;
      const bytes = this.checkpoint.bytes;
      const parts = Math.ceil(bytes.length / PART_BYTES);
      for (let part = 0; part < parts; part++) {
        const data = bytes.slice(part * PART_BYTES, (part + 1) * PART_BYTES);
        if (part === this.corruptLoadPart) data[0] ^= 255;
        const frame = encodePart({
          type: 'save', lease: this.lease, part, parts,
          checkpoint: {
            phase: this.checkpoint.phase, seat: this.checkpoint.seat,
            meta: this.checkpoint.meta, size: bytes.length,
            revision: this.revision,
          },
        }, data);
        queueMicrotask(() => link.client?.onFrame(copy(new Uint8Array(frame))));
      }
    } else if (message?.type === 'claim') {
      if (this.checkpoint?.phase !== 2 || link.seat === this.holder ||
          this.links.has(this.holder)) return;
      this.holder = link.seat; this.lease++;
      this.publish();
    }
  }

  receivePart(link, frame) {
    let head, bytes;
    try { ({ header: head, bytes } = decodePart(frame)); }
    catch { return; }
    if (typeof head?.id !== 'string' || head.id.length > 40) return;
    if (link.seat !== this.holder || head.lease !== this.lease)
      return this.refuse(link, head.id, 'Not your turn to save.');
    if (head.part === 0) {
      if (!['save', 'handoff'].includes(head.type) ||
          ![0, 1, 2].includes(head.phase) ||
          !Number.isInteger(head.size) || head.size < 1 || head.size > MAX_SAVE ||
          head.parts !== Math.ceil(head.size / PART_BYTES) ||
          !Number.isInteger(head.seat) || head.seat < -1 || head.seat >= this.capacity ||
          (head.type === 'handoff' && (!Number.isInteger(head.next) ||
            head.next < 0 || head.next >= this.capacity || head.next === link.seat)) ||
          (head.meta != null && (typeof head.meta !== 'object' ||
            JSON.stringify(head.meta).length > 1024)))
        return this.refuse(link, head.id, 'Bad save header.');
      this.upload = { id: head.id, seat: link.seat, lease: this.lease, head,
        part: 0, chunks: [] };
    }
    const job = this.upload;
    if (!job || job.id !== head.id || job.seat !== link.seat ||
        job.lease !== this.lease || head.part !== job.part)
      return this.refuse(link, head.id, 'Upload out of order; start again.');
    const expected = job.part === job.head.parts - 1
      ? job.head.size - job.part * PART_BYTES : PART_BYTES;
    if (bytes.length !== expected) {
      this.upload = null;
      return this.refuse(link, head.id, 'Wrong part size.');
    }
    job.chunks.push(bytes.slice());
    job.part++;
    if (job.part < job.head.parts)
      return this.reply(link, { type: 'part', id: head.id, part: head.part });
    const all = new Uint8Array(job.head.size);
    let offset = 0;
    for (const chunk of job.chunks) { all.set(chunk, offset); offset += chunk.length; }
    this.checkpoint = { phase: head.phase, seat: head.seat, meta: head.meta, bytes: all };
    this.revision++;
    this.order = head.order ?? this.order;
    if (head.type === 'handoff') {
      this.holder = head.next; this.active = head.next; this.lease++;
    } else if (head.seat >= 0) this.active = head.seat;
    this.upload = null;
    this.reply(link, { type: 'saved', id: head.id, revision: this.revision });
    queueMicrotask(() => {
      if (head.type === 'handoff') this.links.get(head.next)?.client?.onMessage({
        type: 'your-turn', game: 'heroes3', id: 'a'.repeat(32),
      });
      this.publish();
    });
  }
}

export const createFakeTurnRelay = capacity => new FakeTurnRelay(capacity);
