#!/usr/bin/env bash
ramgate() {
  local free
  while :; do
    free="$(powershell -NoProfile -Command '(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1MB' 2>/dev/null | tr -d '\r' | tail -n 1)"
    if [[ ! "$free" =~ ^[0-9]+([.][0-9]+)?$ ]] || awk -v x="$free" 'BEGIN { exit !(x+0 < 0.1) }'; then
      # Some managed shells deny CIM; the same Windows memory counter is available through .NET.
      free="$(powershell -NoProfile -Command 'Add-Type -AssemblyName Microsoft.VisualBasic; ([Microsoft.VisualBasic.Devices.ComputerInfo]::new()).AvailablePhysicalMemory/1GB' | tr -d '\r' | tail -n 1)"
    fi
    if awk -v x="$free" 'BEGIN { exit !(x+0 >= 2.5) }'; then break; fi
    printf 'Free RAM %s GB; waiting for 2.5 GB...\n' "$free" >&2
    sleep 120
  done
  JOBS=1
  export JOBS EMCC_CORES="$JOBS"
  printf 'Free RAM %s GB; JOBS=%s\n' "$free" "$JOBS"
}
