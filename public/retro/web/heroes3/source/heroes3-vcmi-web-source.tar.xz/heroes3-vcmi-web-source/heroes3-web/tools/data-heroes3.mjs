// Stage the owner's Heroes III Complete CD data for LOCAL testing only.
// Reads the verified CD images in Classic Games (never modifies them) and writes into gitignored private/.
// Step 1 (this script): raw MODE1/2352 .bin -> plain 2048-byte-sector .iso, streamed (low memory).
// Original data never goes into git, the public site or any upload. See docs/LEGAL.md.
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const CD = "E:/AI/Games/Classic Games/Library/Heroes of Might and Magic III/CD";
const OUT = path.resolve(
  import.meta.dirname,
  "..",
  "private",
  "heroes3",
  "_iso",
);
fs.mkdirSync(OUT, { recursive: true });

const RAW = 2352,
  USER = 2048,
  HEADER = 16;
for (const disc of [1, 2]) {
  const src = path.join(
    CD,
    `Heroes of Might and Magic III Complete - Collector's Edition (Europe) (Disc ${disc}).bin`,
  );
  const dst = path.join(OUT, `disc${disc}.iso`);
  const size = fs.statSync(src).size;
  if (size % RAW)
    throw new Error(`${src}: size is not a whole number of 2352-byte sectors`);
  if (fs.existsSync(dst) && fs.statSync(dst).size === (size / RAW) * USER) {
    console.log(`disc${disc}.iso already staged`);
    continue;
  }
  const temp = `${dst}.part-${crypto.randomUUID()}`;
  const fdIn = fs.openSync(src, "r"),
    fdOut = fs.openSync(temp, "wx");
  const batch = 512,
    buf = Buffer.alloc(RAW * batch),
    out = Buffer.alloc(USER * batch);
  try {
    for (let pos = 0; pos < size; pos += buf.length) {
      const needed = Math.min(buf.length, size - pos);
      let read = 0;
      while (read < needed) {
        const n = fs.readSync(fdIn, buf, read, needed - read, pos + read);
        if (!n) throw Error(`disc${disc}: truncated source`);
        read += n;
      }
      const sectors = needed / RAW;
      for (let s = 0; s < sectors; s++) {
        const mode = buf[s * RAW + 15];
        if (mode !== 1)
          throw new Error(
            `disc${disc}: sector ${pos / RAW + s} is mode ${mode}, expected 1`,
          );
        buf.copy(out, s * USER, s * RAW + HEADER, s * RAW + HEADER + USER);
      }
      let written = 0;
      const bytes = sectors * USER;
      while (written < bytes) {
        const n = fs.writeSync(fdOut, out, written, bytes - written);
        if (!n) throw Error(`disc${disc}: output write stalled`);
        written += n;
      }
    }
  } catch (error) {
    fs.closeSync(fdIn);
    fs.closeSync(fdOut);
    fs.rmSync(temp, { force: true });
    throw error;
  }
  fs.closeSync(fdIn);
  fs.closeSync(fdOut);
  fs.renameSync(temp, dst);
  console.log(`disc${disc}.iso staged (${(size / RAW) * USER} bytes)`);
}

// Step 2: unpack. Disc 1 keeps the game in an InstallShield 5 cabinet; disc 2 has Heroes3.snd/.vid in the open.
// Windows' own tar.exe (bsdtar) reads ISO9660; Git Bash's GNU tar does not.
import { execFileSync } from "node:child_process";
const ROOT = path.resolve(OUT, "..");
const TAR = "C:/Windows/System32/tar.exe";
const run = (cmd, args) => execFileSync(cmd, args, { stdio: "inherit" });
fs.mkdirSync(path.join(ROOT, "_cab"), { recursive: true });
fs.mkdirSync(path.join(ROOT, "_disc2"), { recursive: true });
run(TAR, [
  "-xf",
  path.join(OUT, "disc1.iso"),
  "-C",
  path.join(ROOT, "_cab"),
  "_setup/data1.cab",
  "_setup/data1.hdr",
]);
run(TAR, [
  "-xf",
  path.join(OUT, "disc2.iso"),
  "-C",
  path.join(ROOT, "_disc2"),
  "heroes3/Data/Heroes3.snd",
  "heroes3/Data/Heroes3.vid",
]);
const CAB_OUT = path.join(ROOT, `_cabout.part-${crypto.randomUUID()}`);
try {
  run(process.execPath, [
    path.join(import.meta.dirname, "is5-extract.mjs"),
    path.join(ROOT, "_cab/_setup/data1.hdr"),
    path.join(ROOT, "_cab/_setup/data1.cab"),
    CAB_OUT,
  ]);
} catch (error) {
  fs.rmSync(CAB_OUT, { recursive: true, force: true });
  throw error;
}

// Step 3: the layout VCMI reads (Data/, Maps/, Mp3/). Disc 2's larger sound archive goes in as Heroes3-cd2.snd,
// the name VCMI's vcmibuilder gives it; its Heroes3.vid sits beside VIDEO.VID.
const DATA = path.join(ROOT, "data");
const STAGING = path.join(ROOT, `data.part-${crypto.randomUUID()}`);
try {
  for (const dir of ["Data", "Maps", "Mp3"])
    fs.cpSync(path.join(CAB_OUT, dir), path.join(STAGING, dir), {
      recursive: true,
    });
  fs.copyFileSync(
    path.join(ROOT, "_disc2/heroes3/Data/Heroes3.snd"),
    path.join(STAGING, "Data/Heroes3-cd2.snd"),
  );
  fs.copyFileSync(
    path.join(ROOT, "_disc2/heroes3/Data/Heroes3.vid"),
    path.join(STAGING, "Data/Heroes3.vid"),
  );

  // Step 4: SHA-256 of every staged file, used by publish leak checks (no original may appear in a public build).
  const sums = {};
  async function hashFile(file) {
    const hash = crypto.createHash("sha256");
    for await (const chunk of fs.createReadStream(file)) hash.update(chunk);
    return hash.digest("hex");
  }
  async function walk(d) {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) await walk(p);
      else
        sums[path.relative(STAGING, p).replace(/\\/g, "/")] = {
          size: fs.statSync(p).size,
          sha256: await hashFile(p),
        };
    }
  }
  await walk(STAGING);
  const manifest = path.join(ROOT, "sha256.json");
  const manifestTemp = path.join(
    ROOT,
    `sha256.part-${crypto.randomUUID()}.json`,
  );
  fs.writeFileSync(manifestTemp, JSON.stringify(sums, null, 1));
  const backup = path.join(ROOT, `data.backup-${crypto.randomUUID()}`);
  const hadPrevious = fs.existsSync(DATA);
  if (hadPrevious) fs.renameSync(DATA, backup);
  try {
    fs.renameSync(STAGING, DATA);
    fs.renameSync(manifestTemp, manifest);
  } catch (error) {
    fs.rmSync(DATA, { recursive: true, force: true });
    if (hadPrevious) fs.renameSync(backup, DATA);
    fs.rmSync(STAGING, { recursive: true, force: true });
    fs.rmSync(manifestTemp, { force: true });
    throw error;
  }
  if (hadPrevious) fs.rmSync(backup, { recursive: true, force: true });
  const total = Object.values(sums).reduce((a, f) => a + f.size, 0);
  console.log(
    `staged ${Object.keys(sums).length} files, ${(total / 1048576).toFixed(0)} MB, in private/heroes3/data`,
  );
} catch (error) {
  fs.rmSync(STAGING, { recursive: true, force: true });
  fs.rmSync(CAB_OUT, { recursive: true, force: true });
  throw error;
}
fs.rmSync(CAB_OUT, { recursive: true, force: true });
