#include <tbb/parallel_for.h>
#include <tbb/parallel_reduce.h>
#include <tbb/parallel_invoke.h>
#include <tbb/blocked_range2d.h>
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_hash_map.h>
#include <tbb/concurrent_unordered_set.h>
#include <tbb/concurrent_unordered_map.h>
#include <tbb/concurrent_vector.h>
#include <tbb/task_arena.h>
#include <tbb/task_group.h>
#include <tbb/global_control.h>
#include <atomic>
#include <cassert>
#include <string>
struct StringHash { static size_t hash(const std::string& s) { return std::hash<std::string>{}(s); } static bool equal(const std::string& a,const std::string& b) { return a==b; } };
int main() {
  int sum=0;
  tbb::parallel_for(tbb::blocked_range<int>(0,4),[&](auto r){for(int i=r.begin();i<r.end();++i)sum+=i;});
  tbb::parallel_for(0,2,[&](int i){sum+=i;});
  tbb::parallel_for(tbb::blocked_range2d<int>(0,2,1,0,2,1),[&](auto r){sum+=r.rows().end()*r.cols().end();});
  assert(sum==11);
  assert(tbb::parallel_reduce(tbb::blocked_range<int>(0,3),0,[](auto r,int x){for(int i=r.begin();i<r.end();++i)x+=i;return x;},std::plus<int>{})==3);
  tbb::parallel_invoke([&]{++sum;},[&]{++sum;});
  tbb::concurrent_queue<int> q; q.push(4); int x=0; assert(q.try_pop(x)&&x==4);
  tbb::concurrent_hash_map<std::string,int,StringHash> m; {decltype(m)::accessor a; assert(m.insert(a,{"key",3}));a->second=4;a.release();}
  {decltype(m)::const_accessor a; assert(m.find(a,"key")&&a->second==4);}
  {decltype(m)::accessor a; assert(m.find(a,"key"));assert(m.erase(a));}
  tbb::concurrent_unordered_set<int> s; s.insert(1); assert(s.count(1));
  tbb::concurrent_unordered_map<int,int> um; um.insert({1,2}); assert(um.at(1)==2);
  tbb::concurrent_vector<int> v; v.push_back(5); assert(v.front()==5);
  tbb::global_control limit(tbb::global_control::max_allowed_parallelism,2);
  std::atomic<int> done=0; tbb::task_group group; tbb::task_arena arena(2);
  arena.enqueue(group.defer([&]{done=1;}));
  while(done==0) std::this_thread::yield();
  group.run([&]{done=2;}); group.wait(); assert(done==2);
  assert(tbb::this_task_arena::max_concurrency()>=1);
}
