#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/env.sh"
source "$PROJECT_ROOT/tools/ramgate.sh"
out="$PROJECT_ROOT/deps/build/tbb-test"
mkdir -p "$out"
ramgate
em++ "$PROJECT_ROOT/compat/tbb/test/shim_test.cpp" -I"$PROJECT_ROOT/compat/tbb/include" \
  $CXXFLAGS $LDFLAGS -sPTHREAD_POOL_SIZE=2 -o "$out/shim_test.js"
"$PROJECT_ROOT/deps/emsdk/node/24.19.0_64bit/node.exe" "$out/shim_test.js"
echo 'TBB shim test passed.'
