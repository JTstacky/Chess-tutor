import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { TurnRelayClient, encodePart, decodePart, PART_BYTES } from '../web/turn-transfer.js';
import { createFakeTurnRelay } from '../tools/fake-turn-server.mjs';

function seat(relay, number, options = {}) {
  const link = relay.connect(number);
  const client = new TurnRelayClient({
    send: message => link.send(message), seat: number,
    timeoutMs: 1500, idFactory: (() => { let n = 0; return () => `attempt-${number}-${++n}`; })(),
    ...options,
  });
  link.bind(client);
  return { link, client };
}
const bytes = blob => blob.arrayBuffer().then(buffer => new Uint8Array(buffer));
const sha = data => createHash('sha256').update(Buffer.from(data)).digest('hex');

test('relay uses 512000-byte parts, confirms handoff, then loads by lease and seat', async () => {
  const relay = createFakeTurnRelay();
  const red = seat(relay, 0), blue = seat(relay, 1);
  const data = Uint8Array.from({ length: PART_BYTES + 3 }, (_, i) => i % 251);
  const save = new Blob([data]);
  const confirmation = await red.client.upload({
    save, lease: 1, phase: 0, saveSeat: 1, nextSeat: 1,
    colors: [0, 1], order: [0, 1],
  });
  assert.equal(confirmation.revision, 1);
  assert.equal(confirmation.sha256, sha(data));
  assert.equal(relay.holder, 1);
  assert.equal(relay.lease, 2);
  const turn = await blue.client.load({ lease: 2, expectedColor: 1 });
  assert.deepEqual(await bytes(turn.save), data);
  assert.equal(turn.checkpoint.phase, 0);
  assert.deepEqual(turn.checkpoint.meta.colors, [0, 1]);
  assert.equal(turn.checkpoint.revision, 1);
  await assert.rejects(red.client.load({ lease: 1, expectedColor: 0 }), /current lease/);
});

test('relay refuses a wrong seat and stale lease, and a newer lease stops the old runner', async () => {
  const relay = createFakeTurnRelay();
  let stopped = 0;
  const red = seat(relay, 0, { onStale: () => stopped++ });
  const blue = seat(relay, 1);
  red.client.runningLease = 1;
  const replies = [];
  const original = blue.client.onMessage.bind(blue.client);
  blue.client.onMessage = message => { replies.push(message); original(message); };
  blue.link.send(encodePart({
    type: 'save', id: 'wrong-seat', lease: 1, phase: 1, seat: 1,
    part: 0, parts: 1, size: 1, meta: { colors: [0, 1], sha256: sha([7]) },
  }, new Uint8Array([7])));
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.match(replies[0].error, /Not your turn/);
  await red.client.upload({
    save: new Blob([new Uint8Array([3])]), lease: 1, phase: 0,
    saveSeat: 1, nextSeat: 1, colors: [0, 1], order: [0, 1],
  });
  assert.equal(stopped, 1);
  assert.equal(red.client.runningLease, null);
  const stale = [];
  red.client.onMessage = message => stale.push(message);
  red.link.send(encodePart({
    type: 'save', id: 'stale-lease', lease: 1, phase: 1, seat: 0,
    part: 0, parts: 1, size: 1, meta: { colors: [0, 1], sha256: sha([8]) },
  }, new Uint8Array([8])));
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.match(stale[0].error, /Not your turn/);
});

test('corrupt download fails SHA-256, and wrong colour is rejected before import', async () => {
  const relay = createFakeTurnRelay();
  const red = seat(relay, 0), blue = seat(relay, 1);
  const data = Uint8Array.from({ length: PART_BYTES + 1 }, (_, i) => i % 253);
  await red.client.upload({
    save: new Blob([data]), lease: 1, phase: 0,
    saveSeat: 1, nextSeat: 1, colors: [0, 1], order: [0, 1],
  });
  await assert.rejects(blue.client.load({ lease: 2, expectedColor: 0 }), /does not belong/);
  relay.corruptLoadPart = 1;
  await assert.rejects(blue.client.load({ lease: 2, expectedColor: 1 }), /SHA-256 verification/);
});

test('a refused part leaves the local save retryable; phase two can be claimed', async () => {
  const relay = createFakeTurnRelay();
  const red = seat(relay, 0), blue = seat(relay, 1);
  const originalSend = red.link.send;
  let breakFirst = true;
  red.client.send = message => {
    if (breakFirst && message instanceof ArrayBuffer) {
      breakFirst = false;
      return originalSend(message.slice(0, -1));
    }
    return originalSend(message);
  };
  const save = new Blob([new Uint8Array([9, 8, 7])]);
  const input = { save, lease: 1, phase: 2, saveSeat: -1,
    colors: [0, 1], order: [0, 1] };
  await assert.rejects(red.client.upload(input), /Wrong part size/);
  assert.equal(relay.checkpoint, null);
  assert.equal(save.size, 3);
  assert.equal((await red.client.upload(input)).revision, 1);
  red.link.close();
  assert.equal((await blue.client.claim()).holder, 1);
  assert.equal(relay.lease, 2);
  const resumed = await blue.client.load({ lease: 2, expectedColor: 1, allowPhase2: true });
  assert.deepEqual(await bytes(resumed.save), new Uint8Array([9, 8, 7]));
});

test('binary framing is big-endian and rejects invalid headers', () => {
  const frame = encodePart({ type: 'save', part: 0 }, new Uint8Array([5]));
  const view = new DataView(frame);
  assert.equal(new Uint8Array(frame)[0], 2);
  assert.equal(view.getUint32(1, false), new TextEncoder().encode('{"type":"save","part":0}').length);
  assert.equal(decodePart(frame).bytes[0], 5);
  assert.throws(() => decodePart(new Uint8Array([2, 0, 0, 8, 1, 7])), /header/);
});
