import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { Sha256 } from "../web/sha256.js";

test("streamed SHA-256 matches Node across block boundaries", () => {
  for (const size of [0, 1, 55, 56, 63, 64, 65, 4097, 1048577]) {
    const bytes = Uint8Array.from({ length: size }, (_, index) => index * 31 & 255);
    const hash = new Sha256();
    for (let offset = 0; offset < size; offset += 13)
      hash.update(bytes.subarray(offset, offset + 13));
    assert.equal(hash.hex(), createHash("sha256").update(bytes).digest("hex"), `size ${size}`);
  }
});
