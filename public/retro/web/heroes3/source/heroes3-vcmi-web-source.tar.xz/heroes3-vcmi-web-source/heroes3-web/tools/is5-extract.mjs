// Minimal InstallShield 5 cabinet reader (our own code), used only to unpack the owner's Heroes III CD
// (_setup/data1.hdr + data1.cab) into gitignored private/ for local tests. Read-only on its inputs.
// Usage: node tools/is5-extract.mjs <data1.hdr> <data1.cab> <outDir> [--list]
// Format: common header "ISc(" + cab descriptor -> file table (directory names, then file descriptors).
// File data in the .cab is a run of chunks: uint16 LE length + an independent raw-deflate stream.
// Every file is checked against the MD5 stored in its descriptor.
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import crypto from "node:crypto";

const [hdrPath, cabPath, outDir] = process.argv.slice(2);
const listOnly = process.argv.includes("--list");
if (!hdrPath || !cabPath || !outDir) {
  console.error("usage: is5-extract.mjs <hdr> <cab> <outDir> [--list]");
  process.exit(2);
}

const h = fs.readFileSync(hdrPath);
if (h.toString("latin1", 0, 4) !== "ISc(")
  throw new Error("not an InstallShield cabinet header");
const version = h.readUInt32LE(4);
const major =
  version >>> 24 === 1
    ? (version >>> 12) & 0xf
    : version >>> 24 === 2 || version >>> 24 === 4
      ? ((version & 0xffff) / 100) | 0
      : 0;
if (major !== 5)
  throw new Error(
    `InstallShield major version ${major}; this reader handles 5 only`,
  );
const cabDesc = h.readUInt32LE(12);
if (cabDesc > h.length - 0x2c) throw Error("cabinet descriptor outside header");
const ftOffset = h.readUInt32LE(cabDesc + 0x0c);
const dirCount = h.readUInt32LE(cabDesc + 0x1c);
const fileCount = h.readUInt32LE(cabDesc + 0x28);
const base = cabDesc + ftOffset;
if (base > h.length || dirCount + fileCount > Math.floor((h.length - base) / 4))
  throw Error("cabinet file table outside header");
const table = Array.from({ length: dirCount + fileCount }, (_, i) =>
  h.readUInt32LE(base + i * 4),
);
const cstr = (off) => {
  if (off < 0 || off >= h.length)
    throw Error("cabinet string offset outside header");
  const end = h.indexOf(0, off);
  if (end < 0) throw Error("unterminated cabinet string");
  return h.toString("latin1", off, end);
};
const dirs = table
  .slice(0, dirCount)
  .map((o) => cstr(base + o).replace(/\\/g, "/"));

const FILE_SPLIT = 1,
  FILE_OBFUSCATED = 2,
  FILE_COMPRESSED = 4,
  FILE_INVALID = 8;
const files = [];
for (let i = 0; i < fileCount; i++) {
  let p = base + table[dirCount + i];
  if (p > h.length - 58) throw Error("cabinet file descriptor outside header");
  const nameOff = h.readUInt32LE(p);
  p += 4;
  const dirIndex = h.readUInt32LE(p);
  p += 4;
  const flags = h.readUInt16LE(p);
  p += 2;
  const size = h.readUInt32LE(p);
  p += 4;
  const csize = h.readUInt32LE(p);
  p += 4;
  p += 0x14;
  const dataOffset = h.readUInt32LE(p);
  p += 4;
  const md5 = h.toString("hex", p, p + 16);
  if (flags & FILE_INVALID) continue;
  if (dirIndex !== 0xffffffff && dirIndex >= dirs.length)
    throw Error("invalid cabinet directory index");
  files.push({
    name: cstr(base + nameOff),
    dir: dirs[dirIndex] ?? "",
    flags,
    size,
    csize,
    dataOffset,
    md5,
  });
}

if (listOnly) {
  for (const f of files)
    console.log(
      `${f.size}\t${f.dir ? f.dir + "/" : ""}${f.name}\tflags=${f.flags}`,
    );
  console.log(`${files.length} files, ${dirs.length} directories`);
  process.exit(0);
}

const cab = fs.openSync(cabPath, "r");
const cabSize = fs.fstatSync(cab).size;
fs.mkdirSync(outDir, { recursive: true });
const root = fs.realpathSync(outDir);
function safeRelative(dir, name) {
  if (dir.startsWith("/") || dir.startsWith("\\"))
    throw Error(`unsafe cabinet path: ${dir}`);
  const parent = dir.replace(/\\/g, "/").replace(/\/+$/, "");
  const joined = `${parent ? parent + "/" : ""}${name}`.replace(/\\/g, "/");
  if (
    !joined ||
    joined.startsWith("/") ||
    /^[A-Za-z]:/.test(joined) ||
    joined.includes("\0")
  )
    throw Error(`unsafe cabinet path: ${joined}`);
  const parts = joined.split("/");
  if (
    parts.some(
      (part) => !part || part === "." || part === ".." || part.includes(":"),
    )
  )
    throw Error(`unsafe cabinet path: ${joined}`);
  return parts.join("/");
}
function readExactly(fd, buffer, length, position) {
  let done = 0;
  while (done < length) {
    const n = fs.readSync(fd, buffer, done, length - done, position + done);
    if (!n) throw Error("truncated cabinet data");
    done += n;
  }
}
function writeExactly(fd, buffer, length) {
  let done = 0;
  while (done < length) {
    const n = fs.writeSync(fd, buffer, done, length - done);
    if (!n) throw Error("cabinet output write stalled");
    done += n;
  }
}
const used = new Set();
let ok = 0;
try {
  for (const f of files) {
    if (f.flags & (FILE_SPLIT | FILE_OBFUSCATED))
      throw new Error(`${f.name}: split/obfuscated files not supported`);
    let rel = safeRelative(f.dir, f.name);
    for (let n = 2; used.has(rel.toLowerCase()); n++)
      rel = safeRelative(
        f.dir,
        `${path.parse(f.name).name}~${n}${path.parse(f.name).ext}`,
      );
    used.add(rel.toLowerCase());
    const dst = path.resolve(root, rel);
    const parent = path.dirname(dst);
    fs.mkdirSync(parent, { recursive: true });
    const actualParent = fs.realpathSync(parent);
    const relativeParent = path.relative(root, actualParent);
    if (
      relativeParent === ".." ||
      relativeParent.startsWith(`..${path.sep}`) ||
      path.isAbsolute(relativeParent)
    )
      throw Error(`unsafe cabinet path: ${rel}`);
    if (fs.existsSync(dst) && fs.lstatSync(dst).isSymbolicLink())
      throw Error(`unsafe cabinet path: ${rel}`);
    if (f.dataOffset > cabSize || f.csize > cabSize - f.dataOffset)
      throw Error(`${rel}: data outside cabinet`);
    const temp = `${dst}.part-${crypto.randomUUID()}`;
    const out = fs.openSync(temp, "wx");
    const hash = crypto.createHash("md5");
    let pos = f.dataOffset,
      left = f.csize,
      written = 0;
    try {
      try {
        if (f.flags & FILE_COMPRESSED) {
          const len = Buffer.alloc(2);
          while (left > 0) {
            if (left < 2) throw Error(`${rel}: truncated chunk header`);
            readExactly(cab, len, 2, pos);
            pos += 2;
            left -= 2;
            const n = len.readUInt16LE(0);
            if (!n || n > left) throw Error(`${rel}: invalid chunk length`);
            const chunk = Buffer.alloc(n);
            readExactly(cab, chunk, n, pos);
            pos += n;
            left -= n;
            const plain = zlib.inflateRawSync(chunk, {
              finishFlush: zlib.constants.Z_SYNC_FLUSH,
              maxOutputLength: Math.max(
                1,
                Math.min(f.size - written, 16 * 1048576),
              ),
            });
            if (plain.length > f.size - written)
              throw Error(`${rel}: decompressed size exceeds descriptor`);
            hash.update(plain);
            writeExactly(out, plain, plain.length);
            written += plain.length;
          }
        } else {
          const buf = Buffer.alloc(1 << 20);
          while (left > 0) {
            const n = fs.readSync(cab, buf, 0, Math.min(buf.length, left), pos);
            if (!n) throw Error(`${rel}: truncated cabinet data`);
            pos += n;
            left -= n;
            hash.update(buf.subarray(0, n));
            writeExactly(out, buf, n);
            written += n;
          }
        }
      } finally {
        fs.closeSync(out);
      }
      const got = hash.digest("hex");
      if (written !== f.size)
        throw new Error(`${rel}: size ${written}, expected ${f.size}`);
      if (f.md5 !== "00000000000000000000000000000000" && got !== f.md5)
        throw new Error(`${rel}: MD5 mismatch`);
      fs.renameSync(temp, dst);
      ok++;
    } catch (error) {
      fs.rmSync(temp, { force: true });
      throw error;
    }
  }
} finally {
  fs.closeSync(cab);
}
console.log(`extracted ${ok} files, sizes and MD5s verified`);
