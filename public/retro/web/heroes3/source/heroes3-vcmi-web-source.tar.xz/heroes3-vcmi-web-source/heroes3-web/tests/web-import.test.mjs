import test from "node:test";
import assert from "node:assert/strict";
import { zipEntries } from "../web/unzip.js";
import {
  planImport,
  readManifest,
  safeGamePath,
  writeEntriesToOpfs,
} from "../web/data-import.js";

function zipWithName(name) {
  const filename = Buffer.from(name);
  const body = Buffer.from("fake");
  let crc = ~0;
  for (const byte of body) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++)
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  }
  crc = ~crc >>> 0;
  const local = Buffer.alloc(30);
  local.writeUInt32LE(0x04034b50);
  local.writeUInt32LE(crc, 14);
  local.writeUInt32LE(body.length, 18);
  local.writeUInt32LE(body.length, 22);
  local.writeUInt16LE(filename.length, 26);
  const central = Buffer.alloc(46);
  central.writeUInt32LE(0x02014b50);
  central.writeUInt32LE(crc, 16);
  central.writeUInt32LE(body.length, 20);
  central.writeUInt32LE(body.length, 24);
  central.writeUInt16LE(filename.length, 28);
  const offset = local.length + filename.length + body.length;
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50);
  end.writeUInt16LE(1, 8);
  end.writeUInt16LE(1, 10);
  end.writeUInt32LE(central.length + filename.length, 12);
  end.writeUInt32LE(offset, 16);
  return new Blob([local, filename, body, central, filename, end]);
}

function missing() {
  return new DOMException("Missing entry", "NotFoundError");
}

class MemoryFile {
  data = new Uint8Array();
  async getFile() {
    return new Blob([this.data]);
  }
  async createWritable() {
    const chunks = [];
    return new WritableStream({
      write(chunk) {
        chunks.push(new Uint8Array(chunk));
      },
      close: () => {
        this.data = new Uint8Array(
          Buffer.concat(chunks.map((chunk) => Buffer.from(chunk))),
        );
      },
    });
  }
}

class MemoryDirectory {
  children = new Map();
  kind = "directory";
  async getDirectoryHandle(name, { create = false } = {}) {
    let child = this.children.get(name);
    if (!child && create)
      this.children.set(name, (child = new MemoryDirectory()));
    if (!child) throw missing();
    if (child.kind !== "directory") throw Error("Not a directory");
    return child;
  }
  async getFileHandle(name, { create = false } = {}) {
    let child = this.children.get(name);
    if (!child && create) this.children.set(name, (child = new MemoryFile()));
    if (!child) throw missing();
    if (child.kind === "directory") throw Error("Not a file");
    return child;
  }
  async removeEntry(name) {
    if (!this.children.delete(name)) throw missing();
  }
  async *entries() {
    yield* this.children.entries();
  }
  async *keys() {
    yield* this.children.keys();
  }
}

test("ZIP and import plans reject traversal paths", async () => {
  await assert.rejects(async () => {
    for await (const entry of zipEntries(zipWithName("../escape.lod")))
      void entry;
  }, /Unsafe ZIP path/);
  assert.equal(safeGamePath("Data/.."), false);
  assert.equal(safeGamePath("Data/fake.lod"), true);
  const plan = planImport([{ name: "../escape.lod", size: 4 }]);
  assert.equal(plan.plan.length, 0);
  assert.deepEqual(plan.skippedNames, ["../escape.lod"]);
});

test("ZIP reader checks the actual file checksum", async () => {
  const valid = zipWithName("Data/fake.lod");
  const [entry] = await Array.fromAsync(zipEntries(valid));
  assert.equal(await new Response(entry.stream()).text(), "fake");
  const altered = new Uint8Array(await valid.arrayBuffer());
  altered[30 + Buffer.byteLength("Data/fake.lod")] ^= 1;
  const [bad] = await Array.fromAsync(zipEntries(new Blob([altered])));
  await assert.rejects(
    new Response(bad.stream()).arrayBuffer(),
    /checksum mismatch/,
  );
});

test("staged OPFS import preserves old copy after failure and swaps on success", async (t) => {
  const descriptor = Object.getOwnPropertyDescriptor(globalThis, "navigator");
  const root = new MemoryDirectory();
  Object.defineProperty(globalThis, "navigator", {
    configurable: true,
    value: {
      storage: {
        getDirectory: async () => root,
        estimate: async () => ({ quota: 1e9, usage: 0 }),
        persist: async () => true,
      },
    },
  });
  t.after(() => {
    if (descriptor) Object.defineProperty(globalThis, "navigator", descriptor);
    else delete globalThis.navigator;
  });
  const entry = (path, data) => ({
    path,
    size: Buffer.byteLength(data),
    stream: () => new Blob([data]).stream(),
  });
  await writeEntriesToOpfs([entry("Data/old.lod", "old")]);
  const before = await readManifest();
  await assert.rejects(
    writeEntriesToOpfs([
      {
        path: "Data/broken.lod",
        size: 5,
        stream: () =>
          new ReadableStream({
            start(c) {
              c.error(Error("fake stream failure"));
            },
          }),
      },
    ]),
    /fake stream failure/,
  );
  assert.deepEqual(await readManifest(), before);
  assert.deepEqual([...root.children.keys()], ["h3"]);
  await assert.rejects(
    writeEntriesToOpfs([
      {
        path: "Data/oversized.lod",
        size: 2,
        stream: () => new Blob(["three"]).stream(),
      },
    ]),
    /exceeds declared size/,
  );
  assert.deepEqual(await readManifest(), before);
  await writeEntriesToOpfs([entry("Data/new.lod", "new")]);
  const after = await readManifest();
  assert.deepEqual(
    after.files.map((f) => f.path),
    ["Data/new.lod"],
  );
  assert.deepEqual([...root.children.keys()], ["h3"]);
  await assert.rejects(
    writeEntriesToOpfs([entry("Data/..", "bad")]),
    /Unsafe data path/,
  );
});

test("worker fallback retries partial synchronous OPFS writes", async (t) => {
  const navigatorDescriptor = Object.getOwnPropertyDescriptor(
    globalThis,
    "navigator",
  );
  const selfDescriptor = Object.getOwnPropertyDescriptor(globalThis, "self");
  const replies = [];
  const data = [];
  const access = {
    truncate() {
      data.length = 0;
    },
    write(bytes, { at }) {
      const count = Math.min(2, bytes.length);
      for (let i = 0; i < count; i++) data[at + i] = bytes[i];
      return count;
    },
    flush() {},
    close() {},
  };
  const dir = {
    async getDirectoryHandle() {
      return dir;
    },
    async getFileHandle() {
      return {
        async createSyncAccessHandle() {
          return access;
        },
      };
    },
  };
  Object.defineProperty(globalThis, "navigator", {
    configurable: true,
    value: {
      storage: { getDirectory: async () => dir },
    },
  });
  Object.defineProperty(globalThis, "self", {
    configurable: true,
    value: {
      postMessage(message) {
        replies.push(message);
      },
    },
  });
  t.after(() => {
    if (navigatorDescriptor)
      Object.defineProperty(globalThis, "navigator", navigatorDescriptor);
    else delete globalThis.navigator;
    if (selfDescriptor)
      Object.defineProperty(globalThis, "self", selfDescriptor);
    else delete globalThis.self;
  });
  await import("../web/opfs-writer-worker.js");
  await self.onmessage({ data: { id: 1, command: "open", path: "../bad" } });
  assert.equal(replies.at(-1).ok, false);
  await self.onmessage({
    data: { id: 2, command: "open", path: "h3/Data/fake.lod" },
  });
  await self.onmessage({
    data: { id: 3, command: "write", chunk: Uint8Array.of(1, 2, 3, 4, 5) },
  });
  await self.onmessage({ data: { id: 4, command: "close" } });
  assert.ok(replies.slice(1).every((reply) => reply.ok));
  assert.deepEqual(data, [1, 2, 3, 4, 5]);
});

test("hosted map names with commas pass the path check (Good Witch, Bad Witch)", async () => {
  const { safeGamePath } = await import("../web/data-import.js");
  assert.equal(safeGamePath("Maps/Good Witch, Bad Witch.h3m"), true);
  assert.equal(safeGamePath("Maps/../Data/x.lod"), false);
  assert.equal(safeGamePath("Maps/a/b.h3m"), false);
});
