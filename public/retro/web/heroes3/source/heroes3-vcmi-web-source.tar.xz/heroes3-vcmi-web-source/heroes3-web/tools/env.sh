#!/usr/bin/env bash
# Source this file from Git Bash; keep every path quoted because the project name has a space.
set -e
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
export PROJECT_ROOT
export PREFIX="$PROJECT_ROOT/deps/prefix-wasm"
export EMSDK_QUIET=1
export PATH="$PROJECT_ROOT/deps/emsdk/python/3.13.3_64bit:$PATH"
if [[ ! -d "$PROJECT_ROOT/deps/emsdk/upstream/emscripten" ]]; then
  cmd //c mklink /J "$(cygpath -w "$PROJECT_ROOT/deps/emsdk")" 'C:\Users\justi\emsdk' >/dev/null
fi
source /c/Users/justi/emsdk/emsdk_env.sh >/dev/null
export EMSDK="$PROJECT_ROOT/deps/emsdk"
mkdir -p "$PROJECT_ROOT/deps/build"
mkdir -p "$PROJECT_ROOT/deps/build/llvm-bin"
# Windows resolves a junction to C: when Clang launches one cc1 process per
# input. Keep the driver executables on E: so those child processes can run.
for tool in clang.exe clang++.exe clang-scan-deps.exe llvm-ar.exe llvm-ranlib.exe llvm-nm.exe llvm-objcopy.exe wasm-ld.exe; do
  if [[ ! -f "$PROJECT_ROOT/deps/build/llvm-bin/$tool" ]]; then
    cp "$PROJECT_ROOT/deps/emsdk/upstream/bin/$tool" "$PROJECT_ROOT/deps/build/llvm-bin/$tool"
  fi
done
if [[ ! -d "$PROJECT_ROOT/deps/build/lib/clang" ]]; then
  mkdir -p "$PROJECT_ROOT/deps/build/lib"
  cp -R "$PROJECT_ROOT/deps/emsdk/upstream/lib/clang" "$PROJECT_ROOT/deps/build/lib/"
fi
export EM_CONFIG="$PROJECT_ROOT/deps/build/emscripten-config.py"
project_win="$(cygpath -m "$PROJECT_ROOT")"
cat > "$EM_CONFIG" <<EOF
LLVM_ROOT = r'$project_win/deps/build/llvm-bin'
BINARYEN_ROOT = r'$project_win/deps/emsdk/upstream'
EMSCRIPTEN_ROOT = r'$project_win/deps/emsdk/upstream/emscripten'
NODE_JS = r'$project_win/deps/emsdk/node/24.19.0_64bit/node.exe'
PYTHON = r'$project_win/deps/emsdk/python/3.13.3_64bit/python.exe'
EOF
export EMSDK_PYTHON="$PROJECT_ROOT/deps/emsdk/python/3.13.3_64bit/python.exe"
export EMSDK_NODE="$PROJECT_ROOT/deps/emsdk/node/24.19.0_64bit/node.exe"
export EM_LLVM_ROOT="$project_win/deps/build/llvm-bin"
export EM_BINARYEN_ROOT="$project_win/deps/emsdk/upstream"
export EM_NODE_JS="$project_win/deps/emsdk/node/24.19.0_64bit/node.exe"
export EMCC_SKIP_SANITY_CHECK=1
export EMCC_USE_NINJA=1
export PATH="$PROJECT_ROOT/deps/emsdk/upstream/emscripten:/c/Users/justi/AppData/Roaming/Python/Python312/site-packages/cmake/data/bin:/c/Users/justi/AppData/Roaming/Python/Python312/Scripts:$PATH"
export EM_CACHE="$project_win/deps/em-cache"
export EMCC_CORES=1
export CFLAGS="${CFLAGS:-} -pthread -matomics -mbulk-memory -fwasm-exceptions"
export CXXFLAGS="${CXXFLAGS:-} -pthread -matomics -mbulk-memory -fwasm-exceptions"
export LDFLAGS="${LDFLAGS:-} -pthread -fwasm-exceptions"
export CMAKE_PREFIX_PATH="$PREFIX${CMAKE_PREFIX_PATH:+;$CMAKE_PREFIX_PATH}"
export CMAKE_MODULE_PATH="$PROJECT_ROOT/cmake/wasm;$PROJECT_ROOT/engines/vcmi/cmake_modules"
export EM_PKG_CONFIG_PATH="$PREFIX/lib/pkgconfig"
emcmake() { python "$PROJECT_ROOT/deps/emsdk/upstream/emscripten/emcmake.py" "$@"; }
