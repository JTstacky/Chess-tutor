// Copy the public Heroes III page into the Teng Games site checkout (Chess-tutor) at public/retro/web/heroes3/.
//   node tools/publish-site.mjs <site checkout> <GPL source archive .tar.xz>
// Fails closed: no original game files or saves, /tg-profile.js first in every page's <head>,
// and the matching source archive present. Never pushes; commit and PR by hand.
import { execFileSync } from 'node:child_process';
import { copyFileSync, cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { basename, extname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const [site, archive] = process.argv.slice(2);
if (!site || !archive || !existsSync(join(site, 'public/tg-profile.js')) || !existsSync(archive)) {
  console.error('usage: node tools/publish-site.mjs <site checkout> <source archive .tar.xz>');
  process.exit(2);
}
const web = join(root, 'web');
for (const f of ['vcmiclient.js', 'vcmiclient.wasm', 'vcmiclient.data']) {
  if (!existsSync(join(web, 'engine', f))) { console.error(`missing engine build: web/engine/${f}`); process.exit(1); }
}
execFileSync(process.execPath, [join(root, 'tools/leak-check.mjs'), 'web'], { cwd: root, stdio: 'inherit' });

const out = join(site, 'public/retro/web/heroes3');
rmSync(out, { recursive: true, force: true });
cpSync(web, out, { recursive: true, filter: src => !/\.(lod|snd|vid|h3m|h3c|vsgm1|iso|cab|cue)$/i.test(src) });

// GPL source: the archive plus a page that links it.
const name = basename(archive);
copyFileSync(archive, join(out, 'source', name));
rmSync(join(out, 'source/README.md'), { force: true });
const commit = execFileSync('git', ['rev-parse', '--short', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim();
const mb = (statSync(archive).size / 1048576).toFixed(1);
writeFileSync(join(out, 'source/index.html'), `<!doctype html><html lang="en"><head><script src="/tg-profile.js"></script><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Heroes III source</title><style>body{font:16px/1.5 system-ui,sans-serif;max-width:46rem;margin:2rem auto;padding:0 16px;background:#14101f;color:#eee}a{color:#c9b8ff}</style></head><body>
<h1>Heroes III source</h1>
<p>The Heroes III page runs the open-source <a href="https://github.com/vcmi/vcmi">VCMI</a> engine, built for the browser. The combined build is licensed under the <a href="https://www.gnu.org/licenses/gpl-3.0.html">GNU GPL version 3</a>.</p>
<p><a href="./${name}" download>Download the complete corresponding source</a> (${mb} MB, .tar.xz, build ${commit}). It holds the patched VCMI source, this page's code and build scripts, and the bundled libraries; its README lists the rest. It contains no Heroes III game files.</p>
<p><a href="../">Back to Heroes III</a></p>
</body></html>
`);

// Checks on what was written.
const bad = [];
const walk = dir => { for (const e of readdirSync(dir, { withFileTypes: true })) { const p = join(dir, e.name); if (e.isDirectory()) walk(p); else check(p); } };
const check = p => {
  const rel = relative(out, p).replaceAll('\\', '/');
  if (/\.(lod|snd|vid|h3m|h3c|vsgm1)$/i.test(p)) bad.push(`game file or save: ${rel}`);
  if (extname(p) === '.html') {
    const head = readFileSync(p, 'utf8').match(/<head[^>]*>\s*([^]*?)<\/head>/i)?.[1] ?? '';
    if (!head.startsWith('<script src="/tg-profile.js"></script>')) bad.push(`/tg-profile.js not first in <head>: ${rel}`);
  }
};
walk(out);
if (bad.length) { console.error(bad.join('\n')); rmSync(out, { recursive: true, force: true }); process.exit(1); }
mkdirSync(join(out, 'source'), { recursive: true });
console.log(`published web/ (${commit}) to ${out}`);
