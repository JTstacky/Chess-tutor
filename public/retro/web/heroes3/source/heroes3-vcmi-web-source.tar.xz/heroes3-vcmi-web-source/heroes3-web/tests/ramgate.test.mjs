import test from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";

const bash = "C:\\Program Files\\Git\\bin\\bash.exe";

test("RAM gate waits below 2.5 GB and always chooses one compile job", () => {
  const script = `
    state=$(mktemp)
    trap 'rm -f "$state"' EXIT
    printf '1.0' > "$state"
    powershell() { cat "$state"; }
    sleep() { printf '7.0' > "$state"; }
    source tools/ramgate.sh
    ramgate
    printf 'jobs=%s\\n' "$JOBS"
  `;
  const result = spawnSync(bash, ["-c", script], { encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
  assert.match(result.stderr, /waiting for 2\.5 GB/);
  assert.match(result.stdout, /jobs=1/);
});
