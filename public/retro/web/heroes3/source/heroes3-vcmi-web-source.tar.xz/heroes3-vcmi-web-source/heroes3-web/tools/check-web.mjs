import { spawn, execFileSync } from "node:child_process";
import {
  readFile,
  mkdtemp,
  rm,
  mkdir,
  writeFile,
  access,
} from "node:fs/promises";
import { tmpdir, freemem } from "node:os";
import { join, resolve } from "node:path";
import { deflateRawSync } from "node:zlib";
import { startServer } from "./serve.mjs";

const checks = [];
const ok = (name, condition) => {
  checks.push({ name, pass: !!condition });
  if (!condition) throw Error(name);
};
const delay = (ms) => new Promise((r) => setTimeout(r, ms));
async function chromePath() {
  const options = [
    process.env.CHROME,
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    join(
      process.env.LOCALAPPDATA || "",
      "Google",
      "Chrome",
      "Application",
      "chrome.exe",
    ),
  ].filter(Boolean);
  for (const p of options)
    try {
      await access(p);
      return p;
    } catch {}
  throw Error("System Chrome not found.");
}
class CDP {
  constructor(url) {
    this.ws = new WebSocket(url);
    this.id = 0;
    this.pending = new Map();
    this.listeners = new Map();
    this.ready = new Promise((yes, no) => {
      this.ws.onopen = yes;
      this.ws.onerror = no;
      this.ws.onclose = () => {
        no(Error("Chrome DevTools connection closed."));
        for (const p of this.pending.values())
          p.reject(Error("Chrome DevTools connection closed."));
        this.pending.clear();
      };
    });
    this.ws.onmessage = (e) => {
      const m = JSON.parse(e.data);
      if (m.id) {
        const p = this.pending.get(m.id);
        if (!p) return;
        this.pending.delete(m.id);
        clearTimeout(p.timer);
        m.error ? p.reject(Error(m.error.message)) : p.resolve(m.result);
      } else for (const f of this.listeners.get(m.method) || []) f(m.params);
    };
  }
  async send(method, params = {}) {
    await this.ready;
    return new Promise((resolve, reject) => {
      const id = ++this.id;
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(Error(`Chrome DevTools timed out: ${method}`));
      }, 60000);
      this.pending.set(id, { resolve, reject, timer });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }
  on(method, f) {
    const list = this.listeners.get(method) || [];
    list.push(f);
    this.listeners.set(method, list);
    return () =>
      this.listeners.set(
        method,
        list.filter((x) => x !== f),
      );
  }
  close() {
    this.ws.close();
  }
}
async function evaluate(cdp, expression) {
  const r = await cdp.send("Runtime.evaluate", {
    expression,
    awaitPromise: true,
    returnByValue: true,
  });
  if (r.exceptionDetails)
    throw Error(
      r.exceptionDetails.text +
        " " +
        (r.exceptionDetails.exception?.description || ""),
    );
  return r.result.value;
}
async function waitFor(fn, ms = 12000) {
  const until = Date.now() + ms;
  while (Date.now() < until) {
    try {
      const x = await fn();
      if (x) return x;
    } catch {}
    await delay(150);
  }
  throw Error("Timed out waiting for page state.");
}
function crc32(data) {
  let c = ~0;
  for (const b of data) {
    c ^= b;
    for (let i = 0; i < 8; i++) c = (c >>> 1) ^ (c & 1 ? 0xedb88320 : 0);
  }
  return ~c >>> 0;
}
function fakeZip() {
  const names = [
    "H3bitmap.lod",
    "H3sprite.lod",
    "H3ab_bmp.lod",
    "H3ab_spr.lod",
    "Heroes3.snd",
    "VIDEO.VID",
  ];
  const local = [],
    central = [];
  let offset = 0;
  names.forEach((name, i) => {
    const filename = Buffer.from("Data/" + name),
      content = Buffer.from("FAKE TEST DATA " + name),
      method = i ? 8 : 0,
      payload = i ? deflateRawSync(content) : content,
      crc = crc32(content);
    const a = Buffer.alloc(30);
    a.writeUInt32LE(0x04034b50);
    a.writeUInt16LE(20, 4);
    a.writeUInt16LE(method, 8);
    a.writeUInt32LE(crc, 14);
    a.writeUInt32LE(payload.length, 18);
    a.writeUInt32LE(content.length, 22);
    a.writeUInt16LE(filename.length, 26);
    local.push(a, filename, payload);
    const b = Buffer.alloc(46);
    b.writeUInt32LE(0x02014b50);
    b.writeUInt16LE(20, 4);
    b.writeUInt16LE(20, 6);
    b.writeUInt16LE(method, 10);
    b.writeUInt32LE(crc, 16);
    b.writeUInt32LE(payload.length, 20);
    b.writeUInt32LE(content.length, 24);
    b.writeUInt16LE(filename.length, 28);
    b.writeUInt32LE(offset, 42);
    central.push(b, filename);
    offset += a.length + filename.length + payload.length;
  });
  const cd = Buffer.concat(central),
    end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50);
  end.writeUInt16LE(names.length, 8);
  end.writeUInt16LE(names.length, 10);
  end.writeUInt32LE(cd.length, 12);
  end.writeUInt32LE(offset, 16);
  return Buffer.concat([...local, cd, end]).toString("base64");
}
async function run() {
  let free;
  try {
    const output = execFileSync(
      "powershell",
      [
        "-NoProfile",
        "-Command",
        "(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory",
      ],
      { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] },
    ).trim();
    free = Number(output);
    if (!output || !Number.isFinite(free) || free <= 0)
      throw Error("CIM returned no reading");
  } catch {
    free = freemem() / 1024;
    console.log(
      "CIM memory query unavailable; using Node free-memory reading.",
    );
  }
  if (!Number.isFinite(free) || free < 1.5 * 1024 * 1024) {
    console.log(
      `RAM gate: ${(free / 1024 / 1024).toFixed(2)} GB free; need 1.5 GB. Chrome not started.`,
    );
    process.exitCode = 2;
    return;
  }
  let server, chrome, profile, browser;
  try {
    server = await startServer({ port: 8831 });
    profile = await mkdtemp(join(tmpdir(), "h3-web-check-"));
    chrome = spawn(
      await chromePath(),
      [
        "--headless=new",
        "--remote-debugging-port=0",
        `--user-data-dir=${profile}`,
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-gpu",
        "--disable-gpu-sandbox",
        "--no-sandbox",
        "--disable-extensions",
        "--mute-audio",
        "about:blank",
      ],
      { stdio: ["ignore", "ignore", "pipe"] },
    );
    let chromeErrors = "";
    chrome.stderr.on("data", (b) => {
      chromeErrors = (chromeErrors + b.toString()).slice(-2000);
    });
    const portFile = join(profile, "DevToolsActivePort");
    const port = await waitFor(
      async () => Number((await readFile(portFile, "utf8")).split("\n")[0]),
      15000,
    );
    const version = await (
      await fetch(`http://127.0.0.1:${port}/json/version`)
    ).json();
    browser = new CDP(version.webSocketDebuggerUrl);
    await browser.ready;
    chrome.on("exit", (code) => {
      if (code && chromeErrors)
        console.error(`Chrome exited ${code}: ${chromeErrors.trim()}`);
    });
    await mkdir(resolve("shots"), { recursive: true });
    const viewports = [
      ["desktop", 1280, 800, false, false],
      ["compact", 800, 600, true, false],
      ["tablet", 1024, 768, true, false],
      ["phone", 844, 390, true, true],
      ["phone-portrait", 390, 844, true, true],
    ];
    const requests = [];
    for (const [name, width, height, touch, mobile] of viewports) {
      const { targetId } = await browser.send("Target.createTarget", {
        url: "about:blank",
      });
      const target = await (
        await fetch(`http://127.0.0.1:${port}/json`)
      ).json();
      const info = target.find((x) => x.id === targetId);
      if (!info) throw Error("Chrome target missing");
      const tab = new CDP(info.webSocketDebuggerUrl);
      await tab.ready;
      try {
        await Promise.all([
          tab.send("Page.enable"),
          tab.send("Runtime.enable"),
          tab.send("Network.enable"),
        ]);
        tab.on("Network.requestWillBeSent", (x) =>
          requests.push({
            method: x.request.method,
            url: x.request.url,
            postData: x.request.postData,
          }),
        );
        await tab.send("Emulation.setDeviceMetricsOverride", {
          width,
          height,
          deviceScaleFactor: 1,
          mobile,
        });
        await tab.send("Emulation.setTouchEmulationEnabled", {
          enabled: touch,
          maxTouchPoints: touch ? 5 : 1,
        });
        await tab.send("Page.navigate", { url: server.url });
        await waitFor(
          () =>
            evaluate(
              tab,
              'document.readyState === "complete" && crossOriginIsolated',
            ),
          15000,
        );
        ok(`${name}: isolated`, await evaluate(tab, "crossOriginIsolated"));
        ok(
          `${name}: profile script first`,
          await evaluate(
            tab,
            "document.head.firstElementChild?.matches('script[src=\"/tg-profile.js\"]')",
          ),
        );
        if (name === "desktop") {
          const imported = await evaluate(
            tab,
            `(async()=>{const m=await import('/data-import.js');const names=['H3bitmap.lod','H3sprite.lod','H3ab_bmp.lod','H3ab_spr.lod','Heroes3.snd','VIDEO.VID'];const files=names.map(n=>new File(['FAKE TEST DATA '+n],n));files.push(new File(['FAKE TEST DATA map'],'test.h3m'),new File(['FAKE TEST DATA music'],'test.mp3'));await m.importFromFiles(files);const x=await m.readManifest();return x.files.length===8&&x.files.every(f=>f.size>0&&/^[0-9a-f]{64}$/.test(f.fp));})()`,
          );
          ok("fake files import and fingerprints", imported);
          const missing = await evaluate(
            tab,
            `(async()=>{const m=await import('/data-import.js');return m.planImport(['H3bitmap.lod','H3sprite.lod','H3ab_bmp.lod','Heroes3.snd','VIDEO.VID'].map(name=>({name}))).missingRequired.some(x=>x.includes('H3ab_spr.lod')&&x.includes('Complete edition'));})()`,
          );
          ok("Complete edition missing-file message", missing);
          const b64 = fakeZip();
          const zip = await evaluate(
            tab,
            `(async()=>{const m=await import('/data-import.js');const bytes=Uint8Array.from(atob('${b64}'),x=>x.charCodeAt(0));await m.importFromZip(new File([bytes],'fake.zip'));const x=await m.readManifest();return x.files.length===6&&x.files.every(f=>f.size>0&&f.fp);})()`,
          );
          ok("stored and deflated ZIP import", zip);
          const replacement = await evaluate(
            tab,
            `(async()=>{
            const m=await import('/data-import.js');
            const names=['H3bitmap.lod','H3sprite.lod','H3ab_bmp.lod','H3ab_spr.lod','Heroes3.snd','VIDEO.VID'];
            const files=names.map(n=>new File(['FAKE TEST DATA '+n],n));
            files.push(new File(['skip'],'bad?.lod'));
            const result=await m.importFromFiles(files);
            const root=await navigator.storage.getDirectory();
            const data=await (await root.getDirectoryHandle('h3')).getDirectoryHandle('Data');
            const remaining=[];for await(const name of data.keys())remaining.push(name);
            let oldMapsGone=false;
            try {await (await root.getDirectoryHandle('h3')).getDirectoryHandle('Maps');}
            catch(e){oldMapsGone=e.name==='NotFoundError';}
            return result.skippedNames.includes('bad?.lod') && result.manifest.files.length===6 && remaining.length===6 && oldMapsGone;
          })()`,
          );
          ok("unsafe name skipped and fresh import replaces h3", replacement);
          const safeFailure = await evaluate(
            tab,
            `(async()=>{
            const m=await import('/data-import.js');
            const before=JSON.stringify(await m.readManifest());
            const failing={path:'Data/broken.lod',size:10,stream(){return new ReadableStream({start(c){c.error(Error('fake read failure'));}});}};
            try{await m.writeEntriesToOpfs([failing]);return false;}catch(e){
              const root=await navigator.storage.getDirectory();
              const names=[];for await(const name of root.keys())names.push(name);
              return e.message.includes('fake read failure') && JSON.stringify(await m.readManifest())===before && !names.some(n=>n.startsWith('h3-import-'));
            }
          })()`,
          );
          ok(
            "failed re-import preserves old copy and cleans staging",
            safeFailure,
          );
          const cd2 = await evaluate(
            tab,
            `(async()=>{
            const m=await import('/data-import.js');
            const entries=['disc1/Data/Heroes3.snd','disc2/Data/Heroes3.snd','disc2/Data/Heroes3.vid'];
            const plan=m.planImport(entries.map(name=>({name,size:1}))).plan.map(x=>x.path);
            return plan.includes('Data/Heroes3.snd') && plan.includes('Data/Heroes3-cd2.snd') && plan.includes('Data/Heroes3.vid');
          })()`,
          );
          ok("CD2 sound and video use VCMI paths", cd2);
          const fullAccountHint = await evaluate(
            tab,
            `(async()=>{
            const {PRIVATE_STORE}=await import('/config.js');
            const {privateStoreSource}=await import('/sources/private-store.js');
            PRIVATE_STORE.enabled=true;
            localStorage.setItem('evonline.session','fake-token');
            localStorage.setItem('tenggames.kind','kid');
            localStorage.setItem('evonline.tier','full');
            const fullKid=privateStoreSource.isAvailable();
            localStorage.setItem('evonline.tier','basic');
            const basicKid=privateStoreSource.isAvailable();
            localStorage.setItem('tenggames.kind','parent');
            const parent=privateStoreSource.isAvailable();
            localStorage.setItem('evonline.tier','guest');
            const guestTier=privateStoreSource.isAvailable();
            localStorage.setItem('evonline.tier','full');
            localStorage.setItem('tenggames.kind','guest');
            const guestKind=privateStoreSource.isAvailable();
            PRIVATE_STORE.enabled=false;
            localStorage.clear();
            return fullKid && basicKid && parent && !guestTier && !guestKind && !privateStoreSource.isAvailable();
          })()`,
          );
          ok("private store button shows signed-in non-guests; server decides access", fullAccountHint);
          const saves = await evaluate(tab, `(async()=>{
            const m=await import('/saves.js');
            const first=await m.importSave(new File(['FAKE SAVE ONE'],'Test turn.vsgm1'));
            const second=await m.importSave(new File(['FAKE SAVE TWO'],'Test turn.vsgm1'));
            const entries=await m.listSaves();
            const root=await navigator.storage.getDirectory();
            const dir=await (await (await root.getDirectoryHandle('userdata')).getDirectoryHandle('vcmi')).getDirectoryHandle('Saves');
            const present=await dir.getFileHandle(second).then(()=>true);
            const exported=await (await m.exportSave(first)).text();
            const autosave=await dir.getDirectoryHandle('Autosave',{create:true});
            const match=await autosave.getDirectoryHandle('2026-10-29_My game',{create:true});
            const nested=await match.getFileHandle('1.vsgm1',{create:true});
            const writer=await nested.createWritable();await writer.write('FAKE AUTOSAVE');await writer.close();
            const nestedPath='Autosave/2026-10-29_My game/1.vsgm1';
            const nestedListed=(await m.listSaves()).some(x=>x.name===nestedPath);
            const nestedExported=await (await m.exportSave(nestedPath)).text();
            let rejected=false;
            try{await m.importSave(new File(['bad'],'../escape.vsgm1'));}catch{rejected=true;}
            await m.deleteSave(second);
            await m.deleteSave(nestedPath);
            return first==='Test turn.vsgm1' && second==='Test turn (2).vsgm1' &&
              present && exported==='FAKE SAVE ONE' && rejected && entries.length===2 &&
              nestedListed && nestedExported==='FAKE AUTOSAVE' && (await m.listSaves()).length===1;
          })()`);
          ok("native saves stay in OPFS, round-trip and avoid overwrite", saves);
          if (await evaluate(tab, `fetch('/engine/vcmiclient.js', {method:'HEAD'}).then(r=>r.ok)`)) {
            const runtime = await evaluate(tab, `(async()=>{
              const output=[];
              const createVcmi=(await import('/engine/vcmiclient.js')).default;
              const module=await createVcmi({noInitialRun:true, locateFile:name=>'/engine/'+name,
                print:line=>output.push(line),printErr:line=>output.push(line)});
              if(typeof module.callMain!=='function')return false;
              if(module.callMain(['--version'])!==0)return false;
              const deadline=Date.now()+12000;
              while(Date.now()<deadline && !output.some(line=>line.includes('user data:')))
                await new Promise(resolve=>setTimeout(resolve,100));
              return output.some(line=>line.includes('user data:')) &&
                !output.some(line=>line.includes('Could not mount browser game storage'));
            })()`);
            ok("built engine mounts OPFS on its worker thread", runtime);
          }
          ok(
            "private store hidden",
            await evaluate(
              tab,
              'document.getElementById("private-store").hidden',
            ),
          );
          await tab.send("Page.reload", { ignoreCache: true });
          await waitFor(() =>
            evaluate(
              tab,
              'document.readyState === "complete" && document.getElementById("status")?.textContent.includes("game files ready")',
            ),
          );
          ok("save survives page reload and appears in UI", await evaluate(tab,
            `document.querySelector('#save-list li')?.textContent.includes('Test turn.vsgm1') && document.getElementById('save-status')?.textContent.includes('1 save')`));
        }
        await delay(300);
        const image = await tab.send("Page.captureScreenshot", {
          format: "png",
          captureBeyondViewport: false,
        });
        await writeFile(
          resolve("shots", `${name}.png`),
          Buffer.from(image.data, "base64"),
        );
        checks.push({ name: `${name}: screenshot`, pass: true });
        const layout = await evaluate(
          tab,
          `(() => {
          document.getElementById('setup').hidden=true;
          document.getElementById('game').hidden=false;
          const bar=document.getElementById('touch-bar');
          const canvas=document.getElementById('canvas');
          const hint=document.getElementById('rotate-hint');
          const rect=element=>element.getBoundingClientRect();
          const visible=element=>getComputedStyle(element).display!=='none' && rect(element).width>0 && rect(element).height>0;
          const inside=r=>r.left>=-1 && r.top>=-1 && r.right<=innerWidth+1 && r.bottom<=innerHeight+1;
          const c=rect(canvas), b=rect(bar);
          return {
            barVisible:visible(bar), barInside:inside(b), hintVisible:visible(hint), canvasVisible:visible(canvas),
            canvasAspect:c.width/c.height, canvasInside:inside(c),
            buttons:[...bar.querySelectorAll('button')].map(button=>{
              const r=rect(button);
              return {width:r.width,height:r.height,inside:inside(r),inBar:r.left>=b.left-1 && r.top>=b.top-1 && r.right<=b.right+1 && r.bottom<=b.bottom+1};
            }),
            barScrolls:bar.scrollWidth>bar.clientWidth+1 || bar.scrollHeight>bar.clientHeight+1
          };
        })()`,
        );
        const gameImage = await tab.send("Page.captureScreenshot", {
          format: "png",
          captureBeyondViewport: false,
        });
        await writeFile(
          resolve("shots", `${name}-game.png`),
          Buffer.from(gameImage.data, "base64"),
        );
        checks.push({ name: `${name}: game screenshot`, pass: true });
        ok(
          `${name}: canvas visible, 4:3, inside viewport`,
          layout.canvasVisible &&
            Math.abs(layout.canvasAspect - 4 / 3) < 0.05 &&
            layout.canvasInside,
        );
        if (touch) {
          ok(`${name}: touch bar visible`, layout.barVisible);
          ok(
            `${name}: touch buttons at least 48x48`,
            layout.buttons.every((b) => b.width >= 48 && b.height >= 48),
          );
          ok(
            `${name}: every touch button fits without scrolling`,
            layout.buttons.every((b) => b.inside && b.inBar) &&
              !layout.barScrolls,
          );
        } else {
          ok("desktop: touch bar hidden by default", !layout.barVisible);
          const shown = await evaluate(
            tab,
            `(() => {
            document.getElementById('controls-toggle').click();
            const bar=document.getElementById('touch-bar');
            return getComputedStyle(bar).display!=='none' && bar.getBoundingClientRect().width>0;
          })()`,
          );
          ok("desktop: Controls toggle shows bar", shown);
        }
        if (name === "phone-portrait")
          ok("phone portrait: rotate hint visible", layout.hintVisible);
        if (name === "phone")
          ok("phone landscape: rotate hint hidden", !layout.hintVisible);
        if (name === "tablet") {
          const singleKey = await evaluate(tab, `(() => {
            const seen=[];
            const listener=e=>{if(e.key==='s')seen.push(e.type);};
            window.addEventListener('keydown',listener);window.addEventListener('keyup',listener);
            [...document.querySelectorAll('#touch-bar button')].find(b=>b.textContent==='Save').click();
            window.removeEventListener('keydown',listener);window.removeEventListener('keyup',listener);
            return seen.join(',')==='keydown,keyup';
          })()`);
          ok("tablet: Save touch button emits one key press", singleKey);
          const fit = await evaluate(
            tab,
            `(() => {
            const game=document.getElementById('game');
            const button=[...document.querySelectorAll('#touch-bar button')].find(b=>b.textContent==='Actual size');
            button.click();
            const actual=game.classList.contains('actual-size') && button.textContent==='Fit' && Math.round(document.getElementById('canvas').getBoundingClientRect().width)===1024;
            button.click();
            return actual && !game.classList.contains('actual-size') && button.textContent==='Actual size';
          })()`,
          );
          ok("tablet: Fit toggles actual canvas pixels", fit);
          const engineSizing = await evaluate(tab, `(() => {
            const canvas=document.getElementById('canvas');
            canvas.style.width='800px'; canvas.style.height='600px';
            const rect=canvas.getBoundingClientRect();
            const bar=document.getElementById('touch-bar').getBoundingClientRect();
            canvas.style.removeProperty('width'); canvas.style.removeProperty('height');
            return {fits:rect.right<=bar.left+1 && bar.right<=innerWidth+1,
              canvasRight:rect.right, canvasWidth:rect.width, barLeft:bar.left, barRight:bar.right, viewport:innerWidth,
              computedWidth:getComputedStyle(canvas).width};
          })()`);
          if (!engineSizing.fits) console.log(`Tablet engine sizing: ${JSON.stringify(engineSizing)}`);
          ok("tablet: SDL inline size cannot hide touch controls", engineSizing.fits);
          const nativeSize = await evaluate(tab, `(() => {
            const canvas=document.getElementById('canvas');
            const game=document.getElementById('game');
            const button=[...document.querySelectorAll('#touch-bar button')].find(b=>b.textContent==='Actual size');
            canvas.width=800; canvas.height=600; button.click();
            const works=game.classList.contains('actual-size') && Math.round(canvas.getBoundingClientRect().width)===800;
            button.click(); canvas.width=1024; canvas.height=768;
            return works;
          })()`);
          ok("tablet: Actual size follows SDL backing pixels", nativeSize);
          const point = await evaluate(tab, `(() => {
            const canvas = document.getElementById('canvas');
            const r = canvas.getBoundingClientRect();
            window.__touchClicks = [];
            for (const type of ['mousedown', 'mouseup', 'click', 'touchstart']) {
              canvas.addEventListener(type, e => window.__touchClicks.push({type, button:e.button, trusted:e.isTrusted}));
            }
            return {x:Math.round(r.left+r.width/2), y:Math.round(r.top+r.height/2)};
          })()`);
          await tab.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [{ ...point, id: 1 }] });
          await delay(600);
          await tab.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
          await delay(100);
          const gesture = await evaluate(tab, `(() => {
            const events = window.__touchClicks;
            return events.filter(e => e.type==='mousedown' && e.button===2).length===1 &&
              events.filter(e => e.type==='mousedown' && e.button===0).length===0 &&
              events.filter(e => e.type==='touchstart').length===0;
          })()`);
          ok("tablet: long press emits one right click and hides native touch", gesture);
        }
        if (name === "phone") {
          const engineSizing = await evaluate(tab, `(() => {
            const canvas=document.getElementById('canvas');
            canvas.style.width='800px'; canvas.style.height='600px';
            const rect=canvas.getBoundingClientRect();
            const bar=document.getElementById('touch-bar').getBoundingClientRect();
            canvas.style.removeProperty('width'); canvas.style.removeProperty('height');
            return {fits:rect.right<=bar.left+1 && bar.right<=innerWidth+1,
              canvasRight:rect.right, barLeft:bar.left, barRight:bar.right, viewport:innerWidth};
          })()`);
          if (!engineSizing.fits) console.log(`Phone engine sizing: ${JSON.stringify(engineSizing)}`);
          ok("phone: SDL inline size cannot hide touch controls", engineSizing.fits);
        }
        if (name === "compact") {
          const engineSizing = await evaluate(tab, `(() => {
            const canvas=document.getElementById('canvas');
            canvas.style.width='800px'; canvas.style.height='600px';
            const rect=canvas.getBoundingClientRect();
            const bar=document.getElementById('touch-bar').getBoundingClientRect();
            canvas.style.removeProperty('width'); canvas.style.removeProperty('height');
            return {fits:rect.right<=bar.left+1 && bar.right<=innerWidth+1,
              canvasRight:rect.right, barLeft:bar.left, barRight:bar.right, viewport:innerWidth};
          })()`);
          if (!engineSizing.fits) console.log(`Compact engine sizing: ${JSON.stringify(engineSizing)}`);
          ok("compact: SDL inline size cannot overlap touch controls", engineSizing.fits);
        }
        if (name === "desktop") {
          const forgot = await evaluate(
            tab,
            `(async()=>{const m=await import('/data-import.js');await m.forgetGameData();return await m.readManifest()===null;})()`,
          );
          ok("forget removes h3", forgot);
        }
      } finally {
        tab.close();
        await browser.send("Target.closeTarget", { targetId }).catch(() => {});
      }
    }
    ok(
      "no upload requests",
      requests.every(
        (r) =>
          ["GET", "HEAD"].includes(r.method) &&
          !r.postData &&
          !r.url.includes("FAKE TEST DATA"),
      ),
    );
  } finally {
    if (browser) {
      await browser.send("Browser.close").catch(() => {});
      browser.close();
    }
    if (chrome && !chrome.killed) {
      chrome.kill();
      await delay(500);
    }
    if (profile)
      await rm(profile, {
        recursive: true,
        force: true,
        maxRetries: 3,
        retryDelay: 200,
      });
    if (server) await server.close();
  }
}
try {
  await run();
} catch (e) {
  checks.push({ name: e.message, pass: false });
  process.exitCode = 1;
}
for (const c of checks) console.log(`${c.pass ? "PASS" : "FAIL"} ${c.name}`);
