#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd -P)"
mkdir -p "$root/patches"
git -C "$root/engines/vcmi" diff > "$root/patches/vcmi-1.7.5-web.patch"
