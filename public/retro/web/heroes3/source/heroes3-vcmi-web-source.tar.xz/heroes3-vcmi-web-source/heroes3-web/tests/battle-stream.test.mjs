import test from 'node:test';
import assert from 'node:assert/strict';
import { createBattleStream, validBattleInput } from '../web/battle-stream.js';

test('battle input accepts bounded pointer and key events only', () => {
  assert.equal(validBattleInput({ type: 'input', event: 'down', x: .5, y: 1, button: 0 }), true);
  assert.equal(validBattleInput({ type: 'input', event: 'up', x: -1, y: 0, button: 0 }), false);
  assert.equal(validBattleInput({ type: 'input', event: 'move', x: NaN, y: .3, button: 0 }), false);
  assert.equal(validBattleInput({ type: 'input', event: 'move', x: .2, y: .3, button: 1 }), false);
  assert.equal(validBattleInput({ type: 'input', event: 'keydown', code: 'KeyA', key: 'a', keyCode: 65 }), true);
  assert.equal(validBattleInput({ type: 'input', event: 'keydown', code: 'KeyA', key: 'a', keyCode: 255 }), false);
  assert.equal(validBattleInput({ type: 'input', event: 'keydown', code: 'F12', key: 'F12', keyCode: 123 }), false);
  // keyCode must be the one for code: an allowed code can't carry Tab, Ctrl or F12.
  assert.equal(validBattleInput({ type: 'input', event: 'keydown', code: 'KeyA', key: 'a', keyCode: 9 }), false);
  assert.equal(validBattleInput({ type: 'input', event: 'keydown', code: 'Digit3', key: '3', keyCode: 51 }), true);
  assert.equal(validBattleInput({ type: 'input', event: 'keyup', code: 'Escape', key: 'Escape', keyCode: 27 }), true);
});

test('a computer player attacking a remote human streams that battle to the human', t => {
  const oldDocument = globalThis.document, oldWindow = globalThis.window;
  const sent = [];
  const element = () => ({ hidden: false, append() {}, querySelectorAll: () => [], addEventListener() {}, setAttribute() {},
    getContext: () => ({ drawImage() {} }) });
  globalThis.document = { createElement: element };
  globalThis.window = { addEventListener() {}, removeEventListener() {} };
  t.after(() => { globalThis.document = oldDocument; globalThis.window = oldWindow; });
  const stream = createBattleStream({ canvas: element(), stage: { append() {} },
    setup: element(), game: element(), send: message => sent.push(message),
    getSeat: () => 0, getModule: () => ({}), timer: () => 1, untimer() {} });
  stream.state({ holder: 0, lease: 2, viewer: -1, controller: -1,
    players: [{ seat: 0, online: true }, { seat: 1, online: true }] });
  // Seats are Red (0) and Blue (1); purple (5) is a computer player.
  stream.battle({ active: true, attacker: 5, defender: 1 }, [0, 1]);
  assert.deepEqual(sent[0], { type: 'control', lease: 2, viewer: 1, controller: -1 });
  stream.battle({ active: true, control: 1 }, [0, 1]);
  assert.deepEqual(sent[1], { type: 'control', lease: 2, viewer: 1, controller: 1 });
  stream.stop();
});

test('holder grants one remote human and sends bounded JPEG frames and input', async t => {
  const oldDocument = globalThis.document, oldWindow = globalThis.window;
  const oldMouse = globalThis.MouseEvent, oldKeyboard = globalThis.KeyboardEvent;
  const events = new Map(), sent = [], injected = [], drawn = [];
  let tick, clock = 0, seat = 0;
  const element = () => ({ hidden: false, style: {}, append() {}, querySelectorAll: () => [],
    addEventListener(kind, fn) { events.set(kind, fn); },
    setAttribute() {}, getContext: () => ({ drawImage: (...args) => drawn.push(args) }),
    getBoundingClientRect: () => ({ left: 10, top: 20, width: 800, height: 600 }),
    dispatchEvent: event => injected.push(event), focus() {},
  });
  const canvas = element();
  canvas.toBlob = callback => callback(new Blob([new Uint8Array(1200)], { type: 'image/jpeg' }));
  const stage = { append(node) { this.viewer = node; } };
  globalThis.document = { createElement: () => element() };
  globalThis.window = { addEventListener() {}, removeEventListener() {} };
  globalThis.MouseEvent = class { constructor(type, options) { Object.assign(this, { type }, options); } };
  globalThis.KeyboardEvent = globalThis.MouseEvent;
  t.after(() => { globalThis.document = oldDocument; globalThis.window = oldWindow;
    globalThis.MouseEvent = oldMouse; globalThis.KeyboardEvent = oldKeyboard; });
  const stream = createBattleStream({ canvas, stage, setup: element(), game: element(),
    send: value => { sent.push(value); return true; }, getSeat: () => seat, getModule: () => ({}),
    now: () => clock, timer: fn => { tick = fn; return 1; }, untimer() {} });
  const room = { holder: 0, lease: 4, viewer: -1, controller: -1,
    players: [{ seat: 0, online: true }, { seat: 1, online: true }] };
  stream.state(room);
  stream.battle({ active: true, attacker: 0, defender: 1 }, [0, 1]);
  assert.deepEqual(sent[0], { type: 'control', lease: 4, viewer: 1, controller: -1 });
  stream.battle({ active: true, control: 1 }, [0, 1]);
  assert.deepEqual(sent[1], { type: 'control', lease: 4, viewer: 1, controller: 1 });
  stream.state({ ...room, viewer: 1, controller: 1 });
  clock = 120; tick();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(new Uint8Array(sent[2])[0], 1);
  assert.equal(new Uint8Array(sent[2]).length, 1201);
  assert.equal(stream.input({ type: 'input', event: 'down', x: .5, y: .5, button: 0, seat: 7 }), false);
  assert.equal(stream.input({ type: 'input', event: 'down', x: .5, y: .5, button: 0, seat: 1 }), true);
  assert.equal(injected[0].clientX, 410);
  assert.equal(injected[0].clientY, 320);
  assert.equal(stream.input({ type: 'input', event: 'keydown', code: 'Space', key: ' ', keyCode: 32, seat: 1 }), true);
  assert.equal(injected[1].keyCode, 32);
  assert.equal(injected[1].which, 32);
  stream.battle({ active: false }, [0, 1]);
  assert.deepEqual(sent.at(-1), { type: 'control', lease: 4, viewer: -1, controller: -1 });
  seat = 1;
  stream.state({ ...room, viewer: 1, controller: 1 });
  assert.equal(stream.viewer.hidden, false);
  stream.stop();
});

test('offline bot-after-zero switches only the remote battle seat once', t => {
  const oldDocument = globalThis.document, oldWindow = globalThis.window;
  const calls = [], sent = [];
  const element = () => ({ hidden: false, append() {}, querySelectorAll: () => [], addEventListener() {}, setAttribute() {},
    getContext: () => ({ drawImage() {} }) });
  globalThis.document = { createElement: element };
  globalThis.window = { addEventListener() {}, removeEventListener() {} };
  t.after(() => { globalThis.document = oldDocument; globalThis.window = oldWindow; });
  let tick;
  const stream = createBattleStream({ canvas: element(), stage: { append() {} },
    setup: element(), game: element(), send: message => sent.push(message),
    getSeat: () => 0, getModule: () => ({ ccall: (...args) => calls.push(args) }),
    timer: fn => { tick = fn; return 1; }, untimer() {} });
  stream.state({ holder: 0, lease: 3, viewer: -1, controller: -1, botMinutes: 0,
    now: 10000, turnSince: 1000, players: [
      { seat: 0, online: true }, { seat: 1, online: false, offlineSince: 9000 },
    ] });
  stream.battle({ active: true, attacker: 0, defender: 1 }, [0, 1]);
  tick(); tick();
  assert.deepEqual(calls, [['h3_set_battle_bot', null, ['number'], [1]]]);
  assert.equal(stream.input({ type: 'input', event: 'down', x: .5, y: .5, button: 0, seat: 1 }), false);
  stream.battle({ active: false }, [0, 1]);
  assert.deepEqual(calls.at(-1), ['h3_set_battle_bot', null, ['number'], [-1]]);
  stream.stop();
});
