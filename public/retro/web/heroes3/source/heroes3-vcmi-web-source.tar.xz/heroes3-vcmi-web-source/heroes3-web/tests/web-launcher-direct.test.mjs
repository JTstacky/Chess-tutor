import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../web/launcher.js?direct-test';

test('direct turn load keeps one local human and forwards native callbacks', async t => {
  const original = Object.getOwnPropertyDescriptor(globalThis, 'navigator');
  Object.defineProperty(globalThis, 'navigator', { configurable: true, value: {
    storage: { getDirectory: async () => ({ getDirectoryHandle: async () => ({}) }) },
  } });
  t.after(() => original
    ? Object.defineProperty(globalThis, 'navigator', original)
    : delete globalThis.navigator);
  const events = [], seats = [], checkpoints = [], battles = [];
  await launch({ canvas: {}, localSeat: 1, saveName: 'TurnPass-a1-r2.vsgm1', phase: 2,
    onTurnPass: event => events.push(event), onSeats: colors => seats.push(colors),
    onCheckpoint: event => checkpoints.push(event),
    onBattle: event => battles.push(event),
    factory: async options => {
      options.preRun[0]();
      assert.equal(options.ENV.H3_LOCAL_SEAT, '1');
      assert.equal(options.ENV.H3_TURN_PHASE, '2');
      options.onTurnPass({ seat: 0, save: 'TurnPass.vsgm1', phase: 0 });
      options.onTurnSeats([0, 1]);
      options.onTurnCheckpoint({ phase: 1, save: 'OnlineCheckpoint1.vsgm1' });
      options.onTurnBattle({ active: true, attacker: 0, defender: 1 });
      return { callMain(args) {
        assert.deepEqual(args, ['--nointro', '--h3-load-save', 'Saves/TurnPass-a1-r2.vsgm1']);
        return 0;
      } };
    },
  });
  assert.deepEqual(events, [{ seat: 0, save: 'TurnPass.vsgm1', phase: 0 }]);
  assert.deepEqual(seats, [[0, 1]]);
  assert.deepEqual(checkpoints, [{ phase: 1, save: 'OnlineCheckpoint1.vsgm1' }]);
  assert.deepEqual(battles, [{ active: true, attacker: 0, defender: 1 }]);
});
