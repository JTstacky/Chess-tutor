import test from 'node:test';
import assert from 'node:assert/strict';
import { launch, prepareGameData } from '../web/launcher.js';

test('launcher prepares OPFS and delegates mounting to the engine thread', async t => {
  const original = Object.getOwnPropertyDescriptor(globalThis, 'navigator');
  const calls = [];
  Object.defineProperty(globalThis, 'navigator', {
    configurable: true,
    value: { storage: { getDirectory: async () => ({
      getDirectoryHandle: async (name, options) => { calls.push([name, options?.create ?? false]); return {}; },
    }) } },
  });
  t.after(() => original
    ? Object.defineProperty(globalThis, 'navigator', original)
    : delete globalThis.navigator);

  await prepareGameData();
  assert.deepEqual(calls, [['h3', false], ['userdata', true]]);
  calls.length = 0;
  const statuses = [];
  let started = false;
  const module = await launch({
    canvas: {},
    localSeat: 1,
    onStatus: message => statuses.push(message),
    factory: async options => {
      assert.equal(options.noInitialRun, true);
      assert.equal(options.locateFile('vcmiclient.wasm').endsWith('/engine/vcmiclient.wasm'), true);
      options.preRun[0]();
      assert.equal(options.ENV.XDG_DATA_DIRS, '/gamedata');
      assert.equal(options.ENV.SDL_RENDER_DRIVER, 'software');
      assert.equal(options.ENV.SDL_AUDIODRIVER, undefined);
      assert.equal(options.ENV.H3_LOCAL_SEAT, '1');
      return { callMain(args) { started = true; assert.deepEqual(args, ['--nointro']); return 0; } };
    },
  });
  assert.equal(started, true);
  assert.equal(typeof module.callMain, 'function');
  assert.deepEqual(calls, [['h3', false], ['userdata', true]]);
  assert.deepEqual(statuses, ['Loading VCMI engine…', 'Starting VCMI…']);
});
