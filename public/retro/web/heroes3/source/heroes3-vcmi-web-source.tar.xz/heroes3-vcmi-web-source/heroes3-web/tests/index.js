// Node on Windows treats `node --test tests/` as a directory module.
import "./leak-check.test.mjs";
import "./is5-extract.test.mjs";
import "./web-import.test.mjs";
import "./private-store.test.mjs";
import "./sha256.test.mjs";
import "./ramgate.test.mjs";
import "./web-launcher.test.mjs";
import "./turn-transfer.test.mjs";
import "./online.test.mjs";
import "./battle-stream.test.mjs";
import "./web-launcher-direct.test.mjs";
