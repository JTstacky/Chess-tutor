import test from 'node:test';
import assert from 'node:assert/strict';
import { mountOnline } from '../web/online.js';
import { createFakeTurnRelay } from '../tools/fake-turn-server.mjs';
import { createHash } from 'node:crypto';

const wait = async check => {
  for (let attempt = 0; attempt < 100; attempt++) {
    if (check()) return;
    await new Promise(resolve => setTimeout(resolve, 5));
  }
  throw Error('Timed out waiting for fake relay turn.');
};

test('online controller passes red to blue and back through the fake relay', async t => {
  const oldDocument = globalThis.document, oldLocation = globalThis.location;
  globalThis.document = { createElement: () => ({ hidden: false, setAttribute() {} }) };
  globalThis.location = { hash: 'invite=' + 'a'.repeat(32) };
  t.after(() => { globalThis.document = oldDocument; globalThis.location = oldLocation; });
  const relay = createFakeTurnRelay(2), starts = [[], []], reloads = [0, 0];
  const bytes = [new Uint8Array([1, 2, 3]), new Uint8Array([4, 5, 6])];
  const makeController = seat => {
    let connection;
    const parent = { children: [], append(node) { this.children.push(node); } };
    const gameParent = { children: [], append(...nodes) { this.children.push(...nodes); } };
    const invite = { mount(options) {
      const link = relay.connect(seat);
      connection = link;
      const status = { textContent: '' };
      const api = { seat, room: null, send: link.send,
        panel: { querySelector: () => status } };
      queueMicrotask(() => link.bind({
        onState(room) { api.room = room; options.onState(room, api); },
        onMessage(message) { options.onMessage(message, api); },
        onFrame(frame) { options.onFrame(frame, api); },
      }));
      return api;
    } };
    const controller = mountOnline({ parent, gameParent, invite, ready: () => true,
      readSave: async () => new Blob([bytes[seat]]),
      importTurn: async ({save}) => { assert.equal(save.size, 3); return 'Relay.vsgm1'; },
      reload: () => { reloads[seat]++; connection?.close(); },
      start: async options => { starts[seat].push(options); if (seat === 0 && !options.saveName) options.onSeats([0, 1]); },
    });
    return { controller, startButton: parent.children[0], gameStatus: gameParent.children[0] };
  };
  const controllers = [makeController(0), makeController(1)];
  await wait(() => controllers[0].startButton.hidden === false);
  await controllers[0].startButton.onclick();
  assert.equal(starts[0][0].localSeat, 0);
  starts[0][0].onCheckpoint({ phase: 1, save: 'OnlineCheckpoint1.vsgm1' });
  await wait(() => relay.revision === 1);
  assert.equal(relay.checkpoint.phase, 1);
  await starts[0][0].onTurnPass({ seat: 1, save: 'TurnPass.vsgm1', phase: 0 });
  await wait(() => starts[1].length === 1);
  assert.equal(reloads[0], 1);
  assert.equal(starts[1][0].localSeat, 1);
  assert.equal(starts[1][0].saveName, 'Relay.vsgm1');
  assert.equal(starts[1][0].phase, 0);
  // A turn loaded from the relay must upload its checkpoints too (it once passed the loaded metadata instead).
  assert.equal(typeof starts[1][0].onCheckpoint, 'function');
  starts[1][0].onCheckpoint({ phase: 1, save: 'OnlineCheckpoint1.vsgm1' });
  await wait(() => relay.revision === 3);
  assert.equal(relay.checkpoint.phase, 1);
  await starts[1][0].onTurnPass({ seat: 0, save: 'TurnPass.vsgm1', phase: 0 });
  assert.equal(relay.holder, 0);
  assert.equal(relay.revision, 4);
  assert.equal(reloads[1], 1);
  const redAgain = makeController(0);
  await wait(() => starts[0].length === 2).catch(error => {
    throw Error(`${error.message}: ${redAgain.gameStatus.textContent}, ${JSON.stringify(relay.room())}`);
  });
  assert.equal(starts[0][1].localSeat, 0);
  assert.equal(starts[0][1].saveName, 'Relay.vsgm1');
  assert.equal(starts[0][1].phase, 0);
});

test('an offline holder lets another seat claim and resume a phase-two AI save', async t => {
  const oldDocument = globalThis.document, oldLocation = globalThis.location;
  globalThis.document = { createElement: () => ({ hidden: false, setAttribute() {} }) };
  globalThis.location = { hash: 'invite=' + 'b'.repeat(32) };
  t.after(() => { globalThis.document = oldDocument; globalThis.location = oldLocation; });
  const fake = createFakeTurnRelay(2);
  const bytes = new Uint8Array([11, 12, 13]);
  fake.checkpoint = { phase: 2, seat: -1, bytes,
    meta: { colors: [0, 1], sha256: createHash('sha256').update(bytes).digest('hex') } };
  fake.revision = 1;
  const parent = { append() {} }, gameParent = { append() {} }, starts = [];
  const invite = { mount(options) {
    const link = fake.connect(1);
    const api = { seat: 1, room: null, send: link.send, panel: { querySelector: () => null } };
    queueMicrotask(() => link.bind({
      onState(room) { api.room = room; options.onState(room, api); },
      onMessage(message) { options.onMessage(message, api); },
      onFrame(frame) { options.onFrame(frame, api); },
    }));
    return api;
  } };
  mountOnline({ parent, gameParent, invite, ready: () => true,
    importTurn: async ({ save }) => {
      assert.deepEqual(new Uint8Array(await save.arrayBuffer()), bytes);
      return 'Claimed.vsgm1';
    },
    start: async options => { starts.push(options); options.onSeats([0, 1]); },
    reload: () => {},
  });
  await wait(() => starts.length === 1);
  assert.equal(fake.holder, 1);
  assert.equal(fake.lease, 2);
  assert.equal(starts[0].localSeat, 1);
  assert.equal(starts[0].saveName, 'Claimed.vsgm1');
  assert.equal(starts[0].phase, 2);
});
