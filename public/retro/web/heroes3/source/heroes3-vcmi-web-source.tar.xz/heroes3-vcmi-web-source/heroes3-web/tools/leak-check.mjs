// Fail closed before any public build can contain original Heroes III files.
import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { lstat, open, readFile, readdir } from "node:fs/promises";
import { extname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const gameExtensions = new Set([
  ".lod",
  ".snd",
  ".vid",
  ".h3m",
  ".h3c",
  ".iso",
  ".cab",
  ".cue",
]);
const manifestPath = fileURLToPath(
  new URL("../private/heroes3/sha256.json", import.meta.url),
);

async function knownHashes(source) {
  let records;
  try {
    records = JSON.parse(await readFile(source, "utf8"));
  } catch (error) {
    if (error.code === "ENOENT") return new Map();
    throw error;
  }
  if (!records || typeof records !== "object" || Array.isArray(records)) {
    throw Error("Invalid private Heroes III hash manifest.");
  }
  const bySize = new Map();
  for (const record of Object.values(records)) {
    if (
      !Number.isSafeInteger(record?.size) ||
      record.size < 0 ||
      !/^[0-9a-f]{64}$/i.test(record?.sha256)
    ) {
      throw Error("Invalid private Heroes III hash manifest.");
    }
    const hashes = bySize.get(record.size) ?? new Set();
    hashes.add(record.sha256.toLowerCase());
    bySize.set(record.size, hashes);
  }
  return bySize;
}

async function sha256(file) {
  const hash = createHash("sha256");
  for await (const chunk of createReadStream(file)) hash.update(chunk);
  return hash.digest("hex");
}

export async function checkDirectory(
  directory,
  { manifest = manifestPath } = {},
) {
  const root = resolve(directory);
  const hashes = await knownHashes(manifest);
  const failures = [];
  let count = 0;

  async function walk(folder) {
    for (const entry of await readdir(folder, { withFileTypes: true })) {
      const file = join(folder, entry.name);
      const info = await lstat(file);
      if (info.isSymbolicLink()) {
        failures.push(`${file}: symbolic link in public build`);
      } else if (info.isDirectory()) {
        await walk(file);
      } else if (info.isFile()) {
        count++;
        if (gameExtensions.has(extname(entry.name).toLowerCase())) {
          failures.push(`${file}: Heroes III data extension`);
          continue;
        }
        const handle = await open(file, "r");
        const header = Buffer.alloc(4);
        try {
          await handle.read(header, 0, 4, 0);
        } finally {
          await handle.close();
        }
        if (header.toString("ascii", 0, 3) === "LOD") {
          failures.push(`${file}: LOD magic header`);
          continue;
        }
        if (hashes.get(info.size)?.has(await sha256(file))) {
          failures.push(`${file}: matches private Heroes III hash`);
        }
      } else {
        failures.push(`${file}: unsupported public-build entry`);
      }
    }
  }

  await walk(root);
  return { count, failures };
}

if (
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  if (process.argv.length !== 3) {
    console.error("Usage: node tools/leak-check.mjs <public-dir>");
    process.exitCode = 2;
  } else {
    try {
      const { count, failures } = await checkDirectory(process.argv[2]);
      for (const failure of failures) console.error(failure);
      if (failures.length) process.exitCode = 1;
      else
        console.log(
          `PASS: ${count} public files checked; no Heroes III data found.`,
        );
    } catch (error) {
      console.error(error.message);
      process.exitCode = 1;
    }
  }
}
