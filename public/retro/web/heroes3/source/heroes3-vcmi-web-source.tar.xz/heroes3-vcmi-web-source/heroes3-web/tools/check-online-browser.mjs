// Owner-local integration only: synthetic account sessions, sequential Chrome
// profiles, real VCMI, and local Wrangler Workers. No live credentials or API.
import { spawn, execFileSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { access, mkdir, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { resolve, join, sep } from 'node:path';
import WebSocket from '../private/local-relay-test/node_modules/ws/wrapper.mjs';
import { TurnRelayClient } from '../web/turn-transfer.js';

const accounts = process.env.H3_TEST_ACCOUNTS || 'http://127.0.0.1:8842';
const relay = process.env.H3_TEST_RELAY || 'ws://127.0.0.1:8840';
const site = process.env.H3_TEST_SITE || 'http://127.0.0.1:8844';
for (const [label, endpoint, protocol] of [
  ['accounts', accounts, 'http:'], ['relay', relay, 'ws:'], ['site', site, 'http:'],
]) {
  const parsed = new URL(endpoint);
  if (parsed.protocol !== protocol || !['127.0.0.1', 'localhost'].includes(parsed.hostname))
    throw Error(`${label} test endpoint must use loopback ${protocol}`);
}
const fixtures = JSON.parse(await readFile(new URL('../private/local-invite-fixtures.json', import.meta.url)));
const privateRoot = resolve('private') + sep;
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
async function until(check, ms, label) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    const value = await check();
    if (value) return value;
    await pause(300);
  }
  throw Error(`Timed out waiting for ${label}.`);
}
function freeKiB() {
  return Number(execFileSync('powershell', ['-NoProfile', '-Command',
    '(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'], { encoding: 'utf8' }).trim());
}
async function chromePath() {
  for (const path of [process.env.CHROME,
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe']) {
    if (!path) continue;
    try { await access(path); return path; } catch {}
  }
  throw Error('Local Chrome is unavailable.');
}
async function localFiles() {
  const root = resolve(process.env.H3_DATA_DIR || '');
  if (!process.env.H3_DATA_DIR) throw Error('Set H3_DATA_DIR to the owner-local game data.');
  const files = (await readdir(join(root, 'Data'), { withFileTypes: true }))
    .filter(item => item.isFile() && /\.(lod|snd|vid)$/i.test(item.name) && item.name.toLowerCase() !== 'heroes3.vid')
    .map(item => join(root, 'Data', item.name));
  const map = (await readdir(join(root, 'Maps'), { withFileTypes: true }))
    .find(item => item.isFile() && /\.h3m$/i.test(item.name));
  if (map) files.push(join(root, 'Maps', map.name));
  files.push(...(await readdir(join(root, 'Mp3'), { withFileTypes: true }))
    .filter(item => item.isFile() && /\.mp3$/i.test(item.name))
    .map(item => join(root, 'Mp3', item.name)));
  if (files.length < 6) throw Error('Local Heroes III files are incomplete.');
  return files;
}
class CDP {
  constructor(url) {
    this.socket = new globalThis.WebSocket(url);
    this.next = 0;
    this.pending = new Map();
    this.handlers = new Map();
    this.ready = new Promise((resolve, reject) => {
      this.socket.onopen = resolve;
      this.socket.onerror = reject;
    });
    this.socket.onmessage = event => {
      const message = JSON.parse(event.data);
      if (message.id) {
        const job = this.pending.get(message.id);
        if (!job) return;
        this.pending.delete(message.id);
        message.error ? job.reject(Error(message.error.message)) : job.resolve(message.result);
      } else for (const handler of this.handlers.get(message.method) || []) handler(message.params);
    };
  }
  async send(method, params = {}) {
    await this.ready;
    return new Promise((resolve, reject) => {
      const id = ++this.next;
      this.pending.set(id, { resolve, reject });
      this.socket.send(JSON.stringify({ id, method, params }));
    });
  }
  on(method, callback) { this.handlers.set(method, [...(this.handlers.get(method) || []), callback]); }
  close() { this.socket.close(); }
}
async function evaluate(tab, expression) {
  const result = await tab.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (result.exceptionDetails) throw Error(result.exceptionDetails.exception?.description || result.exceptionDetails.text);
  return result.result.value;
}
async function openBrowser(profile, token, url) {
  const free = freeKiB();
  if (!Number.isFinite(free) || free < 2621440) throw Error(`RAM gate: ${free} KiB free; need 2.5 GiB.`);
  if (!resolve(profile).startsWith(privateRoot)) throw Error('Browser profile is outside the isolated private test folder.');
  await rm(join(profile, 'DevToolsActivePort'), { force: true });
  const chrome = spawn(await chromePath(), [
    '--headless=new', '--remote-debugging-port=0', `--user-data-dir=${profile}`,
    '--no-first-run', '--no-default-browser-check', '--disable-gpu',
    '--no-sandbox', '--disable-extensions', '--mute-audio', 'about:blank',
  ], { stdio: 'ignore' });
  let browser, tab;
  try {
    const port = await until(async () => {
      try { return Number((await readFile(join(profile, 'DevToolsActivePort'), 'utf8')).split('\n')[0]); }
      catch { return 0; }
    }, 15000, 'Chrome debugger');
    const version = await (await fetch(`http://127.0.0.1:${port}/json/version`)).json();
    browser = new CDP(version.webSocketDebuggerUrl); await browser.ready;
    const page = await until(async () => (await (await fetch(`http://127.0.0.1:${port}/json`)).json()).find(x => x.type === 'page'), 10000, 'browser tab');
    tab = new CDP(page.webSocketDebuggerUrl); await tab.ready;
    await Promise.all([tab.send('Page.enable'), tab.send('Runtime.enable'), tab.send('DOM.enable')]);
    const logs = [];
    tab.on('Runtime.consoleAPICalled', event => logs.push(event.args.map(x => x.value ?? x.description ?? '').join(' ')));
    tab.on('Runtime.exceptionThrown', event => logs.push(event.exceptionDetails.exception?.description ?? event.exceptionDetails.text));
    await tab.send('Page.addScriptToEvaluateOnNewDocument', {
      source: `try{localStorage.setItem('evonline.session',${JSON.stringify(token)})}catch{}`,
    });
    await tab.send('Page.navigate', { url });
    await until(() => evaluate(tab, `document.readyState==='complete' && !!document.querySelector('#online .tg-invite')`), 30000, 'invite page');
    return { chrome, browser, tab, logs, profile };
  } catch (error) {
    tab?.close(); browser?.close(); chrome.kill();
    throw error;
  }
}
async function closeBrowser(run) {
  if (!run) return;
  if (process.platform === 'win32' && run.chrome.exitCode === null) {
    try { execFileSync('taskkill.exe', ['/PID', String(run.chrome.pid), '/T', '/F'], { stdio: 'ignore' }); }
    catch { run.chrome.kill(); }
  } else run.chrome.kill();
  await Promise.race([new Promise(resolve => run.chrome.once('exit', resolve)), pause(10000)]);
  run.tab.close(); run.browser.close();
  if (process.platform === 'win32') {
    const script = `$target=$env:H3_CHECK_PROFILE; Get-CimInstance Win32_Process -Filter "name = 'chrome.exe'" |
      Where-Object { $_.CommandLine -like "*$target*" } |
      ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`;
    execFileSync('powershell', ['-NoProfile', '-Command', script],
      { env: { ...process.env, H3_CHECK_PROFILE: run.profile }, stdio: 'ignore' });
  }
}
async function importFiles(run, files) {
  const { root } = await run.tab.send('DOM.getDocument');
  const { nodeId } = await run.tab.send('DOM.querySelector', { nodeId: root.nodeId, selector: '#files-input' });
  if (!nodeId) throw Error('Game file picker is missing.');
  await run.tab.send('DOM.setFileInputFiles', { nodeId, files });
  await until(async () => {
    const state = await evaluate(run.tab, `({ready:!document.getElementById('launch').disabled,status:document.getElementById('status').textContent})`);
    if (/failed|could not|missing required/i.test(state.status)) throw Error(state.status);
    return state.ready;
  }, 300000, 'local game-file import');
}
async function click(run, x, y) {
  const bounds = await evaluate(run.tab, `(()=>{const r=document.getElementById('canvas').getBoundingClientRect();return {left:r.left,top:r.top,width:r.width,height:r.height}})()`);
  const point = { x: Math.round(bounds.left + bounds.width * x / 800), y: Math.round(bounds.top + bounds.height * y / 600) };
  for (const type of ['mouseMoved', 'mousePressed', 'mouseReleased'])
    await run.tab.send('Input.dispatchMouseEvent', { type, ...point,
      button: type === 'mouseMoved' ? 'none' : 'left', buttons: type === 'mousePressed' ? 1 : 0, clickCount: 1 });
}
async function screenshot(run, name) {
  await mkdir('shots', { recursive: true });
  const image = await run.tab.send('Page.captureScreenshot', { format: 'png' });
  await writeFile(`shots/${name}.png`, Buffer.from(image.data, 'base64'));
}
async function seatReady(run, seat) {
  await until(() => run.logs.some(line => line.includes(`Player ${seat ? 'blue' : 'red'} will be lead by human`)), 240000, 'local human interface');
  const humans = run.logs.filter(line => line.includes('will be lead by human'));
  if (humans.length !== 1) throw Error(`Expected one local human: ${humans.join(' | ')}`);
  const layout = await evaluate(run.tab, `(()=>({
    canvas:document.getElementById('canvas').getBoundingClientRect().width,
    retry:getComputedStyle([...document.querySelectorAll('#online-turn button')].find(b=>b.textContent==='Retry handoff')).display
  }))()`);
  if (layout.canvas < 400 || layout.retry !== 'none')
    throw Error(`Online layout shrank the canvas or exposed Retry: ${JSON.stringify(layout)}`);
}
async function endTurn(run, seat) {
  await screenshot(run, `online-${seat}-before-end`);
  await click(run, 400, 400); // privacy prompt if present
  await pause(3000);
  await click(run, 400, 415); // fixture start-of-turn rumour
  await pause(1000);
  await screenshot(run, `online-${seat}-ready-to-end`);
  await evaluate(run.tab, `[...document.querySelectorAll('#touch-bar button')].find(b=>b.textContent==='End turn').click()`);
  await pause(1500);
  await click(run, 355, 350); // end-turn confirmation
  await screenshot(run, `online-${seat}-after-end`).catch(() => {});
}
async function joinedRoom(id) {
  const socket = new WebSocket(`${relay}/invite/heroes3/${id}`,
    ['tg-invite', `tg-auth.${fixtures[1].token}`], { headers: { Origin: site } });
  await new Promise((resolve, reject) => { socket.once('open', resolve); socket.once('error', reject); });
  const heartbeat = setInterval(() => { if (socket.readyState === WebSocket.OPEN) socket.send('~'); }, 25000);
  return { socket, close() { clearInterval(heartbeat); socket.close(); } };
}
async function seededBattleRoom() {
  const id = randomBytes(16).toString('hex');
  async function connect(seat, query = '') {
    const socket = new WebSocket(`${relay}/invite/heroes3/${id}${query}`,
      ['tg-invite', `tg-auth.${fixtures[seat].token}`], { headers: { Origin: site } });
    const state = { room: null, seat: null, frames: [], client: null };
    socket.on('message', (raw, binary) => {
      if (binary) { state.frames.push(raw); return; }
      let message;
      try { message = JSON.parse(raw.toString()); } catch { return; }
      if (message.type === 'welcome') state.seat = message.seat;
      else if (message.type === 'room') { state.room = message; state.client?.onState(message); }
      else state.client?.onMessage(message);
    });
    await new Promise((resolve, reject) => { socket.once('open', resolve); socket.once('error', reject); });
    await until(() => state.room && state.seat !== null, 10000, 'local battle room');
    state.client = new TurnRelayClient({ seat: state.seat, send: value => {
      socket.send(value instanceof ArrayBuffer ? Buffer.from(value) : JSON.stringify(value)); return true;
    } });
    state.client.onState(state.room);
    return { socket, state };
  }
  const redSeed = await connect(0, '?host=1&players=2&bot=wait');
  let blue;
  try {
    blue = await connect(1);
    await until(() => redSeed.state.room.players.length === 2, 10000, 'two battle seats');
    const save = await readFile('shots/turn-pass-source.vsgm1');
    await redSeed.state.client.upload({ save: new Blob([save]), lease: redSeed.state.room.lease,
      phase: 1, saveSeat: 0, colors: [0, 1], order: [0, 1] });
    await until(() => blue.state.room?.checkpointPhase === 1 && blue.state.room.savedAt,
      10000, 'seeded battle checkpoint');
    const seededAt = blue.state.room.savedAt;
    redSeed.socket.close();
    const heartbeat = setInterval(() => {
      if (blue.socket.readyState === WebSocket.OPEN) blue.socket.send('~');
    }, 25000);
    return { id, seededAt, blue: { ...blue, close() { clearInterval(heartbeat); blue.socket.close(); } } };
  } catch (error) { blue?.socket.close(); redSeed.socket.close(); throw error; }
}
async function roomFor(seat, id) {
  const response = await fetch(`${relay.replace(/^ws/, 'http')}/games`, {
    headers: { Origin: site, Authorization: `Bearer ${fixtures[seat].token}` },
  });
  if (!response.ok) return null;
  return (await response.json()).games.find(game => game.id === id);
}
const url = id => `${site}/?online=1&inviteRelay=${encodeURIComponent(relay)}${id ? '#invite=' + id : ''}`;
let red, blue, temporaryBlue, battleBlue;
const profiles = [];
try {
  const files = await localFiles();
  // The three local services must already be listening. No live endpoint is called.
  for (const endpoint of [accounts + '/api/me', site + '/tg-invite.js']) {
    const response = await fetch(endpoint);
    if (response.status >= 500) throw Error(`Local service unavailable: ${endpoint}`);
  }
  const config = await (await fetch(site + '/config.js')).text();
  if (!config.includes('enabled:false') || !config.includes("apiBase:'http://127.0.0.1:8842'"))
    throw Error('Local browser test requires the loopback-only --test-local-files server flag.');
  const redProfile = await mkdtemp(resolve('private/local-browser-red-'));
  profiles.push(redProfile);
  if (process.env.H3_BATTLE_ONLY === '1') {
    const seeded = await seededBattleRoom();
    battleBlue = seeded.blue;
    red = await openBrowser(redProfile, fixtures[0].token, url(seeded.id));
    await importFiles(red, files);
    await evaluate(red.tab, `document.querySelector('#online [data-join]').click()`);
    await seatReady(red, 0);
    await click(red, 400, 415); // dismiss the start-of-turn banner before server ticks advance
    await until(() => evaluate(red.tab, `window.__h3Battles?.some(event=>event.active && event.attacker===0 && event.defender===1)`),
      60000, 'relay-driven native human battle');
    await until(() => battleBlue.state.room?.controller === 1 && battleBlue.state.frames.some(frame =>
      frame[0] === 1 && frame[1] === 0xff && frame[2] === 0xd8), 60000, 'remote battle view and control');
    await until(() => battleBlue.state.room?.checkpointPhase === 1 &&
      battleBlue.state.room.savedAt > seeded.seededAt, 60000, 'fresh pre-battle checkpoint');
    const battleCheckpointAt = battleBlue.state.room.savedAt;
    const before = await evaluate(red.tab, `window.__h3Battles.filter(event=>event.control===1).length`);
    for (const event of ['keydown', 'keyup']) battleBlue.socket.send(JSON.stringify({
      type: 'input', event, code: 'Space', key: ' ', keyCode: 32,
    }));
    await until(async () => (await evaluate(red.tab,
      `window.__h3Battles.filter(event=>event.control===1).length`)) > before,
    30000, 'relay-driven Blue battle action');
    if (red.logs.some(line => line.includes('Player is not allowed to perform this action!')))
      throw Error('Native server refused the remote human battle action.');
    console.log('PASS relay-driven human battle: private JPEG frame, Blue control, SDL action, no server refusal.');
    await closeBrowser(red); red = null;
    await until(() => battleBlue.state.room?.players.find(player => player.seat === 0)?.online === false,
      15000, 'offline battle holder');
    if (battleBlue.state.room.checkpointPhase !== 1 || battleBlue.state.room.savedAt !== battleCheckpointAt)
      throw Error('Relay lost the last safe pre-battle checkpoint when the holder closed.');
    red = await openBrowser(redProfile, fixtures[0].token, url(seeded.id));
    await evaluate(red.tab, `document.querySelector('#online [data-join]').click()`);
    await seatReady(red, 0);
    await click(red, 400, 415); // a restored turn may open with VCMI's turn banner
    await until(() => evaluate(red.tab,
      `window.__h3Battles?.some(event=>event.active && event.attacker===0 && event.defender===1)`),
    60000, 'restarted human battle after holder recovery');
    console.log('PASS battle rollback: fresh phase-one checkpoint survived holder close and reopened on the same seat.');
  } else {
  const blueProfile = await mkdtemp(resolve('private/local-browser-blue-'));
  profiles.push(blueProfile);
  red = await openBrowser(redProfile, fixtures[0].token, url());
  await importFiles(red, files);
  await evaluate(red.tab, `document.querySelector('#online [data-create]').click()`);
  const id = await until(() => evaluate(red.tab, `new URLSearchParams(location.hash.slice(1)).get('invite')`), 15000, 'new invite ID');
  if (!/^[a-f0-9]{32}$/.test(id)) throw Error('Bad invite ID.');
  temporaryBlue = await joinedRoom(id);
  await until(() => evaluate(red.tab, `!document.querySelector('#online button').hidden`), 15000, 'second seat');
  await evaluate(red.tab, `document.querySelector('#online button').click()`);
  await until(() => red.logs.some(line => line.includes('All game content loaded')), 240000, 'creator engine initialization');
  await pause(10000);
  for (const [x, y, delay] of [[644,70,5000],[649,180,5000],[578,178,5000]]) { await click(red,x,y); await pause(delay); }
  await click(red,410,219);
  for (const letter of 'Second') await red.tab.send('Input.dispatchKeyEvent', { type: 'char', text: letter, unmodifiedText: letter });
  await pause(1000);
  await click(red,343,450); await pause(12000);
  await click(red,490,558);
  await seatReady(red,0);
  await endTurn(red,0);
  await until(async () => (await roomFor(1,id))?.yourTurn, 120000, 'Blue relay turn');
  await evaluate(red.tab, `import('/saves.js').then(m=>m.importSave(
    new File(['STALE LOCAL TEST SAVE'],'TurnPass-${id}-r1.vsgm1')))`);
  console.log('Red created and passed the real browser game to Blue.');
  await closeBrowser(red); red = null; temporaryBlue.close(); temporaryBlue = null;
  blue = await openBrowser(blueProfile, fixtures[1].token, url(id));
  await importFiles(blue, files);
  await evaluate(blue.tab, `document.querySelector('#online [data-join]').click()`);
  await seatReady(blue,1);
  await endTurn(blue,1);
  await until(async () => (await roomFor(0,id))?.yourTurn, 120000, 'Red relay return');
  console.log('Blue loaded and passed the real browser game back to Red.');
  await closeBrowser(blue); blue = null;
  red = await openBrowser(redProfile, fixtures[0].token, url(id));
  await evaluate(red.tab, `document.querySelector('#online [data-join]').click()`);
  await seatReady(red,0);
  await until(() => evaluate(red.tab, `import('/saves.js').then(async m=>{
    const names=(await m.listSaves()).map(save=>save.name).filter(name=>
      /^TurnPass-${id}-r[1-9]\\d*(?: \\(\\d+\\))?\\.vsgm1$/.test(name));
    return names.length===1 && names[0]!=='TurnPass-${id}-r1.vsgm1';
  })`), 30000, 'old imported match save cleanup after native Red load');
  console.log('PASS sequential browsers: create, join, Red End turn, Blue load and End turn, Red load.');
  }
} catch (error) {
  console.error(error.message);
  for (const [name, run] of [['Red', red], ['Blue', blue]])
    if (run) {
      try { await screenshot(run, `online-${name.toLowerCase()}-error`); } catch {}
      try {
        console.error(`${name} lobby: ${JSON.stringify(await evaluate(run.tab, `({
          url:location.href,token:!!localStorage.getItem('evonline.session'),
          status:document.querySelector('#online [data-status]')?.textContent,
          createDisabled:document.querySelector('#online [data-create]')?.disabled,
          createHidden:document.querySelector('#online [data-create]')?.hidden,
          setupHidden:document.getElementById('setup')?.hidden
        })`))}`);
      } catch {}
      console.error(`${name} last logs: ${run.logs.slice(-25).join(' | ')}`);
    }
  process.exitCode = 1;
} finally {
  temporaryBlue?.close();
  battleBlue?.close();
  await closeBrowser(red); await closeBrowser(blue);
  for (const profile of profiles) {
    if (!resolve(profile).startsWith(privateRoot)) throw Error('Refusing to clean a profile outside the isolated private test folder.');
    await rm(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 500 });
  }
}
