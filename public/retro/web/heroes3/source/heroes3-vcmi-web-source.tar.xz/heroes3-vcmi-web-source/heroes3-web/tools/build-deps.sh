#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/env.sh"
source "$PROJECT_ROOT/tools/ramgate.sh"
mkdir -p "$PREFIX" "$PROJECT_ROOT/deps/build"
preflight_ports() {
  local missing=0 entry
  for entry in \
    'freetype/freetype-VER-2-13-3' \
    'harfbuzz/harfbuzz-3.2.0' \
    'libpng/libpng-1.6.39' \
    'sdl2/SDL-release-2.32.8' \
    'sdl2_image/SDL_image-release-2.6.0' \
    'sdl2_mixer/SDL_mixer-release-2.8.0' \
    'sdl2_ttf/SDL_ttf-release-2.20.2' \
    'ogg/libogg-1.3.5' \
    'vorbis/libvorbis-1.3.7' \
    'mpg123/mpg123-1.26.2' \
    'zlib/zlib-1.3.1'; do
    if [[ ! -d "$EM_CACHE/ports/$entry" ]]; then
      printf 'Missing offline Emscripten port source: %s\n' "$EM_CACHE/ports/$entry" >&2
      missing=1
    fi
  done
  if (( missing )); then
    echo 'Stopping before Emscripten attempts a network fetch.' >&2
    return 1
  fi
}
preflight_ports
stamp_dir="$PREFIX/.stamps"
mkdir -p "$stamp_dir"
build_one() {
  local name="$1"; shift
  if [[ -f "$stamp_dir/$name" && "${FORCE:-0}" != 1 ]]; then
    echo "skip $name (installed)"
    return
  fi
  ramgate
  "$@"
  touch "$stamp_dir/$name"
}
cmake_build_install() {
  local name="$1"; shift
  ramgate
  cmake --build "$PROJECT_ROOT/deps/build/$name" --parallel "$JOBS"
  cmake --install "$PROJECT_ROOT/deps/build/$name"
}
boost_build() {
  local dir="$PROJECT_ROOT/deps/build/boost"
  emcmake cmake --fresh -S "$PROJECT_ROOT/deps/src/boost-1.86.0" -B "$dir" -G Ninja \
    -DCMAKE_INSTALL_PREFIX="$PREFIX" -DCMAKE_BUILD_TYPE=Release \
    -DBUILD_SHARED_LIBS=OFF -DBOOST_INCLUDE_LIBRARIES='date_time;filesystem;locale;program_options' \
    -DBOOST_LOCALE_ENABLE_ICU=OFF -DBOOST_LOCALE_ENABLE_POSIX=OFF \
    -DBOOST_LOCALE_ENABLE_STD=ON -DBOOST_LOCALE_ENABLE_ICONV=ON
  cmake_build_install boost
  # Install header-only libraries without enabling their native binary targets.
  # VCMI uses Format, Asio and other transitive headers beyond the four archives.
  local headers
  for headers in "$PROJECT_ROOT"/deps/src/boost-1.86.0/libs/*/include/boost; do
    if [[ -d "$headers" ]]; then cp -R "$headers/." "$PREFIX/include/boost/"; fi
  done
}
minizip_build() {
  local src="$PROJECT_ROOT/deps/src/zlib-1.3.1/contrib/minizip" out="$PROJECT_ROOT/deps/build/minizip"
  mkdir -p "$out" "$PREFIX/lib" "$PREFIX/include/minizip"
  local f
  for f in ioapi.c unzip.c zip.c; do
    ramgate
    emcc $CFLAGS -I"$PROJECT_ROOT/deps/src/zlib-1.3.1" -I"$PREFIX/include" -c "$src/$f" -o "$out/${f%.c}.o"
  done
  "$PROJECT_ROOT/deps/build/llvm-bin/llvm-ar.exe" rcs "$PREFIX/lib/libminizip.a" "$out/ioapi.o" "$out/unzip.o" "$out/zip.o"
  cp "$src"/{ioapi.h,unzip.h,zip.h} "$PREFIX/include/minizip/"
}
squish_build() {
  emcmake cmake -S "$PROJECT_ROOT/deps/src/libsquish-1.15" -B "$PROJECT_ROOT/deps/build/squish" -G Ninja \
    -DCMAKE_INSTALL_PREFIX="$PREFIX" -DCMAKE_BUILD_TYPE=Release -DBUILD_SHARED_LIBS=OFF \
    -DBUILD_SQUISH_WITH_OPENMP=OFF -DBUILD_SQUISH_WITH_SSE2=OFF -DBUILD_SQUISH_WITH_ALTIVEC=OFF -DCMAKE_POLICY_VERSION_MINIMUM=3.5
  cmake_build_install squish
  mkdir -p "$PREFIX/include/squish"
  cp "$PROJECT_ROOT/deps/src/libsquish-1.15/squish.h" "$PREFIX/include/squish/"
}
ports_build() {
  local out="$PROJECT_ROOT/deps/build/ports"
  mkdir -p "$out"
  printf 'int main(void) { return 0; }\n' > "$out/probe.c"
  # SDL2_ttf's port build invokes emcc recursively for plain FreeType. Warm
  # that variant first to avoid Emscripten's non-reentrant cache lock.
  ramgate
  emcc "$out/probe.c" -c -sUSE_FREETYPE=1 -o "$out/freetype.o"
  ramgate
  emcc "$out/probe.c" $CFLAGS $LDFLAGS \
    -sUSE_ZLIB=1 -sUSE_SDL=2 -sUSE_SDL_IMAGE=2 \
    -sSDL2_IMAGE_FORMATS='["png","bmp","tga","pcx"]' \
    -sUSE_SDL_MIXER=2 -sSDL2_MIXER_FORMATS='["mp3","ogg"]' \
    -sUSE_SDL_TTF=2 -o "$out/probe.js"
}
tbb_install() {
  mkdir -p "$PREFIX/include/tbb" "$PREFIX/lib/cmake/TBB"
  cp "$PROJECT_ROOT/compat/tbb/include/tbb/"*.h "$PREFIX/include/tbb/"
  cp "$PROJECT_ROOT/compat/tbb/TBBConfig.cmake" "$PREFIX/lib/cmake/TBB/"
}
cmake_shims_install() {
  local name
  for name in SDL2 SDL2_image SDL2_mixer SDL2_ttf; do
    mkdir -p "$PREFIX/lib/cmake/$name"
    cp "$PROJECT_ROOT/cmake/wasm/Find$name.cmake" "$PREFIX/lib/cmake/$name/${name}Config.cmake"
  done
  mkdir -p "$PREFIX/lib/cmake/ZLIB"
  cp "$PROJECT_ROOT/cmake/wasm/ZLIBConfig.cmake" "$PREFIX/lib/cmake/ZLIB/"
}
build_one boost boost_build
build_one sdl_ports ports_build
build_one minizip minizip_build
build_one squish squish_build
build_one tbb tbb_install
build_one cmake_shims cmake_shims_install
bash "$PROJECT_ROOT/tools/test-tbb-shim.sh"
echo 'All dependencies installed or cached.'
