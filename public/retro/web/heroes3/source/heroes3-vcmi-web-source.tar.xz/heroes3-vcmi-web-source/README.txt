Heroes III on Teng Games: corresponding source for the 2026-11-13 web update

VCMI 1.7.5 base 6901839ae9760dfcd1d5ff2c4aa4ef6968fee752, browser project
engine revision e53754d; web revision 124811b. See BUILD-MANIFEST.json for exact engine artifact hashes.
The combined engine is GPL-3.0; see vcmi/license.txt and the license files
in each dependency (including vcmi/AI/FuzzyLite). No original game data.

vcmi/ contains the complete patched VCMI sources and bundled FuzzyLite.
heroes3-web/ contains the web code, native patch, compatibility shims, build
scripts and tests. deps/ports contains all eleven Emscripten port source trees
used by build-deps.sh, including the actual patched SDL2 2.32.8 audio source.
deps/src contains zlib 1.3.1/minizip and libsquish 1.15.
Download the companion boost-1.86.0-cmake.tar.xz from the same source page.
SHA-256: 2c5ec5edcdff47ff55e27ed9560b0a0b94b07bd07ed9928b476150e16b0efc57
It is separate to keep each source download below the Git hosting file limit.

Build preparation (Windows / Git Bash):
1. Use heroes3-web as the project directory. Place vcmi at engines/vcmi,
   deps/ports at deps/em-cache/ports and deps/src at deps/src in that project.
2. Extract the Boost companion archive to deps/src/boost-1.86.0.
3. Install Emscripten SDK 4.0.15, CMake, Ninja, Python and Node. Adjust the
   machine-specific SDK, Python, Node and CMake locations in tools/env.sh.
   The shipped env.sh records the exact environment used by this build.
4. From Git Bash run bash tools/build-deps.sh then bash tools/build-engine.sh.
   These scripts use a RAM gate and conservative compilation parallelism.
   The VCMI patch is already applied; do not apply it a second time.
5. Output is web/engine/vcmiclient.js, .wasm and .data. Serve web with the
   COOP/COEP isolation headers documented by tools/serve.mjs and the launcher.

The release used existing matching engine/dependency objects, rebuilt all
119 SDL2 objects, compiled the updated server CGameHandler, then relinked.
A clean source build may differ byte-for-byte due to build paths/tool versions.
The source contains the final code, not the old donor build artifacts.
The browser launcher requires the player to import their own licensed files.

The upstream TerrainViewTest.h3m map fixture is excluded by the public game-data
filter. It is not needed to build the engine; the optional native terrain-view
fixture test requires obtaining that map from the upstream VCMI source.
