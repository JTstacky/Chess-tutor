Heroes III on Teng Games: complete corresponding source (GPL-3.0)

This is the source for the WebAssembly build of the VCMI engine served at
tenggames.com.au/heroes3/. It contains no Heroes of Might and Magic III game
files; players supply their own licensed files.

vcmi/          VCMI 1.7.5 (https://github.com/vcmi/vcmi, commit 6901839ae9760dfcd1d5ff2c4aa4ef6968fee752)
               with the browser changes already applied. The same changes are
               in heroes3-web/patches/vcmi-1.7.5-web.patch.
heroes3-web/   The web page, launcher, touch controls, online turn code, build
               scripts (tools/build-deps.sh, tools/build-engine.sh) and tests
               (project revision 1f01c5b). docs/BUILD-NOTES.md explains the build.
deps/          zlib 1.3.1 (with minizip), libsquish 1.15, and the mpg123
               source used by the Emscripten port (LGPL-2.1).
               Boost 1.86.0 (Boost Software License) is not bundled because of
               its size: https://github.com/boostorg/boost/releases/tag/boost-1.86.0
               (boost-1.86.0-cmake.tar.xz, SHA-256 2c5ec5edcdff47ff55e27ed9560b0a0b94b07bd07ed9928b476150e16b0efc57).
               SDL2, SDL2_image, SDL2_mixer, SDL2_ttf, freetype, harfbuzz,
               libpng, libogg, libvorbis come from Emscripten 4.0.15's ports at
               the versions listed in heroes3-web/tools/build-deps.sh. SDL2 is
               built with one change, applied by tools/build-engine.sh: the
               sample-rate read in src/audio/emscripten/SDL_emscriptenaudio.c
               uses MAIN_THREAD_EM_ASM_INT.

Build: Emscripten 4.0.15, then tools/build-deps.sh and tools/build-engine.sh.
Licence: GPL-3.0 for the combined work (vcmi/license.txt). Each dependency
keeps its own licence.
