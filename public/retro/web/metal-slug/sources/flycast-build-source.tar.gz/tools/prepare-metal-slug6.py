"""Prepare private startup data and public hash metadata; never publish game bytes."""
from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).resolve().parents[1]
private=root/'private/metal-slug-6-arcade'
shutil.copyfile(root/'private/metal-slug-6-bootstrap/boot.gz',private/'boot.gz')
files={name:hashlib.sha256((private/name).read_bytes()).hexdigest() for name in ['mslug6.7z','awbios.7z','boot.gz']}
core=hashlib.sha256((root/'web/metal-slug/vendor/cores/flycast_libretro.wasm').read_bytes()).hexdigest()
target=root/'web/metal-slug-6';target.mkdir(exist_ok=True)
(target/'engine.json').write_text(json.dumps({'build':'flycast6-'+core[:16]+'-'+files['mslug6.7z'][:16],'coreSha256':core,'files':files},indent=2)+'\n',encoding='utf-8')
print('Prepared private bootstrap and engine identity metadata.')
