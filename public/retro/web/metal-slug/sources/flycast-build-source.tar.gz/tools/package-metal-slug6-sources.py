"""Package exact source trees for the reproducible Metal Slug 6 engine build.
Run after tools/build-metal-slug6.sh completes. Does not include original games.
"""
from pathlib import Path
import subprocess, tarfile, json, hashlib
root=Path(__file__).resolve().parents[1]
work=root/'tools/_work/metal-slug'
out=root/'web/metal-slug/sources'
# Git metadata and compiled outputs are excluded; vendored dependency source stays.
for name,tree in [('flycast-source','flycast'),('flycast-retroarch-source','retroarch-flycast-eh-sync')]:
    target=work/(name+'.tar.gz')
    with target.open('wb') as f:
        subprocess.run(['docker','run','--rm','-v','metal-slug-engine-build:/build','alpine','tar','czf','-','--exclude=.git','--exclude=build-wasm-prod','--exclude=obj-emscripten','--exclude=*.o','--exclude=*.a','--exclude=*.wasm','--exclude=retroarch.js','-C','/build',tree],stdout=f,check=True)
    with target.open('rb') as source:
        index=1
        while chunk:=source.read(20*1024*1024):
            (out/f'{name}.tar.gz.part{index}').write_bytes(chunk); index+=1
with tarfile.open(out/'flycast-build-source.tar.gz','w:gz') as archive:
    for relative in ['tools/build-metal-slug6.sh','tools/metal-slug6-platform.c','tools/prepare-flycast-runtime.py','tools/prepare-metal-slug6.py','tools/package-metal-slug6-sources.py','engines/flycast-wasm/build-prod.sh','engines/flycast-wasm/build/gl_override.js']:
        archive.add(root/relative,arcname=relative)
    for file in (root/'engines/flycast-wasm/patches').rglob('*'):
        if file.is_file(): archive.add(file,arcname=str(file.relative_to(root)))
    for relative in ['engines/flycast-wasm/LICENSE','engines/flycast-wasm/README.md']:
        if (root/relative).exists(): archive.add(root/relative,arcname=relative)
print('Corresponding Flycast sources packaged. Regenerate shared manifest with package-metal-slug-sources.py.')
