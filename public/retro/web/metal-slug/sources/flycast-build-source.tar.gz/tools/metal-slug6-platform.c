// Browser GL entry point. WebGL compatibility is handled by the JS GL layer.
#include <GLES3/gl3.h>
#include <stddef.h>
extern const GLubyte *__real_glGetString(GLenum name);
const GLubyte *__wrap_glGetString(GLenum name) {
    return __real_glGetString(name);
}
// Bridge the older Flycast frontend API to the pinned RetroArch path helpers.
extern const char *path_basename(const char *path);
extern size_t fill_pathname(char *out, const char *in, const char *replace, size_t size);
void fill_short_pathname_representation(char *out, const char *path, size_t size) {
    fill_pathname(out, path_basename(path), "", size);
}
