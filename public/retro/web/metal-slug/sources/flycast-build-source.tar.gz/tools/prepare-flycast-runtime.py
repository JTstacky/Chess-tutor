from pathlib import Path
import re
import shutil
root=Path(__file__).resolve().parents[1]
source=root/'tools/_work/metal-slug/flycast-rebuilt'
target=root/'web/metal-slug/vendor/cores'
text=(source/'flycast_libretro.js').read_text(encoding='utf-8')
marker='Module["AL"]=AL;'
if marker not in text: raise RuntimeError('Missing main-loop export marker')
text=text.replace(marker,'Module["__tengMainLoop"]=MainLoop;'+marker)
# The upstream build does not link libzip. Report a failed open instead of
# aborting, so Flycast's own verified 7z archive reader gets the request.
failed={'zip_source_filep_create':0,'zip_source_buffer_create':0,'zip_open_from_source':0,
        'zip_close':0,'zip_fclose':0,'zip_source_free':0,'zip_fopen':0,'zip_fopen_index':0,
        'zip_fread':-1,'zip_stat':-1,'zip_stat_index':-1,'zip_get_num_entries':-1}
for name,value in failed.items():
    text,count=re.subn(r'function _'+name+r'\(\)\{abort\("missing function: '+name+r'"\)\}',f'function _{name}(){{return {value}}}',text)
    if count>1: raise RuntimeError(f'Unexpected upstream import: {name} ({count})')
(target/'flycast_libretro.js').write_text(text,encoding='utf-8')
shutil.copyfile(source/'flycast_libretro.wasm',target/'flycast_libretro.wasm')
print('Prepared rebuilt Flycast runtime with native 7z fallback.')
