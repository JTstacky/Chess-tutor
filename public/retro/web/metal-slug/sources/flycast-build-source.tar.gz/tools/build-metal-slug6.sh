#!/usr/bin/env bash
# Dedicated Docker volume; no original game data is used by this build.
set -euo pipefail
cd /build
if [ ! -d flycast ]; then git clone --filter=blob:none https://github.com/flyinghead/flycast.git flycast; fi
cd flycast
if [ ! -f .metal-slug-patched ]; then
 git checkout 2c48c01
 git submodule update --init --recursive --depth 1 --jobs 2
 sed 's/\r$//' /workspace/engines/flycast-wasm/patches/wasm-jit-phase1-modified.patch > /build/flycast-port.patch
 sed -i 's/\r$//' shell/libretro/audiostream.cpp
 git apply /build/flycast-port.patch
 mkdir -p core/rec-wasm
 cp /workspace/engines/flycast-wasm/patches/{rec_wasm.cpp,wasm_emit.h,wasm_module_builder.h,fly_instrument.h} core/rec-wasm/
 # Atomiswave boot performs writes outside the Dreamcast page-generation paths.
 # Retain the existing full-block hash safety check while investigating coverage.
 sed -i 's/#define FLY_SMC_INSURANCE_TICK 0/#define FLY_SMC_INSURANCE_TICK 1/' core/rec-wasm/rec_wasm.cpp
 touch .metal-slug-patched
fi
cmp -s /workspace/engines/flycast-wasm/patches/rec_wasm.cpp core/rec-wasm/rec_wasm.cpp || cp /workspace/engines/flycast-wasm/patches/rec_wasm.cpp core/rec-wasm/rec_wasm.cpp
if [ "${FLYCAST_WASM_EH:-0}" = 1 ]; then
 sed -i 's/PRIVATE -fexceptions)/PRIVATE -fwasm-exceptions)/' CMakeLists.txt
else
 sed -i 's/PRIVATE -fwasm-exceptions)/PRIVATE -fexceptions)/' CMakeLists.txt
fi
# Upstream audio diagnostics call the JS clock four times per 44.1kHz sample.
# Keep these timers for debug builds only; audio generation itself is unchanged.
python3 - <<'PY'
from pathlib import Path
p=Path('core/hw/aica/aica.cpp')
s=p.read_text(); original=s
start=s.index('static int AicaUpdate(')
end=s.index('static void AicaInternalDMA()',start)
s=s[:start]+s[start:end].replace('#ifdef __EMSCRIPTEN__','#if defined(__EMSCRIPTEN__) && !defined(FLY_RELEASE_BUILD)')+s[end:]
if s!=original: p.write_text(s)
PY
# The clean BIOS path already checks every block. Use upstream page-generation
# validation in the fast path; the extra debug hash pass is not a release default.
cd /build
if [ ! -d retroarch ]; then git clone --filter=blob:none https://github.com/EmulatorJS/RetroArch.git retroarch; git -C retroarch checkout 6dd4353937ef48b6ec0bfbdbb15d1c5992d86927; fi
# Use the upstream clean dispatcher for safe BIOS startup, then the optimized
# chained dispatcher once the original boot code has completed (browser probe).
if [ "${1:-build}" = prepare ]; then exit; fi
ra_dir=/build/retroarch
async=1
if [ "${FLYCAST_SYNC:-0}" = 1 ]; then
 ra_dir=/build/retroarch-flycast-sync
 async=0
 if [ "${FLYCAST_WASM_EH:-0}" = 1 ]; then ra_dir=/build/retroarch-flycast-eh-sync; fi
 if [ ! -d "$ra_dir" ]; then
  mkdir -p "$ra_dir"
  git -C /build/retroarch archive 6dd4353937ef48b6ec0bfbdbb15d1c5992d86927 | tar -x -C "$ra_dir"
  # OpenAL normally forces Asyncify even when ASYNC=0 is supplied.
  sed -i 's/override ASYNC = 1/override ASYNC = 0/' "$ra_dir/Makefile.emulatorjs"
  if [ "${FLYCAST_WASM_EH:-0}" = 1 ]; then
   printf '\nCFLAGS += -fwasm-exceptions\nCXXFLAGS += -fwasm-exceptions\nLDFLAGS += -fwasm-exceptions\n' >> "$ra_dir/Makefile.emulatorjs"
  fi
 fi
fi
cd "$ra_dir"
# Build the frontend object files with the same audio/GLES configuration as Flycast.
emar crs libretro_emscripten.a
emmake make -j2 -f Makefile.emulatorjs LIBRETRO=dummy HAVE_OPENGLES3=1 HAVE_AL=1 HAVE_RWEBAUDIO=0 ASYNC="$async" HAVE_CHD=1 HAVE_7ZIP=1 TARGET=retroarch.js
cd /build
sed 's/\r$//' /workspace/engines/flycast-wasm/build-prod.sh > ./build-flycast.sh
sed -i 's/make -j"$(nproc)"/make -j2/; s/glsym_es3"/glsym_es3|libretro_dummy"/' ./build-flycast.sh
sed -i 's/emcc -O3 -flto /emcc -O3 -flto --profiling-funcs /' ./build-flycast.sh
if [ "${FLYCAST_OPTIMIZE:-0}" = 1 ]; then
 sed -i 's/-DJIT_PROD_BUILD=1 /-flto -msimd128 -mnontrapping-fptoint -DJIT_PROD_BUILD=1 /g; s/emcc -O3 -flto /emcc -O3 -flto -msimd128 -mnontrapping-fptoint /' ./build-flycast.sh
fi
if [ "$async" = 0 ]; then
 sed -i '/-s ASYNCIFY_STACK_SIZE=/d; /-s .*ASYNCIFY_REMOVE=/d; s/-s ASYNCIFY=1/-s ASYNCIFY=0/' ./build-flycast.sh
fi
if [ "${FLYCAST_WASM_EH:-0}" = 1 ]; then
 sed -i '/-s DISABLE_EXCEPTION_CATCHING=0/d; s/-fexceptions/-fwasm-exceptions/g' ./build-flycast.sh
fi
export SOURCE_DIR=/build/flycast BUILD_DIR=/build/flycast/build-wasm-prod EJS_RA="$ra_dir"
export STUBS=/workspace/engines/flycast-wasm/build/flycast_stubs.o GL_OVERRIDE=/workspace/engines/flycast-wasm/build/gl_override.js
if [ "${FLYCAST_NO_STUBS:-0}" = 1 ]; then
 sed -i 's/ -Wl,--allow-undefined//; s/-s WARN_ON_UNDEFINED_SYMBOLS=0/-s WARN_ON_UNDEFINED_SYMBOLS=1 -s ERROR_ON_UNDEFINED_SYMBOLS=1/' ./build-flycast.sh
 sed -i 's/|chd_stream//; /"$BUILD_DIR\/libflycast-resources.a"/a\  "$BUILD_DIR/core/deps/libzip/lib/libzip.a" \\' ./build-flycast.sh
 sed -i '/"$BUILD_DIR\/libflycast-resources.a"/a\  "$BUILD_DIR/core/deps/miniupnpc/libminiupnpc.a" \\\n  "$BUILD_DIR/core/deps/libelf/libelf.a" \\' ./build-flycast.sh
 emcc -O3 -fwasm-exceptions -c /workspace/tools/metal-slug6-platform.c -o /build/teng-empty-port.o
 export STUBS=/build/teng-empty-port.o
fi
export OUT_DIR=/workspace/tools/_work/metal-slug/flycast-rebuilt
bash ./build-flycast.sh
