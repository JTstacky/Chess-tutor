import { loadGameFiles } from '../../src/platform/gamedata.js';
import { controls } from './input.js';
import { GameSaves } from './saves.js';
import { sha256 } from '../../src/saves/pack.js';
const $=s=>document.querySelector(s), status=$('#status'), canvas=$('#screen');
const context=canvas.getContext('2d',{alpha:false});
const pixels=context.createImageData(320,224), rgba=new Uint32Array(pixels.data.buffer);
let saves;
let engine,paused=false,audio,muted=false,audioTime=0,last=0,accumulator=0;
const metrics={frames:0,frameMs:[],ready:false};
const input=controls(togglePause);
function togglePause(){if(!engine)return;paused=!paused;input.clear();$('#pause').textContent=paused?'Resume':'Pause';last=0;accumulator=0;if(paused){audio?.suspend();capture().catch(showSaveError);}else if(!muted)audio?.resume();}
$('#pause').onclick=togglePause;
$('#sound').onclick=()=>{muted=!muted;$('#sound').textContent=muted?'Sound off':'Sound on';if(muted)audio?.suspend();else audio?.resume();};
$('#fullscreen').onclick=()=>{const action=document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen();action?.catch(()=>{});};
document.addEventListener('visibilitychange',()=>{if(document.hidden&&engine&&!paused)togglePause();});
function render(){const source=new Uint32Array(engine.HEAPU8.buffer,engine._ng_web_pixels(),320*224);for(let i=0;i<rgba.length;i++){const p=source[i];rgba[i]=0xff000000|((p&255)<<16)|(p&0xff00)|((p>>>16)&255);}context.putImageData(pixels,0,0);}
function sound(count){if(!audio||muted||audio.state!=='running'||count===0)return;const samples=new Int16Array(engine.HEAPU8.buffer,engine._ng_web_audio(),count*2),buffer=audio.createBuffer(2,count,55555);for(let channel=0;channel<2;channel++){const dest=buffer.getChannelData(channel);for(let i=0;i<count;i++)dest[i]=samples[i*2+channel]/32768;}audioTime=Math.max(audioTime,audio.currentTime+.025);if(audioTime>audio.currentTime+.15)return;const source=audio.createBufferSource();source.buffer=buffer;source.connect(audio.destination);source.start(audioTime);audioTime+=buffer.duration;}
function tick(time){requestAnimationFrame(tick);if(!engine||!metrics.ready||paused){last=0;return;}if(!last)last=time;accumulator+=Math.min(time-last,100);last=time;const step=1000/59.185606;let ran=0;while(accumulator>=step&&ran<4){const start=performance.now();const count=engine._ng_web_step(input.read(),input.second());sound(count);metrics.frameMs.push(performance.now()-start);if(metrics.frameMs.length>1800)metrics.frameMs.shift();metrics.frames++;accumulator-=step;ran++;}if(ran)render();}
async function start() {
  metrics.ready=false;const play=$('#play');play.disabled=true;status.textContent='Loading original game…';
  try {
    audio=new AudioContext({latencyHint:'interactive'});await audio.resume();
    const progress=(done,total)=>{status.textContent=`Loading ${Math.round(done/total*100)}%`;};
    const [files,code]=await Promise.all([loadGameFiles('metal-slug',{onProgress:progress}),loadGameFiles('metal-slug-engine')]);
    const js=code.get('metal-slug.js'),wasm=code.get('metal-slug.wasm');
    if(!js||!wasm)throw Error('The private game engine is missing.');
    const url=URL.createObjectURL(new Blob([js],{type:'text/javascript'}));let factory;
    try{factory=(await import(/* @vite-ignore */ url)).default;}finally{URL.revokeObjectURL(url);}
    engine=await factory({wasmBinary:wasm,locateFile:name=>new URL(name,location.href).href,noInitialRun:true,print:console.log,printErr:console.warn});
    engine.FS.mkdir('/roms');for(const [name,bytes] of files)engine.FS.writeFile('/roms/'+name,bytes);
    engine.callMain(['--rom-path','/roms']);
    saves=new GameSaves('metal-slug',await sha256(wasm),message=>{$('#save-status').textContent=message;});
    const saved=await saves.open();
    if(saved){engine.HEAPU8.set(saved,engine._ng_web_state());if(!engine._ng_web_load(saved.length))throw Error('The saved game is incompatible. Your save has been preserved.');}
    metrics.ready=true;$('#intro').hidden=true;$('#playfield').hidden=false;$('#game-controls').hidden=false;
    $('#pause').disabled=false;$('#sound').disabled=false;last=0;
  }catch(error){engine=null;status.textContent=error.message;play.disabled=false;await audio?.close();}
}
function showSaveError(error){$('#save-status').textContent=error.message;}
function capture(){if(!engine||!metrics.ready||!saves)return Promise.resolve();const n=engine._ng_web_save();if(!n)throw Error('Could not capture the game');return saves.save(engine.HEAPU8.slice(engine._ng_web_state(),engine._ng_web_state()+n));}
$('#save').onclick=()=>capture().catch(showSaveError);
setInterval(()=>{if(engine&&metrics.ready&&!paused&&engine._ng_web_frames()>1200)capture().catch(showSaveError);},15000);
window.addEventListener('pagehide',()=>capture().catch(()=>{}));
$('#play').onclick=start;
window.__metalSlug={metrics,capture,get frame(){return engine?engine._ng_web_frames():0;},get paused(){return paused;},get input(){return input.read();},get memory(){return engine?.HEAPU8.byteLength||0;},get pixels(){return engine?Array.from(new Uint8Array(engine.HEAPU8.buffer,engine._ng_web_pixels(),320*224*4)):[];}};
requestAnimationFrame(tick);
if(new URLSearchParams(location.search).has('play'))start();
