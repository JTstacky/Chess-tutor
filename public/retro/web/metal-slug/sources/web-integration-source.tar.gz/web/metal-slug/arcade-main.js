import {loadGameFiles,loadGameManifest} from '../../src/platform/gamedata.js';
import {controls} from './input.js';
import {GameSaves} from './saves.js';
import {installOnline} from './online.js';
import {installSavePicker} from './save-picker.js';
import identities from './rom-identities.json';
const $=s=>document.querySelector(s);
const id=location.pathname.match(/\/web\/(metal-slug(?:-[2x345])?)\//)?.[1]||'metal-slug';
const names={'metal-slug':'mslug','metal-slug-2':'mslug2','metal-slug-x':'mslugx','metal-slug-3':'mslug3','metal-slug-4':'mslug4','metal-slug-5':'mslug5'};
const vendorBase=new URL('../metal-slug/vendor/',location.href).href;
const coreBuild='fbneo-ng-d5f072e-20261027-'+identities[id].sha256.slice(0,16);
const frameMs=[];let loadStarted=0,loadMs=0;
let emu,saves,ready=false,paused=false,muted=false,online,remoteBits=0,cooperative=false;
const still=document.createElement('canvas');still.width=320;still.height=240;still.className='paused-screen';still.hidden=true;
const stillContext=still.getContext('2d',{alpha:false});
const input=controls(togglePause),previous=[0,0];
const mapping=[[1,4],[2,5],[4,6],[8,7],[16,0],[32,8],[64,1],[128,9],[256,2],[512,3]];
const notify=text=>{$('#save-status').textContent=text;};
function setInput(seat,bits){if(!ready)return;for(const [mask,key] of mapping)if((previous[seat]&mask)!==(bits&mask))emu.gameManager.simulateInput(seat,key,+(!!(bits&mask)));previous[seat]=bits;}
function release(){input.clear();setInput(0,0);setInput(1,0);}
function togglePause(){if(!ready)return;paused=!paused;release();paused?emu.pause():emu.play();still.hidden=!paused;$('#pause').textContent=paused?'Resume':'Pause';if(paused)capture().catch(e=>notify(e.message));}
$('#pause').onclick=togglePause;
$('#sound').onclick=()=>{muted=!muted;emu?.setVolume(muted?0:1);online?.setMuted(muted);$('#sound').textContent=muted?'Sound off':'Sound on';};
$('#fullscreen').onclick=()=>{(document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen())?.catch(()=>{});};
document.addEventListener('visibilitychange',()=>{if(document.hidden&&ready&&!paused)togglePause();});
window.addEventListener('blur',release);
async function capture(){if(cooperative)return online?.save();if(!ready||!saves)return;await saves.save(new Uint8Array(emu.gameManager.getState()));}
$('#save').onclick=()=>capture().catch(e=>notify(e.message));
setInterval(()=>{if(ready&&!paused)capture().catch(e=>notify(e.message));},15000);
window.addEventListener('pagehide',()=>capture().catch(()=>{}));
async function start({coop=false,fresh=false}={}){
 cooperative=coop;
 loadStarted=performance.now();
 $('#play').disabled=true;$('#status').textContent='Loading original game…';
 try{
  const manifest=await loadGameManifest(id+'-arcade'),identity=identities[id];
  if(!manifest.files.some(file=>file.path===identity.path&&file.sha256===identity.sha256))throw Error('Game files and player versions differ. Reload to update.');
  const files=await loadGameFiles(id+'-arcade',{manifest,only:path=>path===identity.path,onProgress:(n,total)=>{$('#status').textContent=`Loading ${Math.round(n/total*100)}%`;}});
  const rom=URL.createObjectURL(new Blob([files.get(names[id]+'.zip')]));
  $('#status').textContent='Starting the arcade game…';
  saves=new GameSaves(id,coreBuild,notify);let state=null;
  if(!coop){try{state=await saves.open();}catch(error){
    if(!fresh){if(!$('#new-game')){const button=document.createElement('button');button.id='new-game';button.textContent='Start new game (keep a backup)';button.onclick=()=>start({fresh:true});$('#intro').append(button);}throw error;}
    const previous=await saves.store.get(id,'auto');if(previous)await saves.store.putBackup(id,{...previous,label:'Before starting with a different engine'});saves.blocked=true;
    notify('Previous progress preserved. New progress saves on this device; use Saves to choose what syncs online.');
  }}
  Object.assign(window,{EJS_player:'#screen',EJS_core:'fbneo',EJS_gameName:names[id]+'.zip',EJS_gameUrl:rom,
   EJS_pathtodata:vendorBase,EJS_DEBUG_XX:true,EJS_startOnLoaded:true,
   EJS_disableAutoLang:true,EJS_language:'en-US',EJS_disableDatabases:true,EJS_disableLocalStorage:true,
   EJS_noAutoFocus:true,EJS_defaultOptions:{'virtual-gamepad':'disabled','menu-bar-button':'hidden','fps':'hide','shader':'disabled'},
   EJS_onGameStart:()=>{
    emu=window.EJS_emulator;emu.coopCanvas=still;emu.controls={0:{},1:{},2:{},3:{}};
    const loop=emu.Module.__tengMainLoop||emu.Module.Browser?.mainLoop;if(loop?.func){const frame=loop.func;loop.func=(...args)=>{const t=performance.now();try{return frame(...args);}finally{frameMs.push(performance.now()-t);if(frameMs.length>1200)frameMs.shift();}};}
    if(state)emu.gameManager.loadState(state);
    $('#screen').append(still);ready=true;loadMs=performance.now()-loadStarted;$('#intro').hidden=true;$('#pause').disabled=false;$('#sound').disabled=false;
    URL.revokeObjectURL(rom);
   }});
  $('#playfield').hidden=false;$('#game-controls').hidden=false;
  const script=document.createElement('script');script.src=vendorBase+'loader.js';
  script.onerror=()=>{$('#status').textContent='Could not load the game engine. Reload to retry.';};document.head.append(script);
 }catch(e){$('#status').textContent=e.message;$('#play').disabled=false;}
}
$('#play').onclick=start;
installSavePicker({getSaves:()=>saves,restore:async bytes=>{emu.gameManager.loadState(bytes);},pause:()=>{if(!paused)togglePause();},isCoop:()=>cooperative,notify});
function tick(){requestAnimationFrame(tick);if(ready&&!paused){setInput(0,input.read());setInput(1,cooperative?remoteBits:input.second());const c=emu.canvas,aspect=4/3,w=Math.min(c.width,c.height*aspect),h=w/aspect;stillContext.drawImage(c,(c.width-w)/2,(c.height-h)/2,w,h,0,0,still.width,still.height);}}
requestAnimationFrame(tick);
window.__metalSlug={capture,get frame(){return ready?emu.gameManager.getFrameNum():0;},get paused(){return paused;},get input(){return input.read();},get remoteInput(){return remoteBits;},get memory(){return emu?.Module.HEAPU8.byteLength||0;},metrics:{get ready(){return ready;},get loadMs(){return loadMs;},frameMs}};
installOnline({game:id,title:document.querySelector('h1').textContent,build:coreBuild,host:()=>emu,
 async startHost(){cooperative=true;if(ready){release();emu.gameManager.restart();return;}await start({coop:true});const end=Date.now()+90000;while(!ready){if(Date.now()>end)throw Error('Game loading timed out');await new Promise(r=>setTimeout(r,100));}},
 readInput:()=>input.read(),setRemote:bits=>{remoteBits=bits;},pause:value=>{if(ready&&paused!==value)togglePause();},
 checkpoint:async()=>new Uint8Array(emu.gameManager.getState()),
 async restore(data){const bytes=Uint8Array.from(atob(data),c=>c.charCodeAt(0));if(bytes.length>2*1024*1024)throw Error('Invalid co-op save');emu.gameManager.loadState(bytes);},
 showGuest(video,canvas){cooperative=true;$('#intro').hidden=true;$('#playfield').hidden=false;$('#game-controls').hidden=false;$('#sound').disabled=false;$('#screen').classList.add('remote-screen');$('#screen').replaceChildren(canvas,video);video.hidden=true;$('#pause').disabled=true;},notify
}).then(value=>{online=value;window.__metalSlug.online=value;}).catch(()=>{notify('Online invites are unavailable. Solo play still works.');});
