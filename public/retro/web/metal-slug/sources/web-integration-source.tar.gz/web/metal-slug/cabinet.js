// Keep game controls mounted: their input handlers and held pointers stay intact.
export function installCabinet() {
  const $ = selector => document.querySelector(selector);
  const header = $('header');
  const menu = document.createElement('details');
  menu.id = 'cabinet-menu';
  const summary = document.createElement('summary');
  summary.textContent = 'Menu';
  const panel = document.createElement('div');
  panel.id = 'menu-panel';
  menu.append(summary, panel);
  const back = $('header a');
  back.textContent = 'Games';
  back.href = '/#retro-classics';
  back.setAttribute('aria-label', 'Back to games');
  panel.append($('#sound'), $('#fullscreen'), $('#save'));
  const hint = $('#hint');
  panel.append(hint, $('footer'));
  const bar = document.createElement('div');
  bar.id = 'cabinet-bar';
  header.before(bar);
  bar.append(header, menu);
  // Coin and Start remain immediately accessible beside Pause.
  const controls = $('#game-controls');
  header.append(controls);
  menu.addEventListener('toggle', () => summary.setAttribute('aria-expanded', String(menu.open)));
  document.addEventListener('pointerdown', event => {
    if (!menu.contains(event.target)) menu.open = false;
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && menu.open) {
      event.stopImmediatePropagation();
      menu.open = false;
      summary.focus();
    }
  }, true);
  // Short-lived feedback never consumes screen space or stays over gameplay.
  const status = $('#save-status');
  bar.append(status);
  let timer;
  new MutationObserver(() => {
    status.classList.add('visible');
    clearTimeout(timer);
    timer = setTimeout(() => status.classList.remove('visible'), 5000);
  }).observe(status, {childList: true, characterData: true, subtree: true});
}
