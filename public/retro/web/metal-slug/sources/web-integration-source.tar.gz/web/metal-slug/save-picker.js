export function installSavePicker({getSaves,restore,pause,isCoop,notify}){
 const button=document.createElement('button');button.textContent='Saves';document.querySelector('#menu-panel').prepend(button);
 const dialog=document.createElement('dialog');dialog.className='save-picker';document.body.append(dialog);
 button.onclick=async()=>{
  if(isCoop()){notify('Co-op progress uses Save and the same private invite to resume.');return;}
  const saves=getSaves();if(!saves)return;pause();dialog.replaceChildren();
  const title=document.createElement('h2');title.textContent='Saved progress';dialog.append(title);
  const help=document.createElement('p');help.textContent='Restore a save on this device and sync it online. Your current progress is kept as a backup.';dialog.append(help);
  for(const item of await saves.store.list(saves.game)){
   const row=document.createElement('button');row.textContent=`${item.slot==='auto'?'Current save':item.label||'Backup'} · ${new Date(item.updatedAt).toLocaleString()}`;
   row.onclick=async()=>{row.disabled=true;try{await restore(await saves.restoreSlot(item.slot));dialog.close();notify('Selected progress restored. Press Resume to continue.');}catch(e){notify(e.message);row.disabled=false;}};dialog.append(row);
  }
  const close=document.createElement('button');close.textContent='Close';close.onclick=()=>dialog.close();dialog.append(close);dialog.showModal();
 };
}
