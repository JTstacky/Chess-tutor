// Input is a union of independent keyboard, pointer and controller sources.
// Releasing one finger must not cancel a held direction on another source.
export function controls(onPause) {
  const held = new Map();
  const pressedAt=new Map();
  const keys = {ArrowUp:1,ArrowDown:2,ArrowLeft:4,ArrowRight:8,KeyZ:16,KeyX:32,KeyC:64,KeyV:128,Digit5:256,Digit1:512};
  const clear = () => { held.clear(); pressedAt.clear(); document.querySelectorAll('.held').forEach(el=>el.classList.remove('held')); };
  window.addEventListener('keydown', e => { if(keys[e.code]){e.preventDefault();held.set(e.code,keys[e.code]);} if(e.code==='Escape'&&!e.repeat)onPause(); });
  window.addEventListener('keyup', e=>{if(keys[e.code]){e.preventDefault();held.delete(e.code);}});
  let focused=true;
  window.addEventListener('blur',()=>{focused=false;clear();});
  window.addEventListener('focus',()=>{focused=true;});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)clear();});
  for(const button of document.querySelectorAll('[data-bit]')){
    button.addEventListener('pointerdown',e=>{e.preventDefault();button.setPointerCapture(e.pointerId);pressedAt.set(e.pointerId,performance.now());held.set(e.pointerId,Number(button.dataset.bit));button.classList.add('held');});
    const release=e=>{const bit=held.get(e.pointerId),at=pressedAt.get(e.pointerId);held.delete(e.pointerId);pressedAt.delete(e.pointerId);if(bit&&at!==undefined&&e.type==='pointerup'){const delay=70-(performance.now()-at);if(delay>0){const pulse=Symbol();held.set(pulse,bit);setTimeout(()=>{held.delete(pulse);if(![...held.values()].includes(bit))button.classList.remove('held');},delay);}}if(![...held.values()].includes(Number(button.dataset.bit)))button.classList.remove('held');};
    for(const event of ['pointerup','pointercancel','lostpointercapture'])button.addEventListener(event,release);
  }
  const pad=document.querySelector('#dpad');
  const move=e=>{if(!pad.hasPointerCapture(e.pointerId))return;const r=pad.getBoundingClientRect();const x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;let bits=0;if(Math.hypot(x,y)>.10){if(x<-.15)bits|=4;if(x>.15)bits|=8;if(y<-.15)bits|=1;if(y>.15)bits|=2;}held.set(e.pointerId,bits);};
  pad.addEventListener('pointerdown',e=>{e.preventDefault();pad.setPointerCapture(e.pointerId);move(e);});
  pad.addEventListener('pointermove',move);
  for(const event of ['pointerup','pointercancel','lostpointercapture'])pad.addEventListener(event,e=>held.delete(e.pointerId));
  function gamepad(index=0){const p=[...navigator.getGamepads()].filter(Boolean)[index];if(!p)return 0;const b=i=>p.buttons[i]?.pressed;let bits=0;if(b(12)||p.axes[1]<-.3)bits|=1;if(b(13)||p.axes[1]>.3)bits|=2;if(b(14)||p.axes[0]<-.3)bits|=4;if(b(15)||p.axes[0]>.3)bits|=8;if(b(0))bits|=16;if(b(1))bits|=32;if(b(2))bits|=64;if(b(3))bits|=128;if(b(8))bits|=256;if(b(9))bits|=512;return bits;}
  return {clear,read:()=>focused&&!document.hidden?[...held.values()].reduce((a,b)=>a|b,gamepad()):0,second:()=>focused&&!document.hidden?gamepad(1):0};
}
