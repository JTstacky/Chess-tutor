// The existing full-account private invite lobby authenticates both seats.
// Player 1 runs one authoritative instance; WebRTC carries picture/audio/input.
// The authenticated WebSocket supplies a fallback on networks blocking WebRTC.
export async function installOnline({game,title,build,startHost,host,readInput,setRemote,pause,checkpoint,restore,showGuest,notify,largeCheckpoints=false,checkpointEvery=15000,maxInputBits=1023}){
 const friends=document.createElement('button');friends.textContent='Friends';friends.onclick=()=>document.body.classList.toggle('show-invite');document.querySelector('header').append(friends);
 const panel=document.createElement('div');panel.id='online-lobby';document.querySelector('main').after(panel);
 if(!window.TengInvite)await new Promise((resolve,reject)=>{const s=document.createElement('script');s.src='/tg-invite.js';s.onload=resolve;s.onerror=reject;document.head.append(s);});
 let state,rtc,channel,stream,audioTap,audioSink,remoteAudio,audioTime=0,sequence=0,receivedSequence=-1,lastBits=-1,lastInput=0,active=false,booting=false,frameBusy=false,epoch=0;
 const video=document.createElement('video');video.autoplay=true;video.playsInline=true;video.muted=false;
 let muted=false;
 let pendingCandidates=[];
 let incomingCheckpoint=null,saving=null,hostInitialized=false;
 async function receiveCheckpoint(m){
  if(!largeCheckpoints||invite.seat!==0||m.generation!==state?.generation)return;
  if(m.type==='checkpoint-open'){
   if(m.build!==build||!Number.isSafeInteger(m.length)||m.length<4||m.length>Math.ceil(16*1024*1024/3)*4||m.parts!==Math.ceil(m.length/64000))throw Error('Invalid shared save');
   incomingCheckpoint={id:m.id,length:m.length,count:m.parts,parts:[],received:0};pause(true);return;
  }
  const saved=incomingCheckpoint;if(!saved||saved.id!==m.id)return;
  if(m.type==='checkpoint-part'){
   if(m.index!==saved.parts.length||typeof m.data!=='string'||m.data.length>64000||saved.received+m.data.length>saved.length){incomingCheckpoint=null;throw Error('Incomplete shared save');}
   saved.parts.push(m.data);saved.received+=m.data.length;return;
  }
  if(m.type==='checkpoint-close'){
   incomingCheckpoint=null;if(saved.received!==saved.length||saved.parts.length!==saved.count)throw Error('Incomplete shared save');
   await restore(saved.parts.join(''));pause(!both());
  }
 }
 function setMuted(value){muted=value;video.muted=value;if(value)remoteAudio?.suspend();else{remoteAudio?.resume();video.play().catch(()=>{});}}
 const canvas=document.createElement('canvas');canvas.width=320;canvas.height=240;const ctx=canvas.getContext('2d',{alpha:false});
 const joined=()=>active&&invite.connected;
 const both=()=>joined()&&state?.players.length===2&&state.players.every(p=>p.online);
 const send=m=>invite.send({...m,generation:state?.generation});
 function clear(){setRemote(0);receivedSequence=-1;lastBits=-1;lastInput=0;pendingCandidates=[];rtc?.close();rtc=null;channel=null;stream?.tengCleanup?.();stream=null;video.srcObject=null;video.hidden=true;canvas.hidden=false;epoch++;}
 function makeRTC(){rtc?.close();rtc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.cloudflare.com:3478'}]});const current=rtc;
  rtc.onicecandidate=e=>{if(current===rtc&&e.candidate)send({type:'signal',signal:{candidate:e.candidate.toJSON()}});};
  rtc.ontrack=e=>{if(current!==rtc)return;video.srcObject=e.streams[0]||new MediaStream([e.track]);video.hidden=false;canvas.hidden=true;video.play().catch(()=>notify('Tap any control to enable game sound.'));};
  rtc.ondatachannel=e=>{if(current===rtc)wire(e.channel);else e.channel.close();};
  return rtc;
 }
 function wire(dc){channel=dc;dc.onmessage=e=>{if(invite.seat!==0||channel!==dc)return;let m;try{m=JSON.parse(e.data);}catch{return;}if(m.generation!==state.generation||!Number.isSafeInteger(m.seq)||m.seq<=receivedSequence||!Number.isInteger(m.bits)||m.bits<0||m.bits>maxInputBits||!both())return;receivedSequence=m.seq;setRemote(m.bits);lastInput=performance.now();};}
 async function offer(){if(invite.seat!==0||!host()||!both()||(rtc&&!['closed','failed','disconnected'].includes(rtc.connectionState)))return;const pc=makeRTC();stream=host().collectScreenRecordingMediaTracks(host().coopCanvas,60);for(const track of stream.getTracks())pc.addTrack(track,stream);wire(pc.createDataChannel('controls',{ordered:false,maxRetransmits:0}));await pc.setLocalDescription(await pc.createOffer());if(pc===rtc)send({type:'signal',signal:{description:pc.localDescription.toJSON()}});}
 async function signal(value){if(value.generation!==state?.generation)return;const s=value.signal;if(s.description){if(s.description.type==='offer'){if(invite.seat!==1)return;makeRTC();}if(!rtc)return;const pc=rtc;await pc.setRemoteDescription(s.description);if(pc!==rtc)return;const waiting=pendingCandidates;pendingCandidates=[];for(const candidate of waiting)await pc.addIceCandidate(candidate).catch(()=>{});if(s.description.type==='offer'){await pc.setLocalDescription(await pc.createAnswer());if(pc===rtc)send({type:'signal',signal:{description:pc.localDescription.toJSON()}});}}else if(s.candidate){if(rtc?.remoteDescription)await rtc.addIceCandidate(s.candidate).catch(()=>{});else if(pendingCandidates.length<64)pendingCandidates.push(s.candidate);}}
 function packet(kind,bytes,rate=0){const out=new Uint8Array(8+bytes.byteLength),view=new DataView(out.buffer);view.setUint32(0,state.generation);view.setUint8(4,kind);view.setUint16(5,rate);out.set(new Uint8Array(bytes.buffer||bytes,bytes.byteOffset||0,bytes.byteLength),8);invite.send(out.buffer);}
 function setupAudio(){if(audioTap||!host())return;const al=host().Module.AL?.currentCtx;if(!al)return;const context=al.audioCtx;
  audioTap=context.createScriptProcessor(1024,2,2);audioSink=context.createGain();audioSink.gain.value=0;audioTap.connect(audioSink);audioSink.connect(context.destination);
  for(const source of Object.values(al.sources))source.gain.connect(audioTap);
  audioTap.onaudioprocess=e=>{if(!both()||channel?.readyState==='open')return;const n=e.inputBuffer.length,b=new Int16Array(n*2);for(let c=0;c<2;c++){const a=e.inputBuffer.getChannelData(c);for(let i=0;i<n;i++)b[i*2+c]=Math.max(-32768,Math.min(32767,a[i]*32767));}packet(2,b,context.sampleRate);};
 }
 const invite=window.TengInvite.mount({game,title,parent:panel,description:'Two full-account players. Create a private invite and send the link to your friend. Player 1 keeps this browser open while you play. Progress is saved separately from solo play.',
  async onState(value){active=true;document.body.classList.toggle('show-invite',value.players.length<2||!value.players.every(p=>p.online));const changed=state?.generation!==value.generation;state=value;if(changed)clear();
   if(invite.seat===0){if(!hostInitialized&&!booting){booting=true;try{await startHost();hostInitialized=true;setupAudio();send({type:'ready',build});}catch(e){notify(e.message);}finally{booting=false;}}else if(hostInitialized&&host()&&changed)send({type:'ready',build});pause(!both());}
   else{showGuest(video,canvas);remoteAudio??=new AudioContext({latencyHint:'interactive'});if(!muted)remoteAudio.resume().catch(()=>{});send({type:'ready',build});}
  },
  async onMessage(m){try{if(largeCheckpoints&&m.type.startsWith('checkpoint-')){await receiveCheckpoint(m);return;}if((m.type==='peer-ready'||m.type==='ready')&&invite.seat===0)await offer();else if(m.type==='signal')await signal(m);else if(m.type==='input'&&invite.seat===0&&m.seat===1&&m.generation===state.generation&&Number.isSafeInteger(m.seq)&&m.seq>receivedSequence){receivedSequence=m.seq;setRemote(m.bits);lastInput=performance.now();}else if(m.type==='checkpoint'&&invite.seat===0){await restore(m.data);pause(!both());}else if(m.type==='saved')notify('Co-op progress saved online');else if(m.type==='error')notify(m.message);}catch(e){notify('Connection retry needed: '+e.message);}},
  async onFrame(bytes){if(invite.seat!==1||!both())return;const view=new DataView(bytes);if(bytes.byteLength<9||view.getUint32(0)!==state.generation)return;const kind=view.getUint8(4);
   if(kind===1&&rtc?.connectionState!=='connected'&&!frameBusy){frameBusy=true;const stamp=epoch;let bitmap;try{bitmap=await createImageBitmap(new Blob([bytes.slice(8)],{type:'image/jpeg'}));if(stamp===epoch)ctx.drawImage(bitmap,0,0,320,240);}finally{bitmap?.close();frameBusy=false;}}
   if(kind===2&&rtc?.connectionState!=='connected'&&remoteAudio?.state==='running'){const data=new Int16Array(bytes,8),rate=view.getUint16(5);if(rate<8000||rate>48000||data.length%2)return;const b=remoteAudio.createBuffer(2,data.length/2,rate);for(let c=0;c<2;c++){const dest=b.getChannelData(c);for(let i=0;i<dest.length;i++)dest[i]=data[i*2+c]/32768;}audioTime=Math.max(audioTime,remoteAudio.currentTime+.03);if(audioTime>remoteAudio.currentTime+.15)return;const source=remoteAudio.createBufferSource();source.buffer=b;source.connect(remoteAudio.destination);source.start(audioTime);audioTime+=b.duration;}
  },onDisconnect(){document.body.classList.add('show-invite');clear();pause(true);notify('Co-op paused. Reconnect with the same invite.');}
 });
 setInterval(()=>{if(!both())return;const bits=readInput();if(invite.seat===1){const m={type:'input',bits,seq:++sequence,generation:state.generation};if(channel?.readyState==='open')channel.send(JSON.stringify(m));else invite.send(m);}else{if(lastInput&&performance.now()-lastInput>300)setRemote(0);}},33);
 setInterval(()=>{if(invite.seat!==0||!host()||!both()||channel?.readyState==='open'||frameBusy)return;frameBusy=true;const stamp=epoch;ctx.drawImage(host().coopCanvas,0,0,320,240);canvas.toBlob(async blob=>{try{if(blob&&stamp===epoch)packet(1,await blob.arrayBuffer());}finally{frameBusy=false;}},'image/jpeg',.7);},33);
 async function sendCheckpoint(){
  if(!joined()||invite.seat!==0||!host()||incomingCheckpoint)return;
  const generation=state.generation,bytes=await checkpoint();
  if(bytes.length>(largeCheckpoints?16:2)*1024*1024)throw Error('Shared save exceeds its storage limit. Previous progress is preserved.');
  let text='';for(let i=0;i<bytes.length;i+=8192)text+=String.fromCharCode(...bytes.subarray(i,i+8192));const data=btoa(text);
  if(!largeCheckpoints){send({type:'checkpoint',data});return;}
  const id=crypto.randomUUID();send({type:'checkpoint-begin',id,length:data.length});
  for(let offset=0,index=0;offset<data.length;offset+=32768,index++){
   if(!joined()||state.generation!==generation)throw Error('Connection changed during saving. Previous shared progress is preserved.');
   send({type:'checkpoint-part',id,index,data:data.slice(offset,offset+32768)});
   await new Promise(r=>setTimeout(r,50));
  }
  send({type:'checkpoint-end',id});
 }
 function save(){if(!saving)saving=sendCheckpoint().finally(()=>{saving=null;});return saving;}
 setInterval(()=>save().catch(e=>notify(e.message)),checkpointEvery);
 window.addEventListener('blur',()=>{if(joined())send({type:'input',bits:0,seq:++sequence});});
 document.addEventListener('pointerdown',()=>{if(active&&invite.seat===1&&!muted){remoteAudio?.resume();video.play().catch(()=>{});}});
 return{setMuted,async diagnostics(){const report=rtc?await rtc.getStats():[];let audio=0,frames=0,rtt=null;for(const r of report.values()){if(r.type==='inbound-rtp'&&r.kind==='audio')audio+=r.bytesReceived||0;if(r.type==='inbound-rtp'&&r.kind==='video')frames+=r.framesDecoded||0;if(r.type==='candidate-pair'&&r.state==='succeeded')rtt=r.currentRoundTripTime;}return{connection:rtc?.connectionState||'relay',audioBytes:audio,videoFrames:frames,rtt};},useRelay(){clear();},get active(){return active;},get seat(){return invite.seat;},get both(){return both();},save,invite};
}
