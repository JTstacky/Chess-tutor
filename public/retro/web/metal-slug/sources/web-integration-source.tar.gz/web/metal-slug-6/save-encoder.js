let worker,sequence=0;const pending=new Map();
function encode(kind,data,transfers){
 if(!worker){worker=new Worker(new URL('./save-worker.js',import.meta.url),{type:'module'});worker.onmessage=({data:{id,result,error}})=>{const job=pending.get(id);if(!job)return;pending.delete(id);clearTimeout(job.timer);error?job.reject(Error(error)):job.resolve(result);};worker.onerror=()=>{for(const job of pending.values()){clearTimeout(job.timer);job.reject(Error('Save preparation failed. Please try Save again.'));}pending.clear();worker.terminate();worker=null;};}
 return new Promise((resolve,reject)=>{const id=++sequence,timer=setTimeout(()=>{pending.delete(id);reject(Error('Save preparation timed out. Please try again.'));},60000);pending.set(id,{resolve,reject,timer});worker.postMessage({id,kind,...data},transfers);});
}
export const encodeSave=files=>encode('save',{files},files.map(f=>f.bytes.buffer));
export const encodeCheckpoint=bytes=>encode('checkpoint',{bytes},[bytes.buffer]);
