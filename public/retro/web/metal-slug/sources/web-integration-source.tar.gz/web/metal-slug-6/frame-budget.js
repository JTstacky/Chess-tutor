// Temporary overload may reduce rendering, never permanently cap it at 30 FPS.
// Ignore pauses, save work and low-refresh displays: they are not CPU pressure.
export function frameBudget(setSkip) {
 let skipped=0,slow=0,healthy=0,cooldown=0;
 return {
  get skipped(){return skipped;},
  sample({fps,p90,active=true}) {
   if(!active){slow=0;healthy=0;return;}
   if(cooldown>0)cooldown--;
   if(!skipped){
    slow=fps<57&&p90>16.7?slow+1:0;
    if(slow>=3&&!cooldown){skipped=1;slow=0;healthy=0;cooldown=10;setSkip('1');}
   }else{
    healthy=fps>=57&&p90<12?healthy+1:0;
    if(healthy>=5&&!cooldown){skipped=0;slow=0;healthy=0;cooldown=10;setSkip('disabled');}
   }
  }
 };
}
