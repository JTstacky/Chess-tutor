import {installCabinet} from '../metal-slug/cabinet.js';
import {loadGameFiles,loadGameManifest} from '../../src/platform/gamedata.js';
import {controls} from '../metal-slug/input.js';
import {GameSaves} from '../metal-slug/saves.js';
import {installOnline} from '../metal-slug/online.js';
import {installSavePicker} from '../metal-slug/save-picker.js';
import {unpackState} from './state.js';
import {encodeSave,encodeCheckpoint} from './save-encoder.js';
import identity from './engine.json';
import {frameBudget} from './frame-budget.js';

const $=s=>document.querySelector(s),id='metal-slug-6';
installCabinet();
const vendorBase=new URL('../metal-slug/vendor/',location.href).href;
const notify=text=>{$('#save-status').textContent=text;};
let emu,saves,online,adapter,initialCompressed,ready=false,paused=false,muted=false,cooperative=false,remoteBits=0,loading=false,saving=null;
let loadStarted=0,loadMs=0,measuredFps=0;
const frameMs=[],previous=[0,0];
const still=document.createElement('canvas');still.width=320;still.height=240;still.className='paused-screen';still.hidden=true;
const context=still.getContext('2d',{alpha:false});
const input=controls(togglePause,{weaponSwitch:true});
const mapping=[[1,4],[2,5],[4,6],[8,7],[16,0],[32,8],[64,1],[128,9],[256,2],[512,3],[1024,11]];
function setInput(seat,bits){if(!ready)return;for(const [mask,key] of mapping)if((previous[seat]&mask)!==(bits&mask))emu.gameManager.simulateInput(seat,key,+(!!(bits&mask)));previous[seat]=bits;}
function release(){input.clear();setInput(0,0);setInput(1,0);}
function drawFrame(){const canvas=emu.canvas,w=Math.min(canvas.width,canvas.height*4/3),h=w*3/4;context.drawImage(canvas,(canvas.width-w)/2,(canvas.height-h)/2,w,h,0,0,320,240);}
function togglePause(){if(!ready)return;if(!paused)drawFrame();paused=!paused;release();paused?emu.pause():emu.play();still.hidden=!paused;$('#pause').textContent=paused?'Resume':'Pause';if(paused)capture().catch(e=>notify(e.message));}
$('#pause').onclick=togglePause;
$('#sound').onclick=()=>{muted=!muted;emu?.setVolume(muted?0:1);online?.setMuted(muted);$('#sound').textContent=muted?'Sound off':'Sound on';};
$('#fullscreen').onclick=()=>{(document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen())?.catch(()=>{});};
window.addEventListener('blur',release);
document.addEventListener('visibilitychange',()=>{if(document.hidden&&ready&&!paused)togglePause();});
document.addEventListener('pointerdown',()=>{emu?.Module._flyAud?.ctx.resume().catch(()=>{});});
function capture(){
 if(cooperative)return online?.save();
 if(!ready||!saves)return Promise.resolve();
 if(!saving)saving=saves.save(emu.gameManager.getState()).finally(()=>{saving=null;});return saving;
}
$('#save').onclick=()=>capture().catch(e=>notify(e.message));
setInterval(()=>{if(ready&&!paused&&!cooperative)capture().catch(e=>notify(e.message));},60000);
window.addEventListener('pagehide',()=>capture().catch(()=>{}));
function mediaAdapter(){
 const audio=emu.Module._flyAud;
 if(!audio?.ready)throw Error('Game audio is not ready');
 return {coopCanvas:still,Module:{AL:{currentCtx:{audioCtx:audio.ctx,sources:{game:{gain:audio.node}}}}},
  collectScreenRecordingMediaTracks(canvas,fps){
   const stream=canvas.captureStream(30),destination=audio.ctx.createMediaStreamDestination();
   audio.node.connect(destination);for(const track of destination.stream.getAudioTracks())stream.addTrack(track);
   stream.tengCleanup=()=>{stream.getTracks().forEach(t=>t.stop());try{audio.node.disconnect(destination);}catch{}destination.disconnect();};return stream;
  }};
}
async function start({coop=false,fresh=false}={}){
 if(loading||ready)return;loading=true;cooperative=coop;loadStarted=performance.now();$('#play').disabled=true;
 try{
  $('#status').textContent='Loading original game…';
  const manifest=await loadGameManifest(id+'-arcade');
  for(const [path,hash] of Object.entries(identity.files))if(!manifest.files.some(f=>f.path===path&&f.sha256===hash))throw Error('Game files and player versions differ. Reload to update.');
  const files=await loadGameFiles(id+'-arcade',{manifest,only:path=>path in identity.files,onProgress:(n,total)=>{$('#status').textContent=`Loading ${Math.round(n/total*100)}%`;}});
  initialCompressed=files.get('boot.gz');saves=new GameSaves(id,identity.build,notify,{encode:encodeSave});let state=null;
  if(!coop)try{state=await saves.open();}catch(error){
   if(!fresh){if(!$('#new-game')){const button=document.createElement('button');button.id='new-game';button.textContent='Start new game (keep a backup)';button.onclick=()=>start({fresh:true});$('#intro').append(button);}throw error;}
   const old=await saves.store.get(id,'auto');if(old)await saves.store.putBackup(id,{...old,label:'Before starting with a different engine'});saves.blocked=true;
  }
  const rom=URL.createObjectURL(new Blob([files.get('mslug6.7z')])),bios=URL.createObjectURL(new Blob([files.get('awbios.7z')]));
  $('#status').textContent='Starting the arcade game…';
  Object.assign(window,{EJS_player:'#screen',EJS_core:'flycast',EJS_gameName:'mslug6.7z',EJS_gameUrl:rom,EJS_externalFiles:{'/dc/awbios.7z':bios},
   EJS_pathtodata:vendorBase,EJS_DEBUG_XX:true,EJS_startOnLoaded:true,EJS_disableAutoLang:true,EJS_language:'en-US',EJS_disableDatabases:true,EJS_disableLocalStorage:true,EJS_noAutoFocus:true,
   EJS_defaultOptions:{'virtual-gamepad':'disabled','menu-bar-button':'hidden','fps':'hide','shader':'disabled','webgl2Enabled':'enabled','reicast_hle_bios':'disabled','reicast_threaded_rendering':'disabled','reicast_frame_skipping':'disabled','reicast_internal_resolution':'320x240'},
   EJS_onGameStart:async()=>{try{
    emu=window.EJS_emulator;emu.controls={0:{},1:{},2:{},3:{}};emu.Module._useCleanDispatch=1;
    emu.gameManager.loadState(state||await unpackState(initialCompressed));state=null;emu.Module._useCleanDispatch=0;
    const end=Date.now()+5000;while(!emu.Module._flyAud?.ready){if(Date.now()>end)throw Error('Audio initialization failed. Reload to retry.');await new Promise(r=>setTimeout(r,50));}
    adapter=mediaAdapter();const loop=emu.Module.__tengMainLoop;let frameStarted=0;
    loop.preMainLoop.push(()=>{frameStarted=performance.now();});loop.postMainLoop.push(()=>{frameMs.push(performance.now()-frameStarted);if(frameMs.length>1200)frameMs.shift();});
    $('#screen').append(still);ready=true;loading=false;loadMs=performance.now()-loadStarted;$('#intro').hidden=true;$('#pause').disabled=false;$('#sound').disabled=false;
    URL.revokeObjectURL(rom);URL.revokeObjectURL(bios);files.clear();
   }catch(error){loading=false;$('#status').textContent=error.message;notify(error.message);}}
  });
  $('#playfield').hidden=false;$('#game-controls').hidden=false;
  const script=document.createElement('script');script.src=vendorBase+'loader.js';script.onerror=()=>{$('#status').textContent='Could not load the engine. Reload to retry.';};document.head.append(script);
 }catch(error){loading=false;$('#status').textContent=error.message;$('#play').disabled=false;}
}
$('#play').onclick=()=>start();
installSavePicker({getSaves:()=>saves,restore:async bytes=>{emu.gameManager.loadState(bytes);emu.Module._useCleanDispatch=0;},pause:()=>{if(!paused)togglePause();},isCoop:()=>cooperative,notify});
let lastStreamFrame=0;
function tick(now){requestAnimationFrame(tick);if(ready&&!paused){setInput(0,input.read());setInput(1,cooperative?remoteBits:input.second());if(cooperative&&now-lastStreamFrame>=1000/30){drawFrame();lastStreamFrame=now;}}}
requestAnimationFrame(tick);
let lastFrame=0,lastTime=performance.now(),wasActive=false;
const budget=frameBudget(value=>emu.gameManager.setVariable('reicast_frame_skipping',value));
setInterval(()=>{
 const now=performance.now(),frame=ready?emu.gameManager.getFrameNum():0;
 measuredFps=(frame-lastFrame)*1000/(now-lastTime);lastFrame=frame;lastTime=now;
 const active=ready&&!paused&&!saving&&!document.hidden&&now-loadStarted>=20000;
 const samples=frameMs.slice(-Math.max(1,Math.round(measuredFps))).sort((a,b)=>a-b);
 budget.sample({fps:measuredFps,p90:samples[Math.floor(samples.length*.9)]||0,active:active&&wasActive});
 wasActive=active;
},1000);
window.__metalSlug={capture,get frame(){return ready?emu.gameManager.getFrameNum():0;},get paused(){return paused;},get input(){return input.read();},get remoteInput(){return remoteBits;},get memory(){return emu?.Module.HEAPU8.byteLength||0;},metrics:{get ready(){return ready;},get loadMs(){return loadMs;},get fps(){return measuredFps;},get renderSkip(){return budget.skipped;},frameMs}};
installOnline({game:id,title:'Metal Slug 6',build:identity.build,host:()=>ready?adapter:null,largeCheckpoints:true,checkpointEvery:60000,maxInputBits:2047,
 async startHost(){if(ready){release();capture().catch(error=>notify('Solo save: '+error.message));cooperative=true;emu.gameManager.loadState(await unpackState(initialCompressed));emu.Module._useCleanDispatch=0;return;}await start({coop:true});const end=Date.now()+180000;while(!ready){if(Date.now()>end)throw Error('Game loading timed out');await new Promise(r=>setTimeout(r,100));}},
 readInput:()=>input.read(),setRemote:bits=>{remoteBits=bits;},pause:value=>{if(ready&&paused!==value)togglePause();},checkpoint:async()=>encodeCheckpoint(emu.gameManager.getState()),
 async restore(data){const packed=Uint8Array.from(atob(data),c=>c.charCodeAt(0));if(packed.length>16*1024*1024)throw Error('Invalid shared save');emu.gameManager.loadState(await unpackState(packed));emu.Module._useCleanDispatch=0;},
 showGuest(video,canvas){cooperative=true;$('#intro').hidden=true;$('#playfield').hidden=false;$('#game-controls').hidden=false;$('#sound').disabled=false;$('#screen').classList.add('remote-screen');$('#screen').replaceChildren(canvas,video);video.hidden=true;$('#pause').disabled=true;},notify
}).then(value=>{online=value;window.__metalSlug.online=value;}).catch(()=>notify('Online invites are unavailable. Solo play still works.'));
