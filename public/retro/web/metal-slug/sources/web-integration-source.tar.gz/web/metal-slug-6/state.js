export const MAX_STATE=64*1024*1024;
export async function unpackState(bytes){
 const reader=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip')).getReader();
 const chunks=[];let size=0;
 try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>MAX_STATE)throw Error('Shared save is too large');chunks.push(value);}}
 catch(error){await reader.cancel().catch(()=>{});throw error;}
 const state=new Uint8Array(size);let offset=0;for(const chunk of chunks){state.set(chunk,offset);offset+=chunk.length;}return state;
}
export async function packState(bytes){
 if(!bytes.length||bytes.length>MAX_STATE)throw Error('Invalid game save size');
 const packed=new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer());
 if(packed.length>16*1024*1024)throw Error('Save exceeds its online storage limit');return packed;
}
