import {makeSave} from '../../src/saves/pack.js';
import {packState} from './state.js';
self.onmessage=async({data:{id,kind,files,bytes}})=>{
 try{const result=kind==='save'?await makeSave(files):await packState(bytes);const buffer=kind==='save'?result.body.buffer:result.buffer;self.postMessage({id,result},[buffer]);}
 catch(error){self.postMessage({id,error:error.message});}
};
