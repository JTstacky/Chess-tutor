// Game files for a port (docs/PLATFORM.md, "Game files").
//
//   const files = await loadGameFiles('lemmings', { onProgress: (done, total) => ... });
//   files: Map<path, Uint8Array>, paths as in the manifest (upper-case DOS names stay as they are)
//
// Dev (Vite): /private-data/<id>/manifest.json and /private-data/<id>/<path>, from private/<id>/.
// Online: the Worker's /api/retro/data/<id>/..., which checks the account for tier B games.
// Files are cached in Cache Storage by sha256, so each device downloads them once.

export const API = 'https://ev-online-api.justintengyz.workers.dev';
const CACHE = 'retro-gamedata-v1';

export class GameDataError extends Error {
  constructor(message, status) {
    super(message);
    this.name = 'GameDataError';
    this.status = status; // 401 signed out, 403 needs a full account
  }
}

function base(id) {
  const dev = import.meta.env?.DEV || location.hostname === 'localhost' || location.hostname === '127.0.0.1';
  return dev ? `/private-data/${id}/` : `${API}/api/retro/data/${id}/`;
}

function headers() {
  const session = (() => { try { return localStorage.getItem('evonline.session'); } catch { return null; } })();
  const device = (() => { try { return localStorage.getItem('tenggames.device'); } catch { return null; } })();
  const out = {};
  if (session) out.Authorization = 'Bearer ' + session;
  if (device) out['X-Device'] = device;
  return out;
}

async function fetchChecked(url) {
  const response = await fetch(url, { headers: headers() });
  if (response.status === 401) {
    // The server says why: signed out, session ended, or (with profiles) "Pick a profile first".
    const reason = await response.json().then(b => b?.error).catch(() => null);
    throw new GameDataError(reason && /profile/i.test(reason) ? reason : 'Sign in to play this game.', 401);
  }
  if (response.status === 403) throw new GameDataError('This game needs a full account.', 403);
  if (!response.ok) throw new GameDataError(`Could not load game files (HTTP ${response.status}).`, response.status);
  return response;
}

async function sha256(bytes) {
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
  return [...digest].map(v => v.toString(16).padStart(2, '0')).join('');
}

async function openCache() {
  try { return await caches.open(CACHE); } catch { return null; }
}

// The manifest alone ({ files: [{ path, size, sha256 }] }): lets a page with several games list them before
// downloading any (also checks the account, like loadGameFiles).
export async function loadGameManifest(id) {
  return (await fetchChecked(base(id) + 'manifest')).json();
}

// only: (path) => boolean picks the files to fetch (e.g. one game of several); manifest: reuse one already loaded.
export async function loadGameFiles(id, { onProgress, only, manifest } = {}) {
  const root = base(id);
  manifest ??= await loadGameManifest(id);
  const wanted = only ? manifest.files.filter(file => only(file.path)) : manifest.files;
  const cache = await openCache();
  const total = wanted.reduce((sum, file) => sum + file.size, 0);
  let done = 0;
  const files = new Map();

  for (const file of wanted) {
    const key = `https://retro-cache/${file.sha256}`;
    let bytes = null;
    const cached = cache && (await cache.match(key));
    if (cached) bytes = new Uint8Array(await cached.arrayBuffer());
    if (!bytes || (await sha256(bytes)) !== file.sha256) {
      const path = file.path.split('/').map(encodeURIComponent).join('/');
      bytes = new Uint8Array(await (await fetchChecked(root + path)).arrayBuffer());
      if ((await sha256(bytes)) !== file.sha256) throw new GameDataError(`Game file damaged in transit: ${file.path}`);
      try { await cache?.put(key, new Response(bytes)); } catch {}
    }
    files.set(file.path, bytes);
    done += file.size;
    onProgress?.(done, total);
  }
  return files;
}
