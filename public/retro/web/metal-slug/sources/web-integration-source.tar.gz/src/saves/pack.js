// RSV1 save pack (docs/cloud-saves.md section 5).
//
//   'RSV1' | u32 count | count x { u16 pathLen | path | u32 size | f64 mtime } | file bytes in the same order
//
// Little-endian. Paths are sorted so the same files always give the same bytes and the same hash.
// The stored form is the pack gzipped; the hash is SHA-256 over the uncompressed pack.

const MAGIC = [0x52, 0x53, 0x56, 0x31]; // 'RSV1'

// DOS file names aren't case-sensitive, so paths are stored upper-case and '/'-separated.
export function normalisePath(path) {
  const clean = String(path).replace(/\\/g, '/').replace(/^\/+/, '').toUpperCase();
  if (!clean || clean.split('/').some(part => part === '' || part === '.' || part === '..')) {
    throw Error('Invalid save path: ' + path);
  }
  return clean;
}

// files: iterable of { path, bytes, mtime? }
export function pack(files) {
  const encoder = new TextEncoder();
  const entries = [...files]
    .map(file => ({ path: normalisePath(file.path), bytes: new Uint8Array(file.bytes), mtime: file.mtime ?? 0 }))
    .sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
  const names = entries.map(entry => encoder.encode(entry.path));
  let size = 8;
  entries.forEach((entry, i) => { size += 2 + names[i].length + 4 + 8 + entry.bytes.length; });

  const out = new Uint8Array(size);
  const view = new DataView(out.buffer);
  out.set(MAGIC, 0);
  view.setUint32(4, entries.length, true);
  let p = 8;
  entries.forEach((entry, i) => {
    view.setUint16(p, names[i].length, true); p += 2;
    out.set(names[i], p); p += names[i].length;
    view.setUint32(p, entry.bytes.length, true); p += 4;
    view.setFloat64(p, entry.mtime, true); p += 8;
  });
  for (const entry of entries) { out.set(entry.bytes, p); p += entry.bytes.length; }
  return out;
}

export function unpack(bytes) {
  const data = new Uint8Array(bytes);
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  if (data.length < 8 || MAGIC.some((v, i) => data[i] !== v)) throw Error('Not an RSV1 save pack');
  const count = view.getUint32(4, true);
  const decoder = new TextDecoder();
  const headers = [];
  let p = 8;
  for (let i = 0; i < count; i++) {
    const nameLength = view.getUint16(p, true); p += 2;
    const path = normalisePath(decoder.decode(data.subarray(p, p + nameLength))); p += nameLength;
    const size = view.getUint32(p, true); p += 4;
    const mtime = view.getFloat64(p, true); p += 8;
    headers.push({ path, size, mtime });
  }
  const files = [];
  for (const header of headers) {
    if (p + header.size > data.length) throw Error('Save pack is truncated');
    files.push({ path: header.path, bytes: data.slice(p, p + header.size), mtime: header.mtime });
    p += header.size;
  }
  return files;
}

async function stream(bytes, transform) {
  const body = new Blob([bytes]).stream().pipeThrough(transform);
  return new Uint8Array(await new Response(body).arrayBuffer());
}
export const gzip = bytes => stream(bytes, new CompressionStream('gzip'));
export const gunzip = bytes => stream(bytes, new DecompressionStream('gzip'));

export async function sha256(bytes) {
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
  return [...digest].map(v => v.toString(16).padStart(2, '0')).join('');
}

// Turns a folder's save files into what the store keeps: { body (gzipped pack), sha256, size, files }.
export async function makeSave(files) {
  const raw = pack(files);
  return { body: await gzip(raw), sha256: await sha256(raw), size: raw.length, files: files.length };
}

export async function readSave(record) {
  return unpack(await gunzip(record.body));
}

// Glob matching for catalogue `saveGlob` entries: '*' is any run of characters, '?' is one.
export function globMatcher(globs) {
  const patterns = globs.map(glob => new RegExp('^' + normalisePath(glob)
    .replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '[^/]*').replace(/\?/g, '[^/]') + '$'));
  return path => patterns.some(pattern => pattern.test(normalisePath(path)));
}
