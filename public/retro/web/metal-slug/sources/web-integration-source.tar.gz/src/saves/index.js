// Local save store (IndexedDB), shaped like the online one in docs/cloud-saves.md so syncing can
// sit on top of it later.
//
// One record per game and slot. Slots: 'auto' (the save folder as the game left it) and 'b1'..'b9'
// (backups, e.g. this device's copy after a conflict).
//
//   list(gameId)                 -> [{ slot, rev, sha256, size, files, label, updatedAt }]  (no bodies)
//   get(gameId, slot)            -> the same plus `body` (gzipped RSV1 pack), or null
//   put(gameId, slot, save, rev) -> { rev } or { conflict: <current metadata> } when `rev` is stale
//   putBackup(gameId, save)      -> { slot, rev } in the next free backup slot (oldest reused when full)
// Guests (evonline.tier 'guest'): nothing is kept; list/get are empty and put/save return { rev, skipped: 'guest' }.
//   save(gameId, save, rev)      -> put to 'auto'; on conflict keeps the other copy in 'auto' and
//                                   stores this one as a backup: { rev } or { conflict, backup }

export { makeSave, readSave, globMatcher, pack, unpack } from './pack.js';

export const AUTO = 'auto';
export const BACKUP_SLOTS = ['b1', 'b2', 'b3', 'b4', 'b5', 'b6', 'b7', 'b8', 'b9'];
const STORE = 'slots';

const metadata = ({ slot, rev, sha256, size, files, label, updatedAt }) => ({ slot, rev, sha256, size, files, label, updatedAt });

function request(req) {
  return new Promise((resolve, reject) => { req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); });
}

// Site sign-in (Chess-tutor auth / tg-profile.js) keeps these in localStorage.
const stored = key => { try { return localStorage.getItem(key); } catch { return null; } };
// Guests keep no saves at all, online or on the device (Teng Games accounts, 2026-10-22).
export const isGuest = () => stored('evonline.tier') === 'guest';
// Each profile on a shared device gets its own local store, so two kids on one tablet don't share saves.
// Without a profile id (signed out, or before profiles), the original store is used.
export function profileStoreName(base = 'retro-archive-saves-v2') {
  const id = stored('tenggames.profileId');
  return id && /^[A-Za-z0-9_-]{1,64}$/.test(id) ? `${base}-p${id}` : base;
}

export class IndexedDbSaves {
  constructor(name = profileStoreName()) {
    this.name = name;
    this.opening = null;
  }

  db() {
    this.opening ??= new Promise((resolve, reject) => {
      const req = indexedDB.open(this.name, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: ['gameId', 'slot'] });
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return this.opening;
  }

  async list(gameId) {
    if (isGuest()) return [];
    const db = await this.db();
    const range = IDBKeyRange.bound([gameId, ''], [gameId, '￿']);
    const out = [];
    await new Promise((resolve, reject) => {
      const req = db.transaction(STORE).objectStore(STORE).openCursor(range);
      req.onsuccess = () => {
        const cursor = req.result;
        if (!cursor) return resolve();
        out.push(metadata(cursor.value));
        cursor.continue();
      };
      req.onerror = () => reject(req.error);
    });
    return out;
  }

  async get(gameId, slot) {
    if (isGuest()) return null;
    const db = await this.db();
    return (await request(db.transaction(STORE).objectStore(STORE).get([gameId, slot]))) ?? null;
  }

  // Compare-and-set on the slot's revision, inside one transaction.
  async put(gameId, slot, save, baseRev = 0) {
    if (isGuest()) return { rev: baseRev, skipped: 'guest' };
    const db = await this.db();
    const tx = db.transaction(STORE, 'readwrite');
    const store = tx.objectStore(STORE);
    const done = new Promise((resolve, reject) => { tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error); });
    const current = await request(store.get([gameId, slot]));
    if ((current?.rev ?? 0) !== baseRev) {
      await done;
      return { conflict: metadata(current) };
    }
    const record = {
      gameId, slot, rev: baseRev + 1,
      body: save.body, sha256: save.sha256, size: save.size, files: save.files,
      label: save.label ?? '', updatedAt: new Date().toISOString(),
    };
    store.put(record);
    await done;
    return { rev: record.rev };
  }

  async putBackup(gameId, save) {
    const used = new Map((await this.list(gameId)).map(item => [item.slot, item]));
    let slot = BACKUP_SLOTS.find(name => !used.has(name));
    if (!slot) {
      slot = BACKUP_SLOTS.map(name => used.get(name)).sort((a, b) => a.updatedAt.localeCompare(b.updatedAt))[0].slot;
    }
    const result = await this.put(gameId, slot, save, used.get(slot)?.rev ?? 0);
    if (result.conflict) throw Error('Backup slot ' + slot + ' changed while saving');
    return { slot, rev: result.rev };
  }

  async save(gameId, save, baseRev) {
    if (isGuest()) return { rev: baseRev, skipped: 'guest' };
    const result = await this.put(gameId, AUTO, save, baseRev);
    if (!result.conflict) return result;
    const label = save.label || 'From this device, ' + new Date().toLocaleString();
    const backup = await this.putBackup(gameId, { ...save, label });
    return { conflict: result.conflict, backup };
  }
}
