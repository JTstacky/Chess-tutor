export function unzipStored(bytes) {
  const b = new Uint8Array(bytes),
    v = new DataView(b.buffer, b.byteOffset, b.byteLength),
    out = new Map(),
    dec = new TextDecoder();
  let p = 0;
  while (p + 30 < b.length && v.getUint32(p, true) === 0x04034b50) {
    const method = v.getUint16(p + 8, true),
      size = v.getUint32(p + 18, true),
      nameLen = v.getUint16(p + 26, true),
      extra = v.getUint16(p + 28, true);
    if (method !== 0) throw Error('Bundle uses unsupported ZIP compression');
    const name = dec.decode(b.subarray(p + 30, p + 30 + nameLen)),
      start = p + 30 + nameLen + extra;
    out.set(name, b.slice(start, start + size));
    p = start + size;
  }
  return out;
}
function crc32(b) {
  let c = -1;
  for (const v of b) {
    c ^= v;
    for (let i = 0; i < 8; i++) c = (c >>> 1) ^ (c & 1 ? 0xedb88320 : 0);
  }
  return (c ^ -1) >>> 0;
}
export function zipStored(files) {
  const enc = new TextEncoder(),
    chunks = [],
    central = [];
  let offset = 0;
  for (const [name, value] of files) {
    const data = new Uint8Array(value),
      n = enc.encode(name),
      crc = crc32(data),
      h = new Uint8Array(30),
      v = new DataView(h.buffer);
    v.setUint32(0, 0x04034b50, true);
    v.setUint16(4, 20, true);
    v.setUint32(14, crc, true);
    v.setUint32(18, data.length, true);
    v.setUint32(22, data.length, true);
    v.setUint16(26, n.length, true);
    chunks.push(h, n, data);
    const c = new Uint8Array(46),
      cv = new DataView(c.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, data.length, true);
    cv.setUint32(24, data.length, true);
    cv.setUint16(28, n.length, true);
    cv.setUint32(42, offset, true);
    central.push(c, n);
    offset += h.length + n.length + data.length;
  }
  const centralSize = central.reduce((s, x) => s + x.length, 0),
    end = new Uint8Array(22),
    ev = new DataView(end.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(8, files.size, true);
  ev.setUint16(10, files.size, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);
  const all = [...chunks, ...central, end],
    result = new Uint8Array(all.reduce((s, x) => s + x.length, 0));
  let p = 0;
  for (const x of all) {
    result.set(x, p);
    p += x.length;
  }
  return result;
}
