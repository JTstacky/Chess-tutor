#!/usr/bin/env bash
set -euo pipefail
cd /build
if [ ! -d fbneo ]; then mkdir fbneo; tar -xf /workspace/tools/_work/metal-slug/fbneo-source.tar -C fbneo; fi
cd fbneo/src/burner/libretro
emmake make platform=emscripten SUBSET=neogeo generate-files
emmake make -j2 platform=emscripten SUBSET=neogeo
cd /build
if [ ! -d retroarch-neogeo ]; then mkdir retroarch-neogeo; git -C retroarch archive 6dd4353937ef48b6ec0bfbdbb15d1c5992d86927 | tar -x -C retroarch-neogeo; fi
cp fbneo/src/burner/libretro/fbneo_neogeo_libretro_emscripten.bc retroarch-neogeo/libretro_emscripten.a
cd retroarch-neogeo
emmake make -j2 -f Makefile.emulatorjs HAVE_OPENGLES3=0 HAVE_AL=1 HAVE_RWEBAUDIO=0 ASYNC=0 HAVE_CHD=0 HAVE_7ZIP=0 TARGET=fbneo_libretro.js
mkdir -p /workspace/tools/_work/metal-slug/neogeo-rebuilt
cp fbneo_libretro.{js,wasm} /workspace/tools/_work/metal-slug/neogeo-rebuilt/
