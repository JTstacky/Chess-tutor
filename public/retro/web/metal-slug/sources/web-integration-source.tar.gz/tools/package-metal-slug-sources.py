"""Publish corresponding engine sources only; no game data is included."""
from pathlib import Path
import hashlib, json, shutil, tarfile
root=Path(__file__).resolve().parents[1]
out=root/'web/metal-slug/sources'
out.mkdir(exist_ok=True)
work=root/'tools/_work/metal-slug'
shutil.copyfile(work/'fbneo-source.tar.gz',out/'fbneo-source.tar.gz')
with (work/'retroarch-source.tar.gz').open('rb') as source:
    index=1
    while chunk:=source.read(20*1024*1024):
        (out/f'retroarch-source.tar.gz.part{index}').write_bytes(chunk)
        index+=1
with tarfile.open(out/'web-integration-source.tar.gz','w:gz') as archive:
    for folder in ['web/metal-slug','web/metal-slug-2','web/metal-slug-x','web/metal-slug-3','web/metal-slug-4','web/metal-slug-5','web/metal-slug-6','src/platform','src/saves']:
        for file in (root/folder).rglob('*'):
            if not file.is_file() or out in file.parents: continue
            if 'cores' in file.parts or file.name in ['flycast-probe.html','native.html']: continue
            archive.add(file,arcname=str(file.relative_to(root)))
    for name in ['tools/build-metal-slug-neogeo.sh','tools/prepare-metal-slug-neogeo.py','tools/package-metal-slug-sources.py','site-patches/arcade-room.js']:
        archive.add(root/name,arcname=name)
files={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in out.iterdir() if p.is_file() and p.name!='manifest.json'}
(out/'manifest.json').write_text(json.dumps(files,indent=2)+'\n')
print(json.dumps(files,indent=2))
