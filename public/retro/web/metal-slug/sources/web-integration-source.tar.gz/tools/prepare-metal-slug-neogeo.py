from pathlib import Path
import json
import shutil
import sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools/_work/metal-slug/python-deps'))
import py7zr
source=root/'tools/_work/metal-slug/neogeo-rebuilt'
runtime=source/'fbneo_libretro.js'
text=runtime.read_text(encoding='utf-8')
if 'Module["__tengMainLoop"]' not in text:
    marker='Module["Browser"]=Browser;'
    if marker not in text: raise RuntimeError('Missing main-loop export marker')
    text=text.replace(marker,'Module["__tengMainLoop"]=MainLoop;'+marker)
    runtime.write_text(text,encoding='utf-8')
(source/'core.json').write_text(json.dumps({'name':'fbneo','extensions':['zip'],'options':{},'save':False,'license':'license.txt','repo':'https://github.com/EmulatorJS/FBNeo'}),encoding='utf-8')
(source/'build.json').write_text(json.dumps({'minimumEJSVersion':'4.2.2','version':'2.0.2','tengBuild':'fbneo-neogeo-d5f072e-20261027'}),encoding='utf-8')
shutil.copyfile(root/'engines/emulatorjs-fbneo/src/license.txt',source/'license.txt')
target=root/'web/metal-slug/vendor/cores/fbneo-wasm.data'
with py7zr.SevenZipFile(target,'w',filters=[{'id':py7zr.FILTER_LZMA2,'preset':6}]) as archive:
    for name in ['fbneo_libretro.js','fbneo_libretro.wasm','core.json','build.json','license.txt']:
        archive.write(source/name,name)
# Both paths use the same WebGL1-compatible core; no second download variant.
shutil.copyfile(target,target.with_name('fbneo-legacy-wasm.data'))
print(f'Packaged Neo Geo-only core: {target.stat().st_size:,} bytes')
